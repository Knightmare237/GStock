# API GStock v1

Base : `/api/v1/`, JSON UTF-8. Sessions Django ; aucun jeton dans localStorage. Appeler GET csrf/ avant une mutation publique ; envoyer la valeur du cookie csrftoken dans X-CSRFToken. La connexion renouvelle le jeton CSRF, le frontend le recharge. POST login/register/reset/contact sont également protégés contre le CSRF.

## Comptes et organisation

| Endpoint | Méthodes | Fonction |
| --- | --- | --- |
| csrf/ | GET public | Initialise CSRF ; indique si le contact est configuré |
| auth/register/ | POST public | name, email, organization, password ; crée une organisation et son administrateur |
| auth/login/ | POST public | email, password ; ouvre une session |
| auth/logout/ | POST | Ferme la session |
| auth/me/ | GET, PATCH | Profil ; name, email ; current_password obligatoire pour changer d’email |
| auth/password/ | POST | current_password, password ; invalide les autres sessions |
| auth/forgot-password/ | POST public | email ; réponse identique pour compte absent/présent |
| auth/reset-password/ | POST public | uid, token, password ; lien à usage unique |
| organization/ | GET, PATCH administrateur | name, currency ; pas de conversion des prix |
| members/ | GET, POST administrateur | Liste ou crée un accès ; name, email, role ; lien email pour choisir son mot de passe |
| members/{user_id}/ | PATCH administrateur | role, active ; auto-désactivation interdite |
| contact/ | POST public | name, email, subject, message, website (honeypot vide) ; 503 si non configuré |

Un compte appartient à une seule organisation. Les transferts de comptes et le changement d’organisation ne sont pas disponibles. Aucun secret privilégié n’est envoyé au navigateur.

## Ressources métier

products/, categories/, partners/, documents/ : GET liste, POST création, GET détail, PATCH/PUT modification. DELETE n’est pas autorisé ; archivage par active=false pour produits, catégories et partenaires. Documents : annulation par action dédiée.

Listes paginées : `{count, next, previous, results}` ; 20 éléments/page. Paramètres `page`, `search`, `ordering`. Champs de tri limités par ressource. Produits : name, sku, quantity, purchase_price, sale_price, created_at ; préfixe `-` pour décroissant.

- Produits : sku, name, description, category (ID ou null), barcode, purchase_price, sale_price, minimum_stock, unit, active. `initial_quantity` disponible uniquement à la création et tracé comme mouvement ; quantity est en lecture seule. Filtres active=true/false, category, low_stock=true.
- Catégories : name, active ; archivage refusé si des produits actifs y sont rattachés.
- Partenaires : kind=customer/supplier, name, email, phone, address, active ; filtres kind et active.
- Documents : kind=sale/purchase, partner, notes et lines=[{product, quantity, unit_price}]. 1 à 100 lignes, produits distincts. Total calculé serveur, chaque ligne arrondie au centime. Statut, référence et total non modifiables par le client.
- POST documents/{id}/complete/ : sortie pour une vente ; réception complète pour un achat. Nouvelle validation d’un document déjà validé n’applique pas deux fois le stock.
- POST documents/{id}/cancel/ : annulation complète. Un document validé crée des mouvements inverses ; un brouillon ne modifie pas le stock. Annulation refusée si un stock deviendrait négatif. Retours/réceptions partiels non disponibles.
- movements/ : GET historique paginé, search produit/référence/motif. POST movements/adjust/ : product, delta signé à trois décimales, reason. Un mouvement ne se modifie ni ne se supprime.
- products/{id}/image/ : POST multipart avec image ; GET image privée ; DELETE retire l’image. JPEG/PNG/WebP, 5 Mo et 20 mégapixels maximum ; réencodage WebP 1600×1600 maximum, métadonnées éliminées.
- audit/ : GET événements de l’organisation, aucun mot de passe ni corps de formulaire enregistré.

## Import de produits

GET `products/import-template/` : modèle CSV UTF-8 avec BOM, séparateur point-virgule, une ligne d’exemple à remplacer. Accès owner/manager.

POST `products/import/` : multipart `file` CSV UTF-8 ou XLSX, `mode=preview` (défaut) ou `mode=commit`. Accès owner/manager, session et CSRF requis. Maximum 5 Mo / 1 000 lignes, première feuille Excel, formules refusées. La taille décompressée XLSX est limitée à 30 Mo.

Colonnes : `sku`, `name` obligatoires ; `description`, `category` (nom d’une catégorie active existante de l’organisation), `barcode`, `purchase_price`, `sale_price`, `initial_quantity`, `minimum_stock`, `unit`, `active` facultatives. En-têtes français acceptés : Référence, Produit, Description, Catégorie, Code barres, Prix achat, Prix vente, Quantité, Seuil, Unité, Actif. CSV séparé par point-virgule, virgule ou tabulation. Décimales avec point ou virgule ; quantités à 3 décimales, prix à 2. Actif : oui/non, true/false ou 1/0. Prix/stock/seuil par défaut zéro, unité « unité », actif par défaut vrai, catégorie vide. Codes-barres Excel au format texte pour conserver les zéros.

Preview : `{valid, count, preview, errors, error_count}`. Aperçu limité à 20 produits valides, erreurs aux 100 premières (`line`, `field`, `message`), toutes les lignes vérifiées. Aucun changement lors de l’analyse. Commit : renvoyer le même fichier ; nouvelle validation serveur, création atomique de toutes les lignes ou aucune. Références normalisées en majuscules, doublons dans le fichier ou catalogue refusés, aucun remplacement. Réponse 201 `{created}` ; erreurs de lignes 400 avec le même aperçu. La contrainte d’unicité protège aussi des imports simultanés (409). Stock initial tracé, événements product.create et product.import. Limite 30 demandes / 15 min par IP.

## Dashboard et exports

GET dashboard/?start=AAAA-MM-JJ&end=AAAA-MM-JJ : période inclusive, 367 jours maximum, dates UTC. Produits actifs, valeur du stock aux prix d’achat actuels (pas FIFO), stocks <= seuil, ruptures, totaux des documents validés hors annulations, ventes par jour, meilleurs produits, derniers mouvements et activité.

GET export/?kind=products|movements|sale|purchase&format=csv|xlsx&start=…&end=… : catalogue complet ou opérations de la période. Documents filtrés par date de création, tous statuts inclus ; dashboard filtré par date de validation et statut validé. CSV UTF-8 avec BOM, séparateur point-virgule ; protection contre les formules injectées. Les prix et quantités sont des décimales ; traiter les chaînes JSON comme décimales pour vos intégrations.

## Permissions

Toutes les requêtes métier limitent les objets à l’organisation dérivée de l’utilisateur connecté. Une organization fournie dans le JSON ne change pas cette sélection. Références category/product/partner d’une autre organisation rejetées ; détail hors organisation : 404.

| Rôle | Écriture |
| --- | --- |
| owner | Tous les modules, organisation et utilisateurs |
| manager | Catalogue, catégories, stock, clients/fournisseurs, ventes/achats |
| seller | Clients et ventes uniquement ; achats masqués dans l’API documents |
| accountant | Lecture et exports |
| reader | Lecture uniquement, exports interdits |

Tous les rôles ont accès aux informations de stock et indicateurs de leur organisation ; il ne s’agit pas de permissions personnalisées champ par champ. Export réservé owner/manager/accountant. L’administration Django est réservée aux administrateurs plateforme ; les données métier y sont consultables en lecture seule.

## Erreurs et abus

400 validation, 403 session/CSRF/permissions, 404 objet absent ou hors organisation, 409 contrainte/doublon, 429 limitation, 503 contact non configuré. Erreurs JSON champ par champ ou detail ; les erreurs internes restent des erreurs, jamais des réponses de succès.

Limites persistées par IP et endpoint : connexion 10/15 min, inscription et contact 5/h, reset 5/h et confirmation 10/15 min. Derrière un proxy, TRUST_PROXY=true seulement si X-Real-IP et X-Forwarded-Proto sont recréés et Django inaccessible directement. Prévoir également des limites de trafic au reverse proxy. Les compteurs peuvent être nettoyés périodiquement selon leur ancienneté.
