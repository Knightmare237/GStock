# Licences des dépendances directes

Relevé des métadonnées locales, pas une validation juridique de redistribution. Conserver les avis et textes de licence lors d’un packaging commercial.

## Frontend

| Paquet | Version installée | Licence déclarée |
| --- | --- | --- |
| @tailwindcss/vite | 4.3.3 | MIT |
| axios | 1.20.0 | MIT |
| framer-motion | 13.1.0 | MIT |
| lucide-react | 1.31.0 | ISC |
| react | 19.2.8 | MIT |
| react-dom | 19.2.8 | MIT |
| react-router-dom | 7.18.2 | MIT |
| tailwindcss | 4.3.3 | MIT |
| @types/react | 19.2.18 | MIT |
| @types/react-dom | 19.2.4 | MIT |
| @vitejs/plugin-react | 6.0.5 | MIT |
| oxlint | 1.78.0 | MIT |
| prettier | 3.9.10 | MIT |
| vite | 8.2.1 | MIT |

## Backend runtime

| Paquet | Version verrouillée | Licence déclarée |
| --- | --- | --- |
| asgiref | 3.12.1 | BSD-3-Clause |
| Django | 6.1.2 | BSD-3-Clause |
| djangorestframework | 3.18.3 | BSD-3-Clause |
| et_xmlfile | 2.0.0 | MIT |
| openpyxl | 3.1.5 | MIT |
| pillow | 12.3.0 | MIT-CMU |
| psycopg | 3.3.6 | LGPL-3.0-only |
| psycopg-binary | 3.3.6 | LGPL-3.0-only |
| python-dotenv | 1.2.4 | BSD-3-Clause |
| sqlparse | 0.6.0 | Voir le paquet |
| tzdata | 2026.5 | Apache-2.0 |
| waitress | 3.0.2 | ZPL 2.1 |
| whitenoise | 6.12.0 | MIT |
