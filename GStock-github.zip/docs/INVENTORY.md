# Inventaire des fichiers audités

Lecture des sources, configurations et documentation ; examen des assets comme fichiers statiques.

| Fichier | Taille (octets) |
| --- | ---: |
| `frontend/.gitignore` | 253 |
| `frontend/.oxlintrc.json` | 231 |
| `frontend/index.html` | 505 |
| `frontend/package-lock.json` | 76650 |
| `frontend/package.json` | 645 |
| `frontend/public/favicon.svg` | 9522 |
| `frontend/public/icons.svg` | 5031 |
| `frontend/README.md` | 1009 |
| `frontend/src/App.css` | 2891 |
| `frontend/src/App.jsx` | 1641 |
| `frontend/src/assets/hero.png` | 13057 |
| `frontend/src/assets/react.svg` | 4126 |
| `frontend/src/assets/vite.svg` | 8709 |
| `frontend/src/components/AnimatedSection.jsx` | 543 |
| `frontend/src/components/DashboardHeader.jsx` | 1969 |
| `frontend/src/components/DashboardSidebar.jsx` | 4850 |
| `frontend/src/components/Footer.jsx` | 2850 |
| `frontend/src/components/Navbar.jsx` | 4354 |
| `frontend/src/components/Skeleton.jsx` | 662 |
| `frontend/src/components/StatCard.jsx` | 1385 |
| `frontend/src/index.css` | 848 |
| `frontend/src/layouts/DashboardLayout.jsx` | 758 |
| `frontend/src/layouts/PublicLayout.jsx` | 619 |
| `frontend/src/main.jsx` | 228 |
| `frontend/src/pages/About.jsx` | 585 |
| `frontend/src/pages/Contact.jsx` | 1523 |
| `frontend/src/pages/Dashboard.jsx` | 8741 |
| `frontend/src/pages/Features.jsx` | 1518 |
| `frontend/src/pages/Home.jsx` | 15052 |
| `frontend/src/pages/Login.jsx` | 1738 |
| `frontend/src/pages/NotFound.jsx` | 517 |
| `frontend/src/pages/Register.jsx` | 2251 |
| `frontend/src/pages/Unavailable.jsx` | 901 |
| `frontend/vite.config.js` | 204 |

Les fichiers Unavailable.jsx et NotFound.jsx ont été créés après l’audit initial.

## Verrouillage des dépendances

SHA256 initial et final du package-lock.json : `8321c9831e70e2656da3a5a3278e5178e1094ba54c33a365080f12fa4b765635`.

## Sauvegarde initiale

`backups/initial-2026-10-13.zip` ; sans node_modules ni dist.

SHA256 : `7797762deb2cf59e56757080e5679ecf501ecb4809d664805b25c2b85f09cef9`.

Ne pas restaurer par-dessus les corrections : extraire dans un autre dossier pour comparaison.
