# Préparation desktop et licence annuelle

Document de conception initiale ; aucun client desktop ni serveur de licences développé. Évaluation technique définitive après stabilité de l’application web et validation du périmètre.

## Deux modèles distincts

| Modèle | Intérêt | Contraintes |
| --- | --- | --- |
| React dans Tauri + Django distant | Réutilisation du frontend ; données, sauvegardes et autorisation centralisées | Connectivité pour le métier, coût d’hébergement, suivi du service, gestion sûre de la session desktop |
| Desktop avec données locales | Métier possible sans réseau | Moteur de stockage local, sauvegarde sur poste, migrations et maintenance client ; synchronisation éventuelle complexe |

L’hypothèse prioritaire pour une première offre est le modèle connecté, sous réserve des besoins clients. Une période hors ligne de licence ne rend pas un backend distant accessible hors ligne. Ne pas introduire une seconde base locale sans décision explicite.

Évaluer Tauri avec un prototype Windows : empaquetage, distribution, mises à jour signées, compatibilité WebView et authentification vers l’API distante. Comparer Electron seulement si une dépendance Node ou une exigence de runtime embarqué le justifie. Ces points ne sont pas des capacités vérifiées du projet actuel.

## Frontières à préparer

Conserver React, isoler les appels HTTP dans des services, la configuration dans un module dédié et les fonctions natives derrière un adaptateur. Garder les règles de stock et permissions dans Django, sans dépendance aux composants React. Pour le modèle connecté, les autorisations métier restent contrôlées serveur.

## Licence

Le serveur d’autorisation devra stocker licence, organisation, édition, début/expiration, statut et quota d’appareils ; les activations, révocations et renouvellements devront être journalisés. Prévoir activation, vérification, renouvellement annuel, désactivation d’appareil et consultation de statut. Paiements ultérieurs, après validation commerciale.

Une attestation signée peut être vérifiée avec une clé publique embarquée ; la clé privée et tout secret privilégié restent exclusivement serveur. Définir durée de l’attestation, contrôles périodiques et tolérance hors ligne configurable. Documenter le risque de révocation différée, manipulation de l’horloge et contournement du client. Aucun contrôle client n’est impossible à contourner.

Une licence expirée doit provoquer une information claire et une politique de lecture/export à définir, sans suppression de données ni opération destructive. Limiter les activations par transaction serveur, prévoir révocation et rotation des clés, minimiser les identifiants d’appareil. Ne pas mélanger statut commercial de licence et rôle d’accès aux données.

La décision de stockage, la tolérance hors ligne, la distribution et les conditions d’expiration restent à valider avant implémentation complète.
