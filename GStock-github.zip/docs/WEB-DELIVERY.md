# Bilan de la version web — 13 octobre 2026

## Résultat

Le prototype a été prolongé par une application web avec persistance, organisations, authentification par sessions, catalogue, mouvements, partenaires, ventes/achats et indicateurs réels. L’interface publique existante a été conservée et complétée ; la démonstration fictive reste isolée sous /demo. Une organisation de test distincte a servi au parcours navigateur.

Le code de la version web est implémenté et validé localement sur SQLite. L’ouverture commerciale reste conditionnée à PostgreSQL, SMTP, HTTPS et la validation de restauration sur l’environnement de déploiement. Aucune publication externe n’a été effectuée.

## Fichiers analysés, créés et modifiés

- Sources et configurations frontend analysées dans l’audit initial, puis relues pour intégration.
- Backend créé : manage.py, config/settings.py, config/urls.py, config/wsgi.py, inventory/models.py, serializers.py, views.py, services.py, auth.py, errors.py, admin.py, tests.py et test_concurrency.py, migration 0001_initial.py, .env.example et dépendances verrouillées.
- Frontend créé : AuthPage, Products, Directory, Documents, Movements, LiveDashboard, Reports, Settings, WorkspaceLayout, UI réutilisable, ResourceState, contexte de session, hooks de requêtes/choix/périodes, client API et tests.
- Frontend modifié : App, Vite, index.html/CSS, Home, About, Features, Contact, wrappers Login/Register, Footer et PublicLayout ; logo SVG GStock ajouté.
- Livraison : scripts setup/lancement, compose.yaml, exemple Nginx, documentation API/déploiement, README, ROADMAP et CHANGELOG mis à jour.
- Clé locale créée uniquement dans .env exclu ; aucune clé privée/secret incorporé au frontend. Base locale neuve ; sauvegarde source initiale conservée ; aucune migration antérieure supprimée.

## Problèmes corrigés

- Formulaires et boutons du prototype remplacés par des parcours connectés, contrôles serveur et retours explicites.
- Isolation par organisation dans les listes, détails, références et mutations ; aucun organization transmis par le client ne permet de choisir le propriétaire.
- Quantité non éditable dans les métadonnées ; stock initial et modifications tracés. Transactions, ordre de verrouillage des produits et verrouillage des documents ; validation/annulation répétée sans double mouvement.
- Relecture verrouillée avant une modification de produit ou d’image : une sauvegarde de métadonnées ne peut écraser une quantité récemment modifiée.
- Rollback de toutes les lignes en cas de stock insuffisant ; refus des annulations de réceptions déjà consommées qui entraîneraient un stock négatif.
- CSRF exigé aussi pour la connexion et l’inscription anonymes ; session, mots de passe Django, limitation persistée et désactivation de comptes.
- Images contrôlées, réencodées, délivrées uniquement via une API privée ; données métier en lecture seule dans l’administration plateforme.
- Collision d’agrégat dans le classement des ventes corrigée ; paramètre format des exports rendu compatible avec DRF ; erreurs d’export Blob rendues visibles.
- Favicon de starter remplacé par un SVG GStock ; dépendance réseau Google Fonts supprimée au profit d’une police système ; actions d’activité traduites.
- Axios 1.19.0 et source-map-js 1.2.1 signalés vulnérables par npm ; corrections compatibles vers 1.20.0 et 1.2.2. Minimum déclaré Axios relevé pour éviter une réinstallation d’une version affectée.
- Pages React chargées à la demande pour supprimer l’avertissement de bundle supérieur à 500 kB ; gestion du focus/Escape et blocage du fond dans le menu mobile.
- Prettier ajouté uniquement comme outil de développement ; nouveaux composants mis en forme.

## Commandes et résultats exacts

| Vérification | Résultat |
| --- | --- |
| Installation venv/Django/DRF/psycopg/Pillow/dotenv/WhiteNoise/Waitress/openpyxl | Réussie après autorisation réseau ; versions dans requirements.txt |
| migrate | Toutes les migrations initiales appliquées à la base locale neuve |
| check | Code 0, aucun problème signalé |
| makemigrations --check --dry-run | Code 0, aucun changement détecté |
| collectstatic --noinput | 157 fichiers collectés |
| pip check | Code 0, aucune exigence cassée |
| compileall backend | Code 0 |
| check --deploy avec paramètres production simulés | Code 0, aucun problème ; pas un test de connexion PostgreSQL/SMTP/HTTPS |
| Tests backend finaux | 35 découverts : 34 réussis, 1 ignoré (concurrence PostgreSQL), code 0, 60,651 s |
| Tests frontend Node finaux | 6 réussis, 0 échec, code 0 |
| Scripts PowerShell | Trois scripts analysés, syntaxe valide ; apostrophes typographiques dans les messages corrigées |
| Lint frontend | Code 0, sans avertissement affiché |
| Build frontend | Code 0 ; 2 293 modules ; pages réparties en chunks à la demande ; entrée JS 302,46 kB / gzip 99,11 kB, CSS 37,92 kB / gzip 7,35 kB ; aucun avertissement de chunk trop volumineux |
| Audit npm après corrections | 0 vulnérabilité connue signalée |
| pip-audit sur les 13 exigences runtime verrouillées | Code 0, aucune vulnérabilité connue ; recommande en complément des hashes d’intégrité |

Les premiers tests ont exposé deux erreurs réelles (agrégat des ventes et format Excel) ; elles ont été corrigées, puis les suites réexécutées. Les restrictions EPERM pour Vite/Node et le répertoire temporaire image ont nécessité des réexécutions autorisées hors bac à sable. Les résultats restreints échoués n’ont pas été comptés comme réussites.

## Vérifications navigateur

- Inscription d’un compte de test → création d’organisation → session ouverte → tableau vide réel.
- Création d’un article : quantité initiale 10, prix d’achat 2 500 XAF, prix de vente 4 000 XAF.
- Brouillon de vente de 2 unités : total serveur 8 000 XAF ; validation après confirmation.
- Dashboard après vente : 1 produit, valeur de stock 20 000 XAF, ventes 8 000 XAF, historique +10 puis −2.
- Déconnexion effective et redirection de /dashboard/products vers /login pour une session absente.
- Ouverture/fermeture du menu mobile, sélection du module Ventes et formulaire de vente mobile.
- 17 pages principales × 6 largeurs (320, 375, 430, 768, 1024, 1440) : pas de débordement horizontal de document ; tableaux défilables dans leur conteneur. Six lectures arrivées pendant la vérification de session ont été reprises après apparition du titre, avec résultat normal.
- Les formulaires de réinitialisation ont été testés côté API ; toutes les variantes de modales/rôles/images n’ont pas fait l’objet d’une inspection visuelle exhaustive. Cette validation de largeur ne constitue pas un audit WCAG complet ni un test E2E automatisé.

## Limitations et risques résiduels

- PostgreSQL/Docker absents du poste : test concurrent non exécuté. SQLite ne fournit pas les garanties de verrouillage PostgreSQL et est interdit en production par la configuration.
- Aucun service SMTP/adresse officielle fourni : contact non activé localement, invitations/reset en console de développement. Livraison réelle et récupération de compte externe à vérifier après configuration.
- Configuration Nginx/HTTPS/Waitress préparée, non publiée ; sauvegarde/restauration PostgreSQL non exécutée ; aucun domaine d’hébergement choisi.
- Pas de retours ou réceptions partiels, taxes/paiements, PDF, FIFO, hors ligne ou desktop/licences. Une organisation par compte et rôles prédéfinis.

### Complément — import de catalogue et scrollbar

L’import de nouveaux produits CSV/XLSX est disponible dans Produits pour les administrateurs et gestionnaires : modèle CSV, analyse complète, aperçu de 20 lignes, erreurs par ligne, confirmation et création atomique. Maximum 1 000 produits / 5 Mo ; catégories existantes et références uniques, aucun remplacement. Stock initial tracé. Parcours CSV validé dans l’organisation de test : QA-IMPORT-20261013, stock 3,5, prix achat 12,50 et code-barres avec zéros conservés. Capture `import-produits-verification.png`.

Scrollbar sidebar fine et transparente au repos ; indicateur blanc discret au survol, focus ou écran tactile. Style vérifié dans le navigateur sur une navigation débordant réellement en hauteur. Suite backend : 43 tests, 42 réussis, 1 test PostgreSQL ignoré ; lint et compilation web réussis.
- Pas de suite navigateur automatisée ni pipeline CI/Git initialisé ; sauvegarde initiale disponible et tests reproductibles documentés.
- Audits de dépendances limités aux avis connus au moment de la vérification ; ils ne prouvent pas l’absence de toute faille. Un relevé des licences déclarées est disponible dans DEPENDENCY-LICENSES.md, sans conclusion juridique de redistribution.

## Prochaine étape de mise en service

Configurer PostgreSQL et SMTP avec vos coordonnées officielles, exécuter la suite incluant le test concurrent, choisir le domaine HTTPS, adapter le reverse proxy et vérifier une restauration dans un environnement distinct avant mise en service publique.
