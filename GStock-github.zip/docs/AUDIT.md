# Audit initial GStock — 13 octobre 2026

## Conclusion

Le projet est un prototype visuel frontend, pas une application de gestion de stock opérationnelle. La structure existante est réutilisable. La priorité est d’établir le backend, les organisations et l’authentification avant de connecter le CRUD Produits. Aucun problème de base de données existante n’est à contourner : aucun backend ni fichier de base n’a été trouvé dans le projet.

## Périmètre et état initial

Tous les fichiers applicatifs JSX/CSS, configs Vite/Oxlint, package.json, verrouillage, HTML, README, ignore et assets ont été inventoriés. Les sources textuelles ont été lues ; les images et SVG restent des assets. Le détail est dans [INVENTORY.md](INVENTORY.md). Les trois images fournies servent de références de design : sidebar, cartes statistiques, graphiques et activité récente ; elles ne constituent pas des preuves de fonctions disponibles.

Le seul dossier initial est frontend. Aucun AGENTS.md applicable trouvé. `git status` à la racine et dans frontend échoue : aucun dépôt Git. Aucun .env, backend Python, modèle Django, migration, PostgreSQL, serializer, ViewSet, service HTTP, journal d’opérations, script Windows ou suite de tests n’est présent. Aucun secret d’API observé dans les sources applicatives ; cela ne vaut pas audit de secrets exhaustif des dépendances.

## Constats par priorité

| Priorité | Constat | Traitement |
| --- | --- | --- |
| P0 | Pas d’authentification serveur ; /dashboard public, identité codée en dur | Démonstration publique isolée sous /demo ; backend et contrôles à développer |
| P0 | Pas d’organisation, permissions ou séparation des données | Conception serveur puis tests d’accès par identifiant avant tout CRUD |
| P0 | Pas de persistance, transaction ou opération de stock | Implémenter services métier transactionnels ; tester sous PostgreSQL |
| P1 | Formulaires sans handler ni service ; aucun feedback | Désactivés avec indication explicite, à connecter au backend |
| P1 | Huit liens sidebar sans pages et aucune 404 | Routes d’indisponibilité et page 404 ajoutées |
| P1 | Statistiques, activités et identité fictives non signalées | Étiquetées en démonstration ; claims commerciaux retirés |
| P1 | Boutons décoratifs et délai artificiel de chargement | Liens opérationnels ou actions désactivées ; délai retiré |
| P1 | Pas de tests ni documentation propre au projet | Guides et roadmap créés ; suites automatisées à écrire avec fonctions réelles |
| P2 | Trois imports inutilisés | Retirés ; lint sans avertissement |
| P2 | Menus sans libellé, focus et mouvement réduit incomplets | Libellés/focus/config Motion et CSS ajoutés |
| P2 | Navigation publique potentiellement trop large à 768 px | Breakpoint lg ; vérification navigateur encore requise |
| P2 | Police Google Fonts externe | Dépendance réseau conservée, fallback système ajouté ; hébergement local à évaluer |
| P2 | CSS et assets du starter inutilisés | Conservés pour éviter suppression inutile ; ménage ultérieur documenté |

## Dépendances et compilation

Stack vérifiée : React/React DOM 19.2.8, Router DOM 7.18.2, Tailwind et plugin Vite 4.3.3, Framer Motion 13.1.0, Lucide 1.31.0, Axios 1.19.0. Outils installés : Vite 8.2.1, plugin React 6.0.5, Oxlint 1.78.0, types React 19.2.18 et React DOM 19.2.4. Les écarts aux minima déclarés correspondent aux plages semver ; les 14 versions installées concordent avec package-lock. Axios est inutilisé mais conservé pour le futur client API. Aucun ajout ni changement de version.

Vite contient les plugins React et Tailwind cohérents avec l’import CSS. Aucun import vers un composant inexistant détecté ; la compilation finale résout les imports. L’audit de vulnérabilités à partir d’un registre actualisé n’a pas été exécuté : aucune affirmation d’absence de vulnérabilités n’est faite.

## Plan de correction priorisé

1. Conserver une référence sauvegardée et initialiser Git après revue ; compléter tests navigateur et CI.
2. Ajouter Django/DRF/PostgreSQL et configuration par environnement ; concevoir organisations, adhésions et rôles avant les modèles métier.
3. Pour le web même origine, retenir comme première hypothèse des sessions Django et CSRF ; tester expiration, désactivation, reset, cookies HTTPS et limitation d’abus. Aucune session n’est implémentée actuellement.
4. Construire le CRUD Produits/Catégories, contraintes serveur et DB, images validées, pagination et recherche ; connecter le client HTTP.
5. Ajouter mouvements et services transactionnels de réception/vente avec tests concurrents PostgreSQL et historique immuable des corrections.
6. Alimenter le dashboard à partir de l’organisation courante ; finir contact, public, responsive, exports et documentation de déploiement.
7. Stabiliser le métier avant de développer desktop et licences ; voir DESKTOP.md.

Les dépendances techniques justifient de connecter les formulaires lors de la construction du backend plutôt que d’achever des formulaires purement visuels avant leurs contrats API.

## Bilan de la phase

**Fichiers modifiés :** App.jsx, index.html, index.css, Home, Dashboard, Features, Login, Register, Contact, PublicLayout, AnimatedSection, DashboardHeader, DashboardSidebar, Navbar et Footer, ainsi que frontend/README.md. **Créés :** Unavailable, NotFound, .gitignore racine, README, ROADMAP, CHANGELOG, docs et sauvegarde. Les composants StatCard, Skeleton, DashboardLayout et About sont conservés.

**Fonctionnement réel :** rendu et compilation des pages, navigation publique, démonstration isolée, pages 404/indisponibilité et menus existants. Aucune fonction métier, authentification, envoi de contact ou sécurité multi-organisation n’est opérationnelle. Les squelettes sont conservés pour réutilisation, sans délai simulé.

**Commandes et résultats :**

- Inventaire `rg --files --hidden` hors node_modules/dist, lectures Get-Content, recherches des services, stockage et handlers.
- `git status --short`, `git -C frontend status --short` : code 1, pas de dépôt.
- `node --version`, `npm --version`, `python --version` : 26.5.0, 11.17.0, Python 3.14.6.
- Build initial restreint : code 1, EPERM et chargement natif Tailwind ; réexécution autorisée hors bac à sable : code 0, 2 220 modules.
- Lint initial : code 0, trois avertissements d’import inutilisé.
- `npm ls --depth=0` : code 0, aucune dépendance directe manquante.
- Une invocation accidentelle de npm run lint à la racine a échoué ENOENT ; réexécution dans frontend réussie.
- `npm run lint` final : code 0, aucun avertissement affiché.
- `npm run build` final hors bac à sable : code 0, 2 221 modules, JS 391,74 kB (gzip 122,49 kB), CSS 32,22 kB (gzip 6,45 kB).
- Contrôle Python : 14 versions directes conformes au verrouillage, empreinte du lock inchangée ; ZIP intègre, 37 entrées.

**Non vérifié :** console navigateur, rendu visuel final, six largeurs responsive, parcours E2E, tests backend, PostgreSQL, concurrence, emails, sauvegarde/restauration de données, HTTPS, déploiement, audit du registre et licences de dépendances. Aucun test métier ne peut être déclaré réussi puisque la suite et le backend n’existent pas.

**Risques résiduels :** prototype non commercialisable, absence de sécurité serveur et de données réelles ; routes d’indisponibilité et formulaires désactivés sont des états explicites, pas des implémentations. Une validation navigateur reste nécessaire pour le mouvement réduit, le drawer mobile et les débordements. La sauvegarde source ne remplace pas un historique Git.

**Prochaine étape :** stabilisation vérifiée au navigateur, puis socle Django/PostgreSQL avec organisations et sessions, avant le premier CRUD Produits.
