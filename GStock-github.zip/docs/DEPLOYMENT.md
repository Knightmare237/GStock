# Installation, données et déploiement

## Installation Windows

Depuis la racine, exécuter `./scripts/setup.ps1`. Python 3.12+ compatible avec les dépendances verrouillées et Node compatible avec Vite sont requis. Le script installe les paquets verrouillés, génère une clé aléatoire locale si .env n’existe pas, applique les migrations et installe le frontend. Il ne remplace pas un .env existant et ne supprime pas les données.

Ouvrir deux terminaux : `./scripts/start-backend.ps1` puis `./scripts/start-frontend.ps1`. Interface : http://127.0.0.1:5175 ; API : http://127.0.0.1:8005/api/v1/. Les ports diffèrent d’autres projets présents sur le poste. La session web utilise la même origine grâce au proxy Vite.

Créer votre organisation par la page d’inscription. Pour un administrateur technique plateforme : `.\.venv\Scripts\python.exe backend/manage.py createsuperuser`, puis /admin/ sur le backend. Ce compte technique ne possède pas automatiquement une organisation métier.

## PostgreSQL

SQLite est explicitement réservé au développement/test ; aucune base antérieure n’a été remplacée. En production, définir DB_ENGINE=postgresql, DB_NAME, DB_USER, DB_PASSWORD, DB_HOST et DB_PORT dans backend/.env. Ne pas changer de moteur pour déplacer des données : les bases sont distinctes. Si vous avez des données locales à reprendre, préparer un export et une migration contrôlée vers une base PostgreSQL vide, conserver l’ancienne base et vérifier les relations/comptages avant bascule.

Avec PostgreSQL installé, utiliser un rôle dédié non-superuser et une base appartenant à ce rôle. Par exemple dans psql, en administrateur :

```sql
CREATE ROLE gstock LOGIN;
\password gstock
CREATE DATABASE gstock OWNER gstock;
```

Le mot de passe est choisi à l’invite, jamais dans un fichier versionné. Variante Docker optionnelle : compose.yaml fournit PostgreSQL 17, lié uniquement à 127.0.0.1:5434 et un volume persistant. Définir POSTGRES_PASSWORD dans votre environnement puis `docker compose up -d postgres`. Configurer DB_PORT=5434. Ne pas utiliser `docker compose down -v` sur des données à conserver.

```powershell
.\.venv\Scripts\python.exe backend/manage.py migrate
.\.venv\Scripts\python.exe backend/manage.py makemigrations --check --dry-run
$env:TEST_POSTGRES = 'true'
.\.venv\Scripts\python.exe backend/manage.py test inventory
```

Les tests PostgreSQL créent une base de test distincte ; le rôle utilisé pour les tests doit disposer du droit CREATEDB. Ne pas donner ce droit au rôle de production. Le test concurrent est ignoré automatiquement sous SQLite.

## Emails

Le backend console est réservé au développement : les emails, avec liens de réinitialisation, apparaissent dans le terminal et ne sont pas livrés. En production, configurer EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend, EMAIL_HOST, EMAIL_PORT, EMAIL_HOST_USER, EMAIL_HOST_PASSWORD, EMAIL_USE_TLS, DEFAULT_FROM_EMAIL et CONTACT_EMAIL avec votre fournisseur et vos coordonnées officielles. WEB_URL doit correspondre à l’origine publique HTTPS. Aucun fournisseur ni aucune adresse officielle n’a été inventé.

Contact : si CONTACT_EMAIL est absent, le frontend indique son indisponibilité et le backend répond 503. Configurer l’adresse n’est pas une preuve de livraison : tester réellement SMTP et surveiller les erreurs. Le message est enregistré après acceptation par le backend email ; cela ne prouve pas sa réception finale par le destinataire.

## Déploiement même origine

1. Préparer PostgreSQL, HTTPS, un service SMTP et une clé DJANGO_SECRET_KEY propre à l’environnement. Sauvegarder avant migration.
2. Configurer DJANGO_DEBUG=false, DJANGO_ALLOWED_HOSTS=nom-de-domaine, WEB_URL=https://nom-de-domaine, CSRF_TRUSTED_ORIGINS=https://nom-de-domaine, DB_ENGINE=postgresql. Ne jamais exposer .env ni la clé serveur au frontend.
3. Exécuter migrate, collectstatic --noinput, puis `npm ci` et `npm run build` dans frontend.
4. Démarrer un service WSGI dédié avec Waitress, depuis backend : `..\.venv\Scripts\waitress-serve.exe --listen=127.0.0.1:8005 config.wsgi:application`. Installer ce lancement comme service supervisé adapté à votre hébergement ; pas runserver ni vite preview en production.
5. Faire servir frontend/dist par le reverse proxy, router /api, /admin et /static vers Django. Adapter deploy/nginx.conf.example (domaine, chemins, certificats). Conserver private-media hors d’une racine publique : images via API authentifiée uniquement.
6. TRUST_PROXY=true uniquement lorsque le proxy est maîtrisé, les en-têtes entrants supprimés/recréés et Django privé. Le proxy doit transmettre l’origine HTTPS et l’IP réelle. Ne pas activer cette confiance pour un backend publiquement accessible.
7. Exécuter `manage.py check --deploy`, les tests PostgreSQL, les parcours navigateur et un test de restauration avant ouverture commerciale.

Les cookies de session sont HttpOnly, Secure en production, SameSite=Lax. CSRF est actif, CORS ouvert à toutes les origines n’est pas configuré. L’application ne requiert pas de token en localStorage. Prévoir protections de trafic, supervision des erreurs, politique de rétention et revue des dépendances.

Cette configuration est préparée, pas un déploiement public effectué. Docker, PostgreSQL, reverse proxy et SMTP n’ont pas été démarrés/testés sur ce poste pendant la livraison locale.

## Sauvegarde et restauration

Sauvegarder ensemble PostgreSQL, backend/private-media, la configuration sécurisée et les versions déployées. Utiliser un emplacement privé, accès limités et conservation externe. Avec les outils PostgreSQL :

```powershell
pg_dump -h 127.0.0.1 -p 5432 -U gstock -W -Fc -f gstock-backup.dump gstock
```

Restaurer **dans une base distincte vide**, jamais par-dessus la production sans plan et validation :

```powershell
pg_restore -h 127.0.0.1 -p 5432 -U gstock -W -d gstock_restore gstock-backup.dump
```

Restaurer également les images dans un environnement isolé, vérifier intégrité, comptes, quantités, références et permissions, puis seulement envisager une bascule. Pour SQLite local, arrêter le backend avant copie de dev.sqlite3 et des images ; ne pas copier une base active sans mécanisme de backup cohérent.

## Dépannage

- Formulaire ou page « serveur inaccessible » : vérifier backend, proxy Vite et ports 8005/5175.
- 403 après changement de domaine : vérifier origine CSRF, cookies et faire une nouvelle connexion ; ne pas désactiver CSRF.
- Email absent : backend console, CONTACT_EMAIL absent ou SMTP en erreur ; consulter le terminal local sans partager de lien de reset.
- Annulation refusée : le mouvement inverse rendrait le stock négatif ; enregistrer d’abord les corrections/retours physiques nécessaires.
- Conflit SKU : références uniques par organisation, normalisées en majuscules.
- Stock non modifiable dans un produit : utiliser le module Mouvements, ne pas modifier la base directement.
- EPERM Vite en bac à sable : compilation réussie avec exécution autorisée, sans contournement ni changement arbitraire de versions.
