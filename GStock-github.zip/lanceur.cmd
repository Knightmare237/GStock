@echo off
setlocal
title GStock - Lanceur
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\launch-web.ps1"
if errorlevel 1 (
    echo.
    echo Le lancement de GStock a echoue. Consultez le message ci-dessus.
    pause
    exit /b 1
)
exit /b 0
