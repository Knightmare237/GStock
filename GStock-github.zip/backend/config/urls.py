from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from inventory import views

router = DefaultRouter()
router.register('products', views.ProductViewSet, basename='product')
router.register('categories', views.CategoryViewSet, basename='category')
router.register('partners', views.PartnerViewSet, basename='partner')
router.register('documents', views.DocumentViewSet, basename='document')
router.register('movements', views.MovementViewSet, basename='movement')
router.register('audit', views.AuditViewSet, basename='audit')
urlpatterns = [path('admin/', admin.site.urls), path('api/v1/', include(router.urls))]
for route, view in [('csrf/', views.csrf), ('auth/me/', views.me), ('auth/register/', views.register),
 ('auth/login/', views.sign_in), ('auth/logout/', views.sign_out), ('auth/password/', views.change_password),
 ('auth/forgot-password/', views.forgot_password), ('auth/reset-password/', views.reset_password),
 ('contact/', views.contact), ('organization/', views.organization_settings), ('members/', views.members),
 ('dashboard/', views.dashboard), ('export/', views.export)]:
    urlpatterns.append(path('api/v1/' + route, view))
urlpatterns.append(path('api/v1/members/<int:pk>/', views.member_update))
