from decimal import Decimal
from django.db import transaction
from rest_framework import serializers
from .models import Category, Product, Partner, Document, DocumentLine, Movement, AuditEvent
from .services import line_total

class TenantSerializer(serializers.ModelSerializer):
    def validate(self, attrs):
        org = self.context['request'].user.membership.organization
        for key in ('category', 'partner', 'product'):
            obj = attrs.get(key)
            if obj and (obj.organization_id != org.pk or not obj.active):
                raise serializers.ValidationError({key: 'Référence active introuvable dans votre organisation.'})
        return attrs

class CategorySerializer(TenantSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'active', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']
    def validate(self, attrs):
        attrs = super().validate(attrs)
        if attrs.get('active') is False and self.instance and self.instance.product_set.filter(active=True).exists():
            raise serializers.ValidationError({'active': 'Archivez ou reclassifiez les produits actifs avant cette catégorie.'})
        return attrs

    @transaction.atomic
    def update(self, instance, validated_data):
        instance = Category.objects.select_for_update().get(pk=instance.pk)
        if validated_data.get('active') is False and instance.product_set.filter(active=True).exists():
            raise serializers.ValidationError({'active': 'Cette catégorie contient encore des produits actifs.'})
        return super().update(instance, validated_data)

class ProductSerializer(TenantSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True, default='')
    image_url = serializers.SerializerMethodField()
    initial_quantity = serializers.DecimalField(max_digits=14, decimal_places=3, min_value=0, write_only=True, required=False, default=0)
    class Meta:
        model = Product
        fields = ['id', 'sku', 'name', 'description', 'category', 'category_name', 'barcode', 'purchase_price', 'sale_price',
                  'quantity', 'initial_quantity', 'minimum_stock', 'unit', 'active', 'image_url', 'created_at', 'updated_at']
        read_only_fields = ['id', 'quantity', 'created_at', 'updated_at']
        extra_kwargs = {key: {'min_value': 0} for key in ['purchase_price', 'sale_price', 'minimum_stock']}
    def get_image_url(self, obj):
        return f'/api/v1/products/{obj.pk}/image/' if obj.image else None
    def validate_sku(self, value):
        return value.strip().upper()
    def validate(self, attrs):
        attrs = super().validate(attrs)
        if self.instance and 'initial_quantity' in self.initial_data:
            raise serializers.ValidationError({'initial_quantity': 'Utilisez un mouvement de stock pour modifier la quantité.'})
        return attrs
    def create(self, validated_data):
        from .services import change_stock
        initial = validated_data.pop('initial_quantity', 0)
        with transaction.atomic():
            category = validated_data.get('category')
            if category and not Category.objects.select_for_update().get(pk=category.pk).active:
                raise serializers.ValidationError({'category': 'Cette catégorie est archivée.'})
            product = super().create(validated_data)
            if initial:
                change_stock(product, initial, self.context['request'].user, 'Stock initial')
            return product

    @transaction.atomic
    def update(self, instance, validated_data):
        # A metadata save must not overwrite a quantity changed by another transaction.
        instance = Product.objects.select_for_update().get(pk=instance.pk)
        category = validated_data.get('category')
        if category and not Category.objects.select_for_update().get(pk=category.pk).active:
            raise serializers.ValidationError({'category': 'Cette catégorie est archivée.'})
        validated_data.pop('initial_quantity', None)
        return super().update(instance, validated_data)

class PartnerSerializer(TenantSerializer):
    class Meta:
        model = Partner
        fields = ['id', 'kind', 'name', 'email', 'phone', 'address', 'active', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

class LineSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    class Meta:
        model = DocumentLine
        fields = ['id', 'product', 'product_name', 'quantity', 'unit_price']
        extra_kwargs = {'quantity': {'min_value': Decimal('0.001')}, 'unit_price': {'min_value': 0}}

class DocumentSerializer(TenantSerializer):
    lines = LineSerializer(many=True)
    partner_name = serializers.CharField(source='partner.name', read_only=True, default='')
    class Meta:
        model = Document
        fields = ['id', 'kind', 'reference', 'partner', 'partner_name', 'notes', 'status', 'total', 'lines',
                  'created_at', 'completed_at', 'cancelled_at']
        read_only_fields = ['id', 'reference', 'status', 'total', 'created_at', 'completed_at', 'cancelled_at']
    def validate(self, attrs):
        attrs = super().validate(attrs)
        if self.instance and self.instance.status != 'draft':
            raise serializers.ValidationError('Seul un brouillon peut être modifié.')
        if self.instance and 'kind' in attrs and attrs['kind'] != self.instance.kind:
            raise serializers.ValidationError({'kind': 'Le type du document ne peut pas être changé.'})
        kind = attrs.get('kind', self.instance.kind if self.instance else None)
        partner = attrs.get('partner', self.instance.partner if self.instance else None)
        if partner and partner.kind != ('customer' if kind == 'sale' else 'supplier'):
            raise serializers.ValidationError({'partner': 'Type de partenaire incompatible.'})
        org = self.context['request'].user.membership.organization
        lines = attrs.get('lines')
        if lines is not None:
            if not lines or len(lines) > 100:
                raise serializers.ValidationError({'lines': 'Entre 1 et 100 lignes sont nécessaires.'})
            seen = set()
            for line in lines:
                p = line['product']
                if p.organization_id != org.pk or not p.active:
                    raise serializers.ValidationError({'lines': 'Produit actif introuvable dans votre organisation.'})
                if p.pk in seen:
                    raise serializers.ValidationError({'lines': 'Un produit ne peut apparaître qu’une fois.'})
                seen.add(p.pk)
            if line_total(lines) > Decimal('99999999999999.99'):
                raise serializers.ValidationError({'lines': 'Le total dépasse la limite autorisée.'})
        return attrs
    @transaction.atomic
    def create(self, data):
        lines = data.pop('lines')
        document = Document.objects.create(**data, total=line_total(lines))
        for line in lines:
            DocumentLine.objects.create(document=document, **line)
        return document
    @transaction.atomic
    def update(self, instance, data):
        # Lock against a concurrent validation while replacing draft lines.
        instance = Document.objects.select_for_update().get(pk=instance.pk)
        if instance.status != 'draft':
            raise serializers.ValidationError('Seul un brouillon peut être modifié.')
        lines = data.pop('lines', None)
        if lines is not None:
            instance.lines.all().delete()
            for line in lines:
                DocumentLine.objects.create(document=instance, **line)
            data['total'] = line_total(lines)
        return super().update(instance, data)

class MovementSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    user_name = serializers.CharField(source='user.first_name', read_only=True)
    class Meta:
        model = Movement
        fields = ['id', 'product', 'product_name', 'delta', 'balance', 'reason', 'user_name', 'document', 'created_at']

class AuditSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.first_name', read_only=True)
    class Meta:
        model = AuditEvent
        fields = ['id', 'action', 'object_id', 'user_name', 'created_at']

class ContactSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120)
    email = serializers.EmailField()
    subject = serializers.CharField(max_length=160)
    message = serializers.CharField(min_length=10, max_length=5000)
    website = serializers.CharField(required=False, allow_blank=True, max_length=200)
