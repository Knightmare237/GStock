from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from threading import Barrier
from unittest import skipUnless
from django.contrib.auth import get_user_model
from django.db import connection, close_old_connections
from django.test import TransactionTestCase
from rest_framework.exceptions import ValidationError
from .models import Organization, Membership, Product, Document, DocumentLine, Movement
from .services import transition_document

@skipUnless(connection.vendor == 'postgresql', 'Verrouillage concurrent à vérifier sur PostgreSQL, pas SQLite.')
class PostgreSQLConcurrencyTests(TransactionTestCase):
    def test_two_sales_cannot_consume_same_stock(self):
        user = get_user_model().objects.create_user(username='concurrency@example.test', password='Test-Only!2026')
        org = Organization.objects.create(name='Test concurrent')
        Membership.objects.create(user=user, organization=org, role='owner')
        product = Product.objects.create(organization=org, sku='CONCURRENT', name='Dernière unité', quantity=1)
        documents=[]
        for _ in range(2):
            doc=Document.objects.create(organization=org, kind='sale', created_by=user, total=10)
            DocumentLine.objects.create(document=doc,product=product,quantity=1,unit_price=10)
            documents.append(doc.pk)
        barrier=Barrier(2)
        def sell(pk):
            close_old_connections()
            try:
                thread_user=get_user_model().objects.get(pk=user.pk)
                thread_org=Organization.objects.get(pk=org.pk)
                barrier.wait(timeout=10)
                transition_document(thread_org,pk,thread_user)
                return 'completed'
            except ValidationError:
                return 'rejected'
            finally:
                close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(sell,documents))
        self.assertCountEqual(results,['completed','rejected'])
        product.refresh_from_db()
        self.assertEqual(product.quantity,Decimal('0'))
        self.assertEqual(Movement.objects.filter(product=product).count(),1)
