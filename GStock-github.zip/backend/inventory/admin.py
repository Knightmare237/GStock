from django.contrib import admin
from .models import Organization, Membership, Category, Product, Partner, Document, DocumentLine, Movement, AuditEvent, ContactMessage

# Platform administrators can inspect all organizations. Business writes stay in the API
# so the stock ledger and organization checks cannot be bypassed from admin forms.
class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def has_view_permission(self, request, obj=None):
        return request.user.is_superuser

for model in [Organization, Membership, Category, Product, Partner, Document, DocumentLine, Movement, AuditEvent, ContactMessage]:
    admin.site.register(model, ReadOnlyAdmin)
