import io
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from openpyxl import Workbook
from rest_framework.test import APIClient
from .models import Organization, Membership, Product, Category, Movement, AuditEvent

class ProductImportTests(TestCase):
    def setUp(self):
        self.org = Organization.objects.create(name='Import tests')
        self.other = Organization.objects.create(name='Other')
        self.user = get_user_model().objects.create_user(username='import-test')
        self.member = Membership.objects.create(user=self.user, organization=self.org, role='owner')
        self.client = APIClient()
        self.client.force_login(self.user)

    def csv(self, text, mode='preview'):
        return self.client.post('/api/v1/products/import/', {'file': SimpleUploadedFile('products.csv', text.encode('utf-8-sig')), 'mode': mode}, format='multipart')

    def xlsx(self, rows, mode='preview'):
        book = Workbook()
        for row in rows:
            book.active.append(row)
        buffer = io.BytesIO()
        book.save(buffer)
        return self.client.post('/api/v1/products/import/', {'file': SimpleUploadedFile('products.xlsx', buffer.getvalue()), 'mode': mode}, format='multipart')

    def test_preview_then_commit_french_decimals_stock_and_audit(self):
        Category.objects.create(organization=self.org, name='Boissons')
        text = 'Référence;Produit;Catégorie;Quantité;Prix achat;Prix vente;Seuil;Actif;Code barres\n test-1 ;Café;boissons;3,500;12,50;20;2;oui;001234\n'
        preview = self.csv(text)
        self.assertEqual(preview.status_code, 200, preview.data)
        self.assertTrue(preview.data['valid'], preview.data)
        self.assertFalse(Product.objects.exists())
        self.assertFalse(Movement.objects.exists())
        response = self.csv(text, 'commit')
        self.assertEqual(response.status_code, 201, response.data)
        product = Product.objects.get(organization=self.org)
        self.assertEqual(product.sku, 'TEST-1')
        self.assertEqual(str(product.quantity), '3.500')
        self.assertEqual(str(product.purchase_price), '12.50')
        self.assertEqual(product.barcode, '001234')
        self.assertEqual(Movement.objects.get().product, product)
        self.assertTrue(AuditEvent.objects.filter(action='product.import').exists())
        self.assertEqual(self.csv(text, 'commit').status_code, 400)
        self.assertEqual(Product.objects.count(), 1)
        self.assertEqual(Movement.objects.count(), 1)

    def test_invalid_row_prevents_entire_commit(self):
        result = self.csv('sku;name;initial_quantity\nOK;Valide;5\nBAD;Invalide;-1\n', 'commit')
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data['errors'][0]['line'], 3)
        self.assertFalse(Product.objects.exists())
        self.assertFalse(Movement.objects.exists())

    def test_duplicate_case_normalized_and_no_overwrite(self):
        Product.objects.create(organization=self.org, sku='OLD', name='Original')
        result = self.csv('sku,name\nnew,Nouveau\nNEW,Autre\nold,Remplacement\n', 'commit')
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data['error_count'], 2)
        self.assertEqual(Product.objects.get().name, 'Original')

    def test_other_organization_sku_allowed_but_category_unavailable(self):
        Product.objects.create(organization=self.other, sku='SHARED', name='Other')
        Category.objects.create(organization=self.other, name='Privée')
        self.assertEqual(self.csv('sku;name;category\nSHARED;Local;Privée\n', 'commit').status_code, 400)
        self.assertEqual(self.csv('sku;name\nSHARED;Local\n', 'commit').status_code, 201)
        self.assertEqual(Product.objects.filter(organization=self.other).count(), 1)

    def test_xlsx_values_and_formulas(self):
        result = self.xlsx([['sku', 'name', 'initial_quantity'], ['XL-1', 'Excel', 7]], 'commit')
        self.assertEqual(result.status_code, 201, result.data)
        self.assertEqual(Product.objects.get().quantity, 7)
        formula = self.xlsx([['sku', 'name'], ['XL-2', '=1+1']], 'commit')
        self.assertEqual(formula.status_code, 400)
        self.assertEqual(Product.objects.count(), 1)

    def test_permissions_template_and_import(self):
        for role in ['reader', 'seller', 'accountant']:
            self.member.role = role
            self.member.save()
            self.assertEqual(self.csv('sku;name\nA;B\n').status_code, 403)
            self.assertEqual(self.client.get('/api/v1/products/import-template/').status_code, 403)

    def test_template_is_accepted_and_preview_does_not_write(self):
        result = self.client.get('/api/v1/products/import-template/')
        self.assertEqual(result.status_code, 200)
        self.assertTrue(self.csv(result.content.decode('utf-8-sig')).data['valid'])
        self.assertFalse(Product.objects.exists())

    def test_missing_headers_excess_rows_and_corrupt_file(self):
        for text in ['sku;sku\nA;B', 'name;unit\nA;unité', 'sku;name\n' + 'A;B\n' * 1001]:
            self.assertEqual(self.csv(text).status_code, 400)
        result = self.client.post('/api/v1/products/import/', {'file': SimpleUploadedFile('bad.xlsx', b'not a workbook')}, format='multipart')
        self.assertEqual(result.status_code, 400)
        self.assertFalse(Product.objects.exists())
