import logging
from decimal import Decimal, ROUND_HALF_UP
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from .models import AuditEvent, Document, Movement, Product

def audit(user, organization, action, object_id=''):
    AuditEvent.objects.create(user=user, organization=organization, action=action, object_id=str(object_id))
    logging.getLogger('gstock.audit').info('user=%s organization=%s action=%s object=%s', user.pk, organization.pk, action, object_id)

def change_stock(product, delta, user, reason, document=None):
    # Caller holds a row lock inside a transaction; never expose quantity as editable product data.
    delta = Decimal(delta)
    if delta == 0 or product.quantity + delta < 0 or product.quantity + delta > Decimal('99999999999.999'):
        raise ValidationError({'quantity': f'Stock insuffisant ou mouvement nul pour {product.name}.'})
    product.quantity += delta
    product.save(update_fields=['quantity', 'updated_at'])
    Movement.objects.create(organization=product.organization, product=product, delta=delta,
                           balance=product.quantity, user=user, reason=reason, document=document)

@transaction.atomic
def move_stock(organization, product_id, delta, user, reason):
    try:
        product = Product.objects.select_for_update().get(pk=product_id, organization=organization, active=True)
    except Product.DoesNotExist:
        raise ValidationError({'product': 'Produit actif introuvable dans votre organisation.'})
    change_stock(product, delta, user, reason)
    audit(user, organization, 'stock.movement', product.pk)
    return product

@transaction.atomic
def transition_document(organization, document_id, user, cancel=False):
    document = Document.objects.select_for_update().get(pk=document_id, organization=organization)
    if cancel and document.status == 'cancelled' or not cancel and document.status == 'completed':
        return document  # retry-safe transition, no duplicate stock movements
    if document.status == 'cancelled':
        raise ValidationError('Un document annulé ne peut pas être validé.')
    lines = list(document.lines.order_by('product_id'))
    if not lines:
        raise ValidationError('Ajoutez au moins une ligne.')
    products = {p.pk: p for p in Product.objects.select_for_update().filter(
        pk__in=[line.product_id for line in lines], organization=organization).order_by('pk')}
    for line in lines:
        product = products.get(line.product_id)
        if not product or not product.active and not cancel:
            raise ValidationError('Une ligne désigne un produit indisponible.')
        delta = line.quantity * (1 if document.kind == 'purchase' else -1)
        if cancel:
            delta = -delta
        if not cancel or document.status == 'completed':
            change_stock(product, delta, user, ('Annulation' if cancel else 'Validation') + ' ' + document.reference, document)
    document.status = 'cancelled' if cancel else 'completed'
    if cancel:
        document.cancelled_at = timezone.now()
    else:
        document.completed_at = timezone.now()
    document.save()
    audit(user, organization, 'document.cancel' if cancel else 'document.complete', document.pk)
    return document

def line_total(lines):
    # Currency totals: round each line to cents, then sum.
    return sum((line['quantity'] * line['unit_price']).quantize(Decimal('.01'), rounding=ROUND_HALF_UP) for line in lines)
