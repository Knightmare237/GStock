import csv
import io
import secrets
from datetime import timedelta
from PIL import Image, UnidentifiedImageError
from django.conf import settings
from django.contrib.auth import authenticate, get_user_model, login, logout, update_session_auth_hash
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.tokens import default_token_generator
from django.core.exceptions import ValidationError as DjangoValidationError
from django.core.files.base import ContentFile
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import F, Sum, DecimalField, ExpressionWrapper
from django.db.models.functions import TruncDate
from django.http import FileResponse, HttpResponse
from django.middleware.csrf import get_token
from django.utils import timezone
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from rest_framework import serializers, viewsets
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.permissions import AllowAny, BasePermission
from rest_framework.response import Response
from .models import Organization, Membership, Category, Product, Partner, Document, DocumentLine, Movement, AuditEvent, ContactMessage
from .serializers import CategorySerializer, ProductSerializer, PartnerSerializer, DocumentSerializer, MovementSerializer, AuditSerializer, ContactSerializer
from .auth import limit
from .services import audit, move_stock, transition_document

User = get_user_model()

def organization(request):
    try:
        return request.user.membership.organization
    except Membership.DoesNotExist:
        raise PermissionDenied('Aucune organisation attribuée à ce compte.')

def role(request):
    organization(request)
    return request.user.membership.role

def allowed(request, roles):
    if role(request) not in roles:
        raise PermissionDenied('Votre rôle ne permet pas cette opération.')

def session_data(user):
    member = user.membership
    return {'id': user.pk, 'name': user.first_name, 'email': user.email, 'role': member.role,
            'organization': {'id': member.organization_id, 'name': member.organization.name, 'currency': member.organization.currency}}

def password_check(password, user=None):
    try:
        validate_password(password, user)
    except DjangoValidationError as e:
        raise ValidationError({'password': e.messages})

@api_view(['GET'])
@permission_classes([AllowAny])
def csrf(request):
    return Response({'csrfToken': get_token(request), 'contact_available': bool(settings.CONTACT_EMAIL)})

@api_view(['GET', 'PATCH'])
def me(request):
    organization(request)
    if request.method == 'PATCH':
        name = serializers.CharField(max_length=150).run_validation(request.data.get('name'))
        email = serializers.EmailField(max_length=150).run_validation(request.data.get('email', request.user.email)).lower()
        if email != request.user.email:
            current = serializers.CharField(max_length=128).run_validation(request.data.get('current_password'))
            if not request.user.check_password(current):
                raise ValidationError({'current_password': 'Mot de passe actuel incorrect.'})
            if User.objects.filter(username=email).exclude(pk=request.user.pk).exists():
                raise ValidationError({'email': 'Adresse indisponible.'})
        request.user.first_name = name
        request.user.email = email
        request.user.username = email
        request.user.save(update_fields=['first_name', 'email', 'username'])
        audit(request.user, organization(request), 'account.profile')
    return Response(session_data(request.user))

@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    limit(request, 'register', 5, 3600)
    email = serializers.EmailField(max_length=150).run_validation(request.data.get('email')).lower()
    name = serializers.CharField(max_length=150).run_validation(request.data.get('name'))
    org_name = serializers.CharField(max_length=120).run_validation(request.data.get('organization'))
    password = serializers.CharField(max_length=128).run_validation(request.data.get('password'))
    password_check(password, User(username=email, email=email, first_name=name))
    with transaction.atomic():
        if User.objects.filter(username=email).exists():
            raise ValidationError({'email': 'Cette adresse est déjà associée à un compte.'})
        org = Organization.objects.create(name=org_name)
        user = User.objects.create_user(username=email, email=email, password=password, first_name=name)
        Membership.objects.create(user=user, organization=org, role='owner')
        audit(user, org, 'account.register')
    login(request, user)
    return Response(session_data(user), status=201)

@api_view(['POST'])
@permission_classes([AllowAny])
def sign_in(request):
    limit(request, 'login', 10)
    email = serializers.EmailField(max_length=150).run_validation(request.data.get('email')).lower()
    password = serializers.CharField(max_length=128).run_validation(request.data.get('password'))
    user = authenticate(request, username=email, password=password)
    if user is None or not Membership.objects.filter(user=user).exists():
        raise ValidationError('Identifiants incorrects ou compte indisponible.')
    login(request, user)
    audit(user, user.membership.organization, 'account.login')
    return Response(session_data(user))

@api_view(['POST'])
def sign_out(request):
    audit(request.user, organization(request), 'account.logout')
    logout(request)
    return Response(status=204)

@api_view(['POST'])
def change_password(request):
    limit(request, 'password')
    current = serializers.CharField(max_length=128).run_validation(request.data.get('current_password'))
    password = serializers.CharField(max_length=128).run_validation(request.data.get('password'))
    if not request.user.check_password(current):
        raise ValidationError({'current_password': 'Mot de passe actuel incorrect.'})
    password_check(password, request.user)
    request.user.set_password(password)
    request.user.save()
    update_session_auth_hash(request, request.user)
    audit(request.user, organization(request), 'account.password')
    return Response({'detail': 'Mot de passe modifié. Les autres sessions seront invalidées.'})

@api_view(['POST'])
@permission_classes([AllowAny])
def forgot_password(request):
    limit(request, 'reset', 5, 3600)
    email = serializers.EmailField(max_length=150).run_validation(request.data.get('email')).lower()
    user = User.objects.filter(username=email, is_active=True).first()
    if user:
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        link = f'{settings.WEB_URL}/reset-password/{uid}/{token}'
        send_mail('Réinitialiser votre mot de passe GStock', f'Pour choisir un nouveau mot de passe :\n{link}\nSi vous n’êtes pas à l’origine de cette demande, ignorez ce message.', settings.DEFAULT_FROM_EMAIL or None, [user.email])
    return Response({'detail': 'Si un compte actif correspond à cette adresse, un lien de réinitialisation sera envoyé.'})

@api_view(['POST'])
@permission_classes([AllowAny])
def reset_password(request):
    limit(request, 'reset-confirm', 10)
    try:
        uid = force_str(urlsafe_base64_decode(str(request.data.get('uid', ''))))
        user = User.objects.get(pk=uid, is_active=True)
    except (ValueError, TypeError, OverflowError, User.DoesNotExist):
        raise ValidationError('Lien invalide ou expiré.')
    token = str(request.data.get('token', ''))
    if not default_token_generator.check_token(user, token):
        raise ValidationError('Lien invalide ou expiré.')
    password = serializers.CharField(max_length=128).run_validation(request.data.get('password'))
    password_check(password, user)
    user.set_password(password)
    user.save()
    if Membership.objects.filter(user=user).exists():
        audit(user, user.membership.organization, 'account.reset')
    return Response({'detail': 'Mot de passe réinitialisé. Connectez-vous avec le nouveau mot de passe.'})

@api_view(['POST'])
@permission_classes([AllowAny])
def contact(request):
    limit(request, 'contact', 5, 3600)
    data = ContactSerializer(data=request.data)
    data.is_valid(raise_exception=True)
    values = dict(data.validated_data)
    if values.pop('website', ''):
        raise ValidationError('Ce formulaire ne peut pas être envoyé.')
    if not settings.CONTACT_EMAIL:
        return Response({'detail': 'Le service de contact n’est pas configuré. Aucun message n’a été envoyé.'}, status=503)
    # Persist only after SMTP accepted; no false success on mail errors.
    from django.core.mail import EmailMessage
    mail = EmailMessage('GStock : ' + values['subject'], f"{values['name']}\n{values['message']}",
                        settings.DEFAULT_FROM_EMAIL, [settings.CONTACT_EMAIL], reply_to=[values['email']])
    mail.send(fail_silently=False)
    ContactMessage.objects.create(**values)
    return Response({'detail': 'Votre message a été transmis.'}, status=201)

class TenantPermission(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_authenticated or not request.user.is_active:
            return False
        organization(request)
        if request.method in ('GET', 'HEAD', 'OPTIONS'):
            return True
        return role(request) in view.write_roles

class TenantViewSet(viewsets.ModelViewSet):
    permission_classes = [TenantPermission]
    write_roles = ('owner', 'manager')
    ordering_fields = ['id', 'name', 'created_at']
    ordering = ['-id']
    def get_queryset(self):
        queryset = self.queryset.filter(organization=organization(self.request))
        active = self.request.query_params.get('active')
        if active in ('true', 'false'):
            queryset = queryset.filter(active=active == 'true')
        return queryset
    @transaction.atomic
    def perform_create(self, serializer):
        obj = serializer.save(organization=organization(self.request))
        audit(self.request.user, organization(self.request), obj._meta.model_name + '.create', obj.pk)
    @transaction.atomic
    def perform_update(self, serializer):
        obj = serializer.save()
        audit(self.request.user, organization(self.request), obj._meta.model_name + '.update', obj.pk)
    def destroy(self, request, *args, **kwargs):
        return Response({'detail': 'Suppression définitive désactivée. Archivez avec active=false pour conserver l’historique.'}, status=405)

class CategoryViewSet(TenantViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    search_fields = ['name']

class PartnerViewSet(TenantViewSet):
    queryset = Partner.objects.all()
    serializer_class = PartnerSerializer
    search_fields = ['name', 'email', 'phone']
    write_roles = ('owner', 'manager', 'seller')
    def get_queryset(self):
        qs = super().get_queryset()
        kind = self.request.query_params.get('kind')
        return qs.filter(kind=kind) if kind else qs
    def perform_create(self, serializer):
        if role(self.request) == 'seller' and serializer.validated_data['kind'] != 'customer':
            raise PermissionDenied('Un vendeur peut uniquement gérer les clients.')
        super().perform_create(serializer)
    def perform_update(self, serializer):
        if role(self.request) == 'seller' and (serializer.instance.kind != 'customer' or serializer.validated_data.get('kind', 'customer') != 'customer'):
            raise PermissionDenied('Un vendeur peut uniquement gérer les clients.')
        super().perform_update(serializer)

class ProductViewSet(TenantViewSet):
    queryset = Product.objects.select_related('category')
    serializer_class = ProductSerializer
    search_fields = ['name', 'sku', 'barcode']
    ordering_fields = ['name', 'sku', 'quantity', 'purchase_price', 'sale_price', 'created_at']
    @action(detail=False, methods=['POST'], url_path='import')
    def import_products(self, request):
        from .product_import import validate_import, commit_import
        allowed(request, ['owner', 'manager'])
        limit(request, 'product-import', 30)
        mode = request.data.get('mode', 'preview')
        if mode not in ('preview', 'commit'):
            raise ValidationError('Mode invalide.')
        result, validated = validate_import(request.FILES.get('file'), request)
        if mode == 'commit':
            if not result['valid']:
                return Response(result, status=400)
            commit_import(validated, request)
            return Response({'created': result['count']}, status=201)
        return Response(result)

    @action(detail=False, methods=['GET'], url_path='import-template')
    def import_template(self, request):
        from .product_import import HEADERS
        allowed(request, ['owner', 'manager'])
        stream = io.StringIO()
        writer = csv.writer(stream, delimiter=';')
        writer.writerow(HEADERS)
        writer.writerow(['EXEMPLE-001', 'Produit exemple', '', '', '001234567890', '12,50', '20', '10', '2', 'unité', 'oui'])
        response = HttpResponse('\ufeff' + stream.getvalue(), content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = 'attachment; filename="gstock-modele-produits.csv"'
        response['Cache-Control'] = 'private, no-store'
        return response

    def get_queryset(self):
        qs = super().get_queryset()
        category = self.request.query_params.get('category')
        if category:
            try:
                qs = qs.filter(category_id=int(category))
            except ValueError:
                raise ValidationError({'category': 'Identifiant invalide.'})
        if self.request.query_params.get('low_stock') == 'true':
            qs = qs.filter(quantity__lte=F('minimum_stock'), active=True)
        return qs
    @action(detail=True, methods=['GET', 'POST', 'DELETE'])
    @transaction.atomic
    def image(self, request, pk=None):
        product = self.get_object()
        if request.method == 'GET':
            if not product.image:
                return Response({'detail': 'Aucune image.'}, status=404)
            response = FileResponse(product.image.open('rb'), content_type='image/webp')
            response['Cache-Control'] = 'private, no-store'
            return response
        product = Product.objects.select_for_update().get(pk=product.pk, organization=organization(request))
        if request.method == 'DELETE':
            product.image.delete(save=True)
            audit(request.user, organization(request), 'product.image.delete', product.pk)
            return Response(status=204)
        uploaded = request.FILES.get('image')
        if not uploaded or uploaded.size > 5 * 1024 * 1024:
            raise ValidationError({'image': 'Image obligatoire, taille maximale 5 Mo.'})
        try:
            source = Image.open(uploaded)
            if source.format not in ('JPEG', 'PNG', 'WEBP') or source.width * source.height > 20_000_000:
                raise ValueError()
            source.load()
            source.thumbnail((1600, 1600))
            output = io.BytesIO()
            source.convert('RGB').save(output, format='WEBP', quality=85)
        except (ValueError, OSError, UnidentifiedImageError, Image.DecompressionBombError):
            raise ValidationError({'image': 'Image invalide. Formats acceptés : JPEG, PNG, WebP ; maximum 20 mégapixels.'})
        product.image.save('image.webp', ContentFile(output.getvalue()))
        audit(request.user, organization(request), 'product.image', product.pk)
        return Response(self.get_serializer(product).data)

class DocumentViewSet(TenantViewSet):
    queryset = Document.objects.select_related('partner').prefetch_related('lines__product')
    serializer_class = DocumentSerializer
    search_fields = ['reference', 'partner__name']
    ordering_fields = ['created_at', 'total', 'status']
    write_roles = ('owner', 'manager', 'seller')
    def get_queryset(self):
        qs = self.queryset.filter(organization=organization(self.request))
        for field in ('kind', 'status'):
            if self.request.query_params.get(field):
                qs = qs.filter(**{field: self.request.query_params[field]})
        if role(self.request) == 'seller':
            qs = qs.filter(kind='sale')
        return qs
    def check_kind(self, kind):
        if role(self.request) == 'seller' and kind != 'sale':
            raise PermissionDenied('Un vendeur peut uniquement gérer les ventes.')
    @transaction.atomic
    def perform_create(self, serializer):
        self.check_kind(serializer.validated_data['kind'])
        document = serializer.save(organization=organization(self.request), created_by=self.request.user)
        audit(self.request.user, organization(self.request), 'document.create', document.pk)
    def perform_update(self, serializer):
        self.check_kind(serializer.instance.kind)
        super().perform_update(serializer)
    @action(detail=True, methods=['POST'])
    def complete(self, request, pk=None):
        document = self.get_object()
        result = transition_document(organization(request), document.pk, request.user)
        return Response(self.get_serializer(result).data)
    @action(detail=True, methods=['POST'])
    def cancel(self, request, pk=None):
        document = self.get_object()
        result = transition_document(organization(request), document.pk, request.user, cancel=True)
        return Response(self.get_serializer(result).data)

class MovementViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = MovementSerializer
    search_fields = ['product__name', 'product__sku', 'reason']
    ordering_fields = ['created_at']
    def get_queryset(self):
        return Movement.objects.filter(organization=organization(self.request)).select_related('product', 'user')
    @action(detail=False, methods=['POST'])
    def adjust(self, request):
        allowed(request, ('owner', 'manager'))
        product_id = serializers.IntegerField(min_value=1).run_validation(request.data.get('product'))
        delta = serializers.DecimalField(max_digits=14, decimal_places=3).run_validation(request.data.get('delta'))
        reason = serializers.CharField(max_length=250, min_length=3).run_validation(request.data.get('reason'))
        product = move_stock(organization(request), product_id, delta, request.user, reason)
        return Response(ProductSerializer(product, context={'request': request}).data, status=201)

class AuditViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = AuditSerializer
    def get_queryset(self):
        return AuditEvent.objects.filter(organization=organization(self.request)).select_related('user')

@api_view(['GET', 'PATCH'])
def organization_settings(request):
    org = organization(request)
    if request.method == 'PATCH':
        allowed(request, ('owner',))
        name = serializers.CharField(max_length=120).run_validation(request.data.get('name'))
        currency = serializers.ChoiceField(choices=['XAF', 'XOF', 'EUR', 'USD', 'GBP']).run_validation(request.data.get('currency'))
        if currency != org.currency and Document.objects.filter(organization=org).exists():
            raise ValidationError({'currency': 'La devise ne peut plus changer après création d’un document.'})
        org.name, org.currency = name, currency
        org.save()
        audit(request.user, org, 'organization.update')
    return Response({'id': org.pk, 'name': org.name, 'currency': org.currency})

@api_view(['GET', 'POST'])
def members(request):
    allowed(request, ('owner',))
    org = organization(request)
    if request.method == 'POST':
        email = serializers.EmailField(max_length=150).run_validation(request.data.get('email')).lower()
        name = serializers.CharField(max_length=150).run_validation(request.data.get('name'))
        new_role = serializers.ChoiceField(choices=['manager', 'seller', 'accountant', 'reader']).run_validation(request.data.get('role'))
        # Server-generated temporary password is never disclosed. Email reset link activates access.
        if not settings.DEFAULT_FROM_EMAIL and not settings.DEBUG:
            raise ValidationError('Service email non configuré.')
        with transaction.atomic():
            if User.objects.filter(username=email).exists():
                raise ValidationError({'email': 'Adresse indisponible. Le transfert de comptes entre organisations n’est pas autorisé.'})
            user = User.objects.create_user(username=email, email=email, first_name=name, password=secrets.token_urlsafe(40))
            Membership.objects.create(user=user, organization=org, role=new_role)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            token = default_token_generator.make_token(user)
            send_mail('Votre accès GStock', f'{request.user.first_name} vous invite dans {org.name}.\nChoisissez votre mot de passe :\n{settings.WEB_URL}/reset-password/{uid}/{token}', settings.DEFAULT_FROM_EMAIL or None, [email])
            audit(request.user, org, 'member.invite', user.pk)
    return Response([{'id': m.user_id, 'name': m.user.first_name, 'email': m.user.email, 'role': m.role, 'active': m.user.is_active}
                     for m in Membership.objects.filter(organization=org).select_related('user')])

@api_view(['PATCH'])
def member_update(request, pk):
    allowed(request, ('owner',))
    if pk == request.user.pk:
        raise ValidationError('Vous ne pouvez pas désactiver votre propre compte ni modifier votre propre rôle.')
    from django.shortcuts import get_object_or_404
    member = get_object_or_404(Membership, organization=organization(request), user_id=pk)
    new_role = serializers.ChoiceField(choices=['manager', 'seller', 'accountant', 'reader']).run_validation(request.data.get('role', member.role))
    active = serializers.BooleanField().run_validation(request.data.get('active', member.user.is_active))
    with transaction.atomic():
        member.role = new_role
        member.save()
        member.user.is_active = active
        member.user.save(update_fields=['is_active'])
        audit(request.user, organization(request), 'member.update', pk)
    return Response({'detail': 'Accès mis à jour.'})

def period(request):
    from datetime import date, datetime, time
    try:
        start = date.fromisoformat(request.query_params.get('start', (timezone.now().date()-timedelta(days=29)).isoformat()))
        end = date.fromisoformat(request.query_params.get('end', timezone.now().date().isoformat()))
    except ValueError:
        raise ValidationError('Dates invalides ; format attendu AAAA-MM-JJ.')
    if end < start or (end-start).days > 366:
        raise ValidationError('Période invalide ; maximum 367 jours.')
    return start, end

@api_view(['GET'])
def dashboard(request):
    org = organization(request)
    start, end = period(request)
    products = Product.objects.filter(organization=org, active=True)
    docs = Document.objects.filter(organization=org, status='completed', completed_at__date__range=(start, end))
    movements = Movement.objects.filter(organization=org, created_at__date__range=(start, end)).select_related('product', 'user')
    stock_value = products.aggregate(value=Sum(ExpressionWrapper(F('quantity')*F('purchase_price'), output_field=DecimalField(max_digits=20, decimal_places=2))))['value'] or 0
    sales = docs.filter(kind='sale')
    purchases = docs.filter(kind='purchase')
    series = list(sales.annotate(day=TruncDate('completed_at')).values('day').annotate(total=Sum('total')).order_by('day'))
    tops = list(DocumentLine.objects.filter(document__in=sales).values('product_id', 'product__name').annotate(quantity_sold=Sum('quantity'), revenue=Sum(ExpressionWrapper(F('quantity')*F('unit_price'), output_field=DecimalField(max_digits=20, decimal_places=2)))).order_by('-quantity_sold')[:5])
    for item in tops:
        item['quantity'] = item.pop('quantity_sold')
    return Response({'start': start, 'end': end, 'product_count': products.count(), 'stock_value': stock_value,
       'low_stock_count': products.filter(quantity__lte=F('minimum_stock')).count(), 'out_of_stock_count': products.filter(quantity=0).count(),
       'sales_total': sales.aggregate(total=Sum('total'))['total'] or 0, 'purchases_total': purchases.aggregate(total=Sum('total'))['total'] or 0,
       'series': series, 'top_products': tops, 'alerts': ProductSerializer(products.filter(quantity__lte=F('minimum_stock'))[:10], many=True, context={'request': request}).data,
       'movements': MovementSerializer(movements[:10], many=True).data,
       'activity': AuditSerializer(AuditEvent.objects.filter(organization=org).select_related('user')[:10], many=True).data})

@api_view(['GET'])
def export(request):
    org = organization(request)
    allowed(request, ('owner', 'manager', 'accountant'))
    kind = request.query_params.get('kind', 'products')
    if kind == 'products':
        header = ['Référence', 'Produit', 'Catégorie', 'Quantité', 'Unité', 'Prix achat', 'Prix vente', 'Seuil', 'Actif']
        rows = [[p.sku,p.name,p.category.name if p.category else '',p.quantity,p.unit,p.purchase_price,p.sale_price,p.minimum_stock,p.active]
                for p in Product.objects.filter(organization=org).select_related('category').order_by('sku')]
    elif kind == 'movements':
        start, end = period(request)
        header = ['Date', 'Produit', 'Variation', 'Solde', 'Motif', 'Utilisateur']
        rows = [[m.created_at.isoformat(),m.product.name,m.delta,m.balance,m.reason,m.user.first_name]
                for m in Movement.objects.filter(organization=org, created_at__date__range=(start,end)).select_related('product','user')]
    elif kind in ('sale','purchase'):
        start, end = period(request)
        header = ['Référence', 'Partenaire', 'Statut', 'Total', 'Devise', 'Date']
        rows = [[d.reference,d.partner.name if d.partner else '',d.status,d.total,org.currency,d.created_at.isoformat()]
                for d in Document.objects.filter(organization=org, kind=kind, created_at__date__range=(start,end)).select_related('partner')]
    else:
        raise ValidationError('Export inconnu.')
    # Protect spreadsheet formula injection from user-controlled values.
    def safe(value):
        s = str(value)
        return "'"+s if isinstance(value, str) and s.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')) else value
    rows = [[safe(v) for v in row] for row in rows]
    if request.query_params.get('format') == 'xlsx':
        from openpyxl import Workbook
        book = Workbook()
        sheet = book.active
        sheet.title = 'GStock'
        sheet.append(header)
        for row in rows:
            sheet.append(row)
        sheet.freeze_panes = 'A2'
        sheet.auto_filter.ref = sheet.dimensions
        for col in sheet.columns:
            sheet.column_dimensions[col[0].column_letter].width = min(50, max(15, max(len(str(c.value or '')) for c in col)+2))
        buffer = io.BytesIO()
        book.save(buffer)
        response = HttpResponse(buffer.getvalue(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        suffix = 'xlsx'
    else:
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response.write('\ufeff')
        writer = csv.writer(response, delimiter=';')
        writer.writerow(header)
        writer.writerows(rows)
        suffix = 'csv'
    response['Content-Disposition'] = f'attachment; filename="gstock-{kind}.{suffix}"'
    audit(request.user, org, 'report.export', kind)
    return response
