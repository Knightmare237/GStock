import io
from decimal import Decimal
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.core import mail
from django.test import TestCase, override_settings
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from rest_framework.test import APIClient
from PIL import Image
from django.core.files.uploadedfile import SimpleUploadedFile
from .models import Organization, Membership, Product, Category, Movement, Document

User = get_user_model()

class WebTests(TestCase):
    def setUp(self):
        self.org = Organization.objects.create(name='Entreprise A')
        self.other_org = Organization.objects.create(name='Entreprise B')
        self.user = User.objects.create_user(username='owner@example.test', email='owner@example.test', password='Gstock!2026-secure', first_name='Alice')
        self.other = User.objects.create_user(username='other@example.test', password='Gstock!2026-secure')
        Membership.objects.create(user=self.user, organization=self.org, role='owner')
        Membership.objects.create(user=self.other, organization=self.other_org, role='owner')
        self.client = APIClient()
        self.client.force_login(self.user)
        self.product = Product.objects.create(organization=self.org, sku='A1', name='Produit A', quantity=10, purchase_price=5, sale_price=12)
        self.other_product = Product.objects.create(organization=self.other_org, sku='B1', name='Produit B', quantity=99)

    def post(self, path, data):
        return self.client.post('/api/v1/' + path, data, format='json')

    def document(self, kind='sale', quantity='3', lines=None):
        response = self.post('documents/', {'kind':kind,'lines':lines or [{'product':self.product.pk,'quantity':quantity,'unit_price':'12.50'}]})
        self.assertEqual(response.status_code, 201, response.data)
        return response.data['id']

    def test_anonymous_cannot_access_business_endpoints(self):
        self.client.logout()
        for path in ['products/','categories/','partners/','documents/','movements/','dashboard/','export/','members/']:
            self.assertIn(self.client.get('/api/v1/'+path).status_code, [401,403])

    def test_organization_isolation_lists_and_objects(self):
        response = self.client.get('/api/v1/products/')
        self.assertEqual(response.data['count'], 1)
        self.assertEqual(self.client.get(f'/api/v1/products/{self.other_product.pk}/').status_code,404)
        self.assertEqual(self.client.patch(f'/api/v1/products/{self.other_product.pk}/', {'name':'Intrusion'},format='json').status_code,404)

    def test_forged_organization_ignored(self):
        response=self.post('products/',{'sku':'NEW','name':'Nouveau','organization':self.other_org.pk})
        self.assertEqual(response.status_code,201)
        self.assertEqual(Product.objects.get(pk=response.data['id']).organization_id,self.org.pk)

    def test_cross_organization_category_rejected(self):
        category=Category.objects.create(organization=self.other_org,name='Privée')
        response=self.post('products/',{'sku':'NEW','name':'Nouveau','category':category.pk})
        self.assertEqual(response.status_code,400)

    def test_product_initial_stock_traced_and_quantity_not_editable(self):
        response=self.post('products/',{'sku':'new','name':'Produit','initial_quantity':'2.500','purchase_price':'1'})
        self.assertEqual(response.status_code,201,response.data)
        p=Product.objects.get(pk=response.data['id'])
        self.assertEqual(p.sku,'NEW');self.assertEqual(p.quantity,Decimal('2.500'))
        self.assertEqual(Movement.objects.get(product=p).reason,'Stock initial')
        self.client.patch(f'/api/v1/products/{p.pk}/',{'quantity':99},format='json')
        p.refresh_from_db();self.assertEqual(p.quantity,Decimal('2.500'))
        self.assertEqual(self.client.patch(f'/api/v1/products/{p.pk}/',{'initial_quantity':99},format='json').status_code,400)

    def test_unique_sku_per_organization(self):
        self.assertEqual(self.post('products/',{'sku':'A1','name':'Doublon'}).status_code,409)
        self.client.force_login(self.other)
        self.assertEqual(self.post('products/',{'sku':'A1','name':'Autorisé'}).status_code,201)

    def test_prices_and_stock_validated(self):
        self.assertEqual(self.post('products/',{'sku':'NEG','name':'Test','purchase_price':'-1'}).status_code,400)
        self.assertEqual(self.post('movements/adjust/',{'product':self.product.pk,'delta':'-11','reason':'Sortie'}).status_code,400)
        self.product.refresh_from_db();self.assertEqual(self.product.quantity,10)
        self.assertFalse(Movement.objects.exists())

    def test_manual_movement_trace(self):
        response=self.post('movements/adjust/',{'product':self.product.pk,'delta':'-2','reason':'Inventaire corrigé'})
        self.assertEqual(response.status_code,201)
        m=Movement.objects.get();self.assertEqual(m.balance,8);self.assertEqual(m.user,self.user)
        self.assertEqual(self.client.delete(f'/api/v1/movements/{m.pk}/').status_code,405)

    def test_sale_atomic_validation_retry_and_cancel(self):
        pk=self.document()
        self.product.refresh_from_db();self.assertEqual(self.product.quantity,10)
        self.assertEqual(self.post(f'documents/{pk}/complete/',{}).status_code,200)
        self.assertEqual(self.post(f'documents/{pk}/complete/',{}).status_code,200)
        self.product.refresh_from_db();self.assertEqual(self.product.quantity,7)
        self.assertEqual(Movement.objects.count(),1)
        self.assertEqual(Document.objects.get(pk=pk).total,Decimal('37.50'))
        self.assertEqual(self.post(f'documents/{pk}/cancel/',{}).status_code,200)
        self.assertEqual(self.post(f'documents/{pk}/cancel/',{}).status_code,200)
        self.product.refresh_from_db();self.assertEqual(self.product.quantity,10)
        self.assertEqual(Movement.objects.count(),2)
        self.assertEqual(self.post(f'documents/{pk}/complete/',{}).status_code,400)

    def test_purchase_receipt(self):
        pk=self.document('purchase','5')
        self.assertEqual(self.post(f'documents/{pk}/complete/',{}).status_code,200)
        self.product.refresh_from_db();self.assertEqual(self.product.quantity,15)

    def test_consumed_purchase_cannot_be_cancelled(self):
        pk=self.document('purchase','20');self.post(f'documents/{pk}/complete/',{})
        self.post('movements/adjust/',{'product':self.product.pk,'delta':'-25','reason':'Consommation'})
        self.assertEqual(self.post(f'documents/{pk}/cancel/',{}).status_code,400)
        self.assertEqual(Document.objects.get(pk=pk).status,'completed')

    def test_partial_sale_failure_rolls_back_every_line(self):
        p2=Product.objects.create(organization=self.org,sku='A2',name='Vide',quantity=0)
        pk=self.document(lines=[{'product':self.product.pk,'quantity':2,'unit_price':1},{'product':p2.pk,'quantity':1,'unit_price':1}])
        self.assertEqual(self.post(f'documents/{pk}/complete/',{}).status_code,400)
        self.product.refresh_from_db();self.assertEqual(self.product.quantity,10)
        self.assertFalse(Movement.objects.exists());self.assertEqual(Document.objects.get(pk=pk).status,'draft')

    def test_cross_organization_document_line_rejected(self):
        response=self.post('documents/',{'kind':'sale','lines':[{'product':self.other_product.pk,'quantity':1,'unit_price':1}]})
        self.assertEqual(response.status_code,400)

    def test_duplicate_document_lines_rejected(self):
        line={'product':self.product.pk,'quantity':1,'unit_price':1}
        self.assertEqual(self.post('documents/',{'kind':'sale','lines':[line,line]}).status_code,400)

    def test_completed_document_immutable(self):
        pk=self.document();self.post(f'documents/{pk}/complete/',{})
        self.assertEqual(self.client.patch(f'/api/v1/documents/{pk}/',{'notes':'Changement'},format='json').status_code,400)

    def test_reader_write_and_export_denied(self):
        self.user.membership.role='reader';self.user.membership.save()
        self.assertEqual(self.post('products/',{'sku':'NEW','name':'Interdit'}).status_code,403)
        self.assertEqual(self.post('movements/adjust/',{'product':self.product.pk,'delta':1,'reason':'Entrée'}).status_code,403)
        self.assertEqual(self.client.get('/api/v1/export/').status_code,403)

    def test_seller_purchase_denied_sales_allowed(self):
        self.user.membership.role='seller';self.user.membership.save()
        self.document('sale')
        response=self.post('documents/',{'kind':'purchase','lines':[{'product':self.product.pk,'quantity':1,'unit_price':1}]})
        self.assertEqual(response.status_code,403)
        self.assertEqual(self.post('partners/',{'kind':'supplier','name':'Interdit'}).status_code,403)

    def test_archive_category_dependency(self):
        category=Category.objects.create(organization=self.org,name='Catégorie')
        self.product.category=category;self.product.save()
        self.assertEqual(self.client.patch(f'/api/v1/categories/{category.pk}/',{'active':False},format='json').status_code,400)
        self.client.patch(f'/api/v1/products/{self.product.pk}/',{'active':False},format='json')
        self.assertEqual(self.client.patch(f'/api/v1/categories/{category.pk}/',{'active':False},format='json').status_code,200)

    def test_pagination_search_filters(self):
        for i in range(24):Product.objects.create(organization=self.org,sku=f'P{i}',name=f'Recherche {i}')
        response=self.client.get('/api/v1/products/?search=Recherche&page=2')
        self.assertEqual(response.data['count'],24);self.assertEqual(len(response.data['results']),4)
        self.assertEqual(self.client.get('/api/v1/products/?active=false').data['count'],0)

    def test_dashboard_and_exports_real_values(self):
        pk=self.document();self.post(f'documents/{pk}/complete/',{})
        response=self.client.get('/api/v1/dashboard/')
        self.assertEqual(response.data['product_count'],1);self.assertEqual(response.data['sales_total'],Decimal('37.50'))
        self.assertEqual(response.data['stock_value'],Decimal('35'))
        export=self.client.get('/api/v1/export/?kind=products')
        self.assertNotIn('Produit B',export.content.decode('utf-8'))
        self.assertEqual(self.client.get('/api/v1/export/?format=xlsx').status_code,200)

    def test_formula_injection_export(self):
        self.product.name='=HYPERLINK("evil")';self.product.save()
        content=self.client.get('/api/v1/export/').content.decode('utf-8')
        self.assertIn("'=HYPERLINK",content)

    def test_password_reset_single_use_and_login(self):
        uid=urlsafe_base64_encode(force_bytes(self.user.pk));token=default_token_generator.make_token(self.user)
        self.client.logout()
        payload={'uid':uid,'token':token,'password':'Changed!2026-secret'}
        self.assertEqual(self.post('auth/reset-password/',payload).status_code,200)
        self.assertEqual(self.post('auth/reset-password/',payload).status_code,400)
        self.assertEqual(self.post('auth/login/',{'email':self.user.email,'password':payload['password']}).status_code,200)

    def test_deactivated_session_rejected(self):
        self.user.is_active=False;self.user.save()
        self.assertEqual(self.client.get('/api/v1/products/').status_code,403)

    def test_members_isolation_and_self_protection(self):
        self.assertEqual(self.client.patch(f'/api/v1/members/{self.other.pk}/',{'active':False},format='json').status_code,404)
        self.assertEqual(self.client.patch(f'/api/v1/members/{self.user.pk}/',{'active':False},format='json').status_code,400)

    def test_dates_invalid(self):
        self.assertEqual(self.client.get('/api/v1/dashboard/?start=incorrect').status_code,400)

    @override_settings(EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',CONTACT_EMAIL='support@example.test',DEFAULT_FROM_EMAIL='web@example.test')
    def test_contact_and_antispam(self):
        self.client.logout()
        values={'name':'Alice','email':'alice@example.test','subject':'Question','message':'Un message assez long pour être valide.'}
        self.assertEqual(self.post('contact/',values).status_code,201)
        self.assertEqual(len(mail.outbox),1)
        self.assertEqual(self.post('contact/',{**values,'website':'spam'}).status_code,400)

    def test_contact_unconfigured(self):
        self.client.logout()
        self.assertEqual(self.post('contact/',{'name':'Alice','email':'a@example.test','subject':'Question','message':'Un message assez long.'}).status_code,503)

    def test_csrf_login_and_register(self):
        client=APIClient(enforce_csrf_checks=True)
        values={'email':self.user.email,'password':'Gstock!2026-secure'}
        self.assertEqual(client.post('/api/v1/auth/login/',values,format='json').status_code,403)
        token=client.get('/api/v1/csrf/').data['csrfToken']
        self.assertEqual(client.post('/api/v1/auth/login/',values,format='json',HTTP_X_CSRFTOKEN=token).status_code,200)
        self.assertEqual(client.post('/api/v1/auth/logout/',{},format='json').status_code,403)

    def test_register_real_password_hash_and_org(self):
        self.client.logout()
        response=self.post('auth/register/',{'email':'new@example.test','name':'Bob','organization':'Nouveau','password':'Random!2026-secure'})
        self.assertEqual(response.status_code,201,response.data)
        user=User.objects.get(username='new@example.test')
        self.assertNotEqual(user.password,'Random!2026-secure');self.assertTrue(user.check_password('Random!2026-secure'))
        self.assertEqual(user.membership.role,'owner')

    def test_login_throttled(self):
        self.client.logout()
        for _ in range(10):self.post('auth/login/',{'email':'nobody@example.test','password':'bad'})
        self.assertEqual(self.post('auth/login/',{'email':'nobody@example.test','password':'bad'}).status_code,429)

    def test_profile_email_requires_current_password(self):
        response = self.client.patch('/api/v1/auth/me/', {'name': 'Alice', 'email': 'new-mail@example.test'}, format='json')
        self.assertEqual(response.status_code, 400)
        response = self.client.patch('/api/v1/auth/me/', {'name': 'Alice', 'email': 'new-mail@example.test', 'current_password': 'Gstock!2026-secure'}, format='json')
        self.assertEqual(response.status_code, 200)
        self.user.refresh_from_db()
        self.assertEqual(self.user.username, 'new-mail@example.test')

    def test_image_invalid_and_cross_org(self):
        fake=SimpleUploadedFile('x.png',b'not an image',content_type='image/png')
        self.assertEqual(self.client.post(f'/api/v1/products/{self.product.pk}/image/',{'image':fake},format='multipart').status_code,400)
        self.assertEqual(self.client.get(f'/api/v1/products/{self.other_product.pk}/image/').status_code,404)

    def test_valid_image_reencoded_and_private(self):
        import tempfile
        with tempfile.TemporaryDirectory() as directory, override_settings(MEDIA_ROOT=directory):
            image=io.BytesIO()
            Image.new('RGB',(20,20),'blue').save(image,format='PNG')
            file=SimpleUploadedFile('image.png',image.getvalue(),content_type='image/png')
            response=self.client.post(f'/api/v1/products/{self.product.pk}/image/',{'image':file},format='multipart')
            self.assertEqual(response.status_code,200,response.data)
            response=self.client.get(f'/api/v1/products/{self.product.pk}/image/')
            self.assertEqual(response['Content-Type'],'image/webp')
            response.close()
            self.client.logout()
            self.assertEqual(self.client.get(f'/api/v1/products/{self.product.pk}/image/').status_code,403)

    def test_product_metadata_cannot_overwrite_recent_stock(self):
        from types import SimpleNamespace
        from .serializers import ProductSerializer
        from .services import move_stock
        stale=Product.objects.get(pk=self.product.pk)
        serializer=ProductSerializer(stale,data={'name':'Nouveau nom'},partial=True,context={'request':SimpleNamespace(user=self.user)})
        self.assertTrue(serializer.is_valid(),serializer.errors)
        move_stock(self.org,self.product.pk,-2,self.user,'Sortie concurrente')
        serializer.save()
        self.product.refresh_from_db()
        self.assertEqual(self.product.quantity,Decimal('8'))

