from django.db import IntegrityError
from rest_framework.views import exception_handler as drf_handler
from rest_framework.response import Response

def exception_handler(exc, context):
    response = drf_handler(exc, context)
    if response is not None:
        return response
    if isinstance(exc, IntegrityError):
        return Response({'detail': 'Conflit : doublon ou contrainte métier. Vérifiez les informations.'}, status=409)
    return None
