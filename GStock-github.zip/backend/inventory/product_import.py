"""Bounded catalogue import. Preview and commit use the same validation."""
import csv
import io
import unicodedata
import zipfile
from pathlib import Path
from django.db import transaction
from rest_framework.exceptions import ValidationError
from openpyxl import load_workbook
from .models import Category, Product
from .serializers import ProductSerializer
from .services import audit

HEADERS = ['sku', 'name', 'description', 'category', 'barcode', 'purchase_price',
           'sale_price', 'initial_quantity', 'minimum_stock', 'unit', 'active']
ALIASES = dict(zip(['reference', 'produit', 'description', 'categorie', 'code_barres',
                   'prix_achat', 'prix_vente', 'quantite', 'seuil', 'unite', 'actif'], HEADERS))
MAX_ROWS = 1000
MAX_BYTES = 5 * 1024 * 1024

def header(value):
    value = ''.join(c for c in unicodedata.normalize('NFKD', str(value or '')) if not unicodedata.combining(c))
    value = value.strip().lower().replace(' ', '_').replace('-', '_')
    return ALIASES.get(value, value)

def read_rows(upload):
    if not upload or upload.size > MAX_BYTES:
        raise ValidationError('Choisissez un fichier CSV ou XLSX de 5 Mo maximum.')
    raw = upload.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValidationError('Le fichier dépasse 5 Mo.')
    extension = Path(upload.name).suffix.lower()
    if extension == '.csv':
        try:
            content = raw.decode('utf-8-sig')
            delimiter = csv.Sniffer().sniff(content[:8192], delimiters=';,\t').delimiter
            reader = csv.reader(io.StringIO(content, newline=''), delimiter=delimiter, strict=True)
            rows = []
            for row in reader:
                rows.append((reader.line_num, row))
                if len(rows) > MAX_ROWS + 1:
                    raise ValidationError('Le fichier est limité à 1 000 lignes de produits.')
        except (UnicodeDecodeError, csv.Error):
            raise ValidationError('CSV invalide : utilisez UTF-8 et un séparateur point-virgule, virgule ou tabulation.')
    elif extension == '.xlsx':
        workbook = None
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                if len(archive.infolist()) > 1000 or sum(info.file_size for info in archive.infolist()) > 30 * 1024 * 1024:
                    raise ValidationError('Classeur trop volumineux après décompression.')
            workbook = load_workbook(io.BytesIO(raw), read_only=True, data_only=False, keep_links=False)
            sheet = workbook.worksheets[0]
            if sheet.max_row and sheet.max_row > MAX_ROWS + 1:
                raise ValidationError('Le classeur est limité à 1 000 lignes de produits.')
            if sheet.max_column and sheet.max_column > len(HEADERS):
                raise ValidationError('Le classeur contient trop de colonnes.')
            rows = []
            for number, cells in enumerate(sheet.iter_rows(max_row=MAX_ROWS + 2, max_col=len(HEADERS) + 1), 1):
                if any(cell.data_type == 'f' for cell in cells):
                    raise ValidationError(f'Ligne {number} : remplacez les formules par des valeurs.')
                values = [cell.value for cell in cells]
                while values and values[-1] is None:
                    values.pop()
                if values:
                    if number > MAX_ROWS + 1:
                        raise ValidationError('Le classeur est limité à 1 000 lignes de produits.')
                    rows.append((number, values))
        except ValidationError:
            raise
        except Exception:
            raise ValidationError('Classeur XLSX illisible ou invalide.')
        finally:
            if workbook:
                workbook.close()
    else:
        raise ValidationError('Formats acceptés : CSV et XLSX uniquement.')
    if not rows:
        raise ValidationError('Le fichier est vide.')
    columns = [header(value) for value in rows[0][1]]
    if len(set(columns)) != len(columns) or any(c not in HEADERS for c in columns):
        raise ValidationError('Colonnes inconnues ou répétées. Utilisez le modèle proposé.')
    if not {'sku', 'name'}.issubset(columns):
        raise ValidationError('Les colonnes sku et name (référence et produit) sont obligatoires.')
    products = [(line, values) for line, values in rows[1:] if any(str(v or '').strip() for v in values)]
    if not products:
        raise ValidationError('Le fichier ne contient aucun produit.')
    return columns, products

def validate_import(upload, request):
    columns, rows = read_rows(upload)
    org = request.user.membership.organization
    existing = set(Product.objects.filter(organization=org).values_list('sku', flat=True))
    categories = {}
    for category in Category.objects.filter(organization=org, active=True):
        categories.setdefault(category.name.casefold(), []).append(category.pk)
    seen, errors, validated, preview = set(), [], [], []
    for line, values in rows:
        if len(values) > len(columns):
            errors.append({'line': line, 'field': 'fichier', 'message': 'Trop de cellules sur cette ligne.'})
            continue
        data = {key: str(value).strip() for key, value in zip(columns, values) if value is not None and str(value).strip()}
        data.setdefault('purchase_price', '0')
        data.setdefault('sale_price', '0')
        data.setdefault('unit', 'unité')
        sku = data.get('sku', '').upper()
        if sku in seen or sku in existing:
            errors.append({'line': line, 'field': 'sku', 'message': 'Référence déjà utilisée dans ce fichier ou votre catalogue.'})
        seen.add(sku)
        category_name = data.pop('category', '')
        if category_name:
            matches = categories.get(category_name.casefold(), [])
            if len(matches) != 1:
                errors.append({'line': line, 'field': 'category', 'message': 'Catégorie active introuvable ou ambiguë. Créez-la avant l’import.'})
            else:
                data['category'] = matches[0]
        for key in ('purchase_price', 'sale_price', 'initial_quantity', 'minimum_stock'):
            if key in data:
                data[key] = data[key].replace('\u202f', '').replace('\xa0', '').replace(' ', '').replace(',', '.')
        if 'active' in data:
            flag = data['active'].casefold()
            if flag in ('oui', 'true', '1'):
                data['active'] = True
            elif flag in ('non', 'false', '0'):
                data['active'] = False
            else:
                errors.append({'line': line, 'field': 'active', 'message': 'Utilisez oui/non, true/false ou 1/0.'})
                data.pop('active')
        serializer = ProductSerializer(data=data, context={'request': request})
        if serializer.is_valid():
            validated.append(serializer)
            if len(preview) < 20:
                preview.append({'line': line, 'sku': sku, 'name': data.get('name'), 'category': category_name,
                                'initial_quantity': str(serializer.validated_data['initial_quantity'])})
        else:
            for field, messages in serializer.errors.items():
                errors.append({'line': line, 'field': field, 'message': ' '.join(map(str, messages))})
    return {'valid': not errors, 'count': len(rows), 'preview': preview,
            'errors': errors[:100], 'error_count': len(errors)}, validated

@transaction.atomic
def commit_import(validated, request):
    org = request.user.membership.organization
    # The database uniqueness constraint protects against an intervening import.
    for serializer in validated:
        product = serializer.save(organization=org)
        audit(request.user, org, 'product.create', product.pk)
    audit(request.user, org, 'product.import')
