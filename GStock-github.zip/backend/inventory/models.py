import uuid
from django.conf import settings
from django.db import models
from django.db.models import Q


class Organization(models.Model):
    name = models.CharField(max_length=120)
    currency = models.CharField(max_length=3, default='XAF')
    created_at = models.DateTimeField(auto_now_add=True)


class Membership(models.Model):
    ROLES = [('owner', 'Administrateur'), ('manager', 'Gestionnaire'), ('seller', 'Vendeur'), ('accountant', 'Comptable'), ('reader', 'Lecteur')]
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='membership')
    organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    role = models.CharField(max_length=15, choices=ROLES, default='reader')


class TenantModel(models.Model):
    organization = models.ForeignKey(Organization, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        abstract = True


class Category(TenantModel):
    name = models.CharField(max_length=120)
    active = models.BooleanField(default=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['organization', 'name'], name='category_org_name_unique')]


def image_path(instance, filename):
    return f'{instance.organization_id}/{uuid.uuid4().hex}.webp'


class Product(TenantModel):
    sku = models.CharField(max_length=80)
    name = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    category = models.ForeignKey(Category, null=True, blank=True, on_delete=models.PROTECT)
    barcode = models.CharField(max_length=80, blank=True)
    purchase_price = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    sale_price = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    quantity = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    minimum_stock = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    unit = models.CharField(max_length=30, default='unité')
    active = models.BooleanField(default=True)
    image = models.ImageField(upload_to=image_path, blank=True)
    class Meta:
        ordering = ['name', 'id']
        constraints = [models.UniqueConstraint(fields=['organization', 'sku'], name='product_org_sku_unique'),
            models.CheckConstraint(condition=Q(quantity__gte=0), name='product_quantity_nonnegative'),
            models.CheckConstraint(condition=Q(purchase_price__gte=0) & Q(sale_price__gte=0) & Q(minimum_stock__gte=0), name='product_prices_threshold_nonnegative')]


class Partner(TenantModel):
    kind = models.CharField(max_length=10, choices=[('customer', 'Client'), ('supplier', 'Fournisseur')])
    name = models.CharField(max_length=160)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=40, blank=True)
    address = models.TextField(blank=True)
    active = models.BooleanField(default=True)


class Document(TenantModel):
    kind = models.CharField(max_length=10, choices=[('sale', 'Vente'), ('purchase', 'Achat')])
    reference = models.CharField(max_length=40, default=uuid.uuid4, editable=False)
    partner = models.ForeignKey(Partner, null=True, blank=True, on_delete=models.PROTECT)
    status = models.CharField(max_length=12, default='draft', choices=[('draft', 'Brouillon'), ('completed', 'Validé'), ('cancelled', 'Annulé')])
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    total = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    class Meta:
        constraints = [models.CheckConstraint(condition=Q(total__gte=0), name='document_total_nonnegative')]


class DocumentLine(models.Model):
    document = models.ForeignKey(Document, related_name='lines', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=14, decimal_places=3)
    unit_price = models.DecimalField(max_digits=14, decimal_places=2)
    class Meta:
        constraints = [models.CheckConstraint(condition=Q(quantity__gt=0) & Q(unit_price__gte=0), name='line_quantity_price_valid'),
                       models.UniqueConstraint(fields=['document', 'product'], name='line_document_product_unique')]


class Movement(TenantModel):
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    delta = models.DecimalField(max_digits=14, decimal_places=3)
    balance = models.DecimalField(max_digits=14, decimal_places=3)
    reason = models.CharField(max_length=250)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    document = models.ForeignKey(Document, null=True, blank=True, on_delete=models.PROTECT)
    class Meta:
        ordering = ['-created_at', '-id']
        constraints = [models.CheckConstraint(condition=~Q(delta=0) & Q(balance__gte=0), name='movement_valid_delta_balance')]


class AuditEvent(TenantModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    action = models.CharField(max_length=100)
    object_id = models.CharField(max_length=80, blank=True)
    class Meta:
        ordering = ['-created_at', '-id']


class RateWindow(models.Model):
    key = models.CharField(max_length=64, unique=True)
    started_at = models.DateTimeField()
    count = models.PositiveIntegerField(default=0)


class ContactMessage(models.Model):
    name = models.CharField(max_length=120)
    email = models.EmailField()
    subject = models.CharField(max_length=160)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
