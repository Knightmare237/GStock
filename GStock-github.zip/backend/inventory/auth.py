import hashlib
import ipaddress
from datetime import timedelta
from django.db import transaction
from django.utils import timezone
from django.conf import settings
from rest_framework.authentication import SessionAuthentication
from rest_framework.exceptions import Throttled
from .models import RateWindow

class StrictSessionAuthentication(SessionAuthentication):
    def authenticate(self, request):
        # DRF normally checks CSRF only for authenticated users. Login/register also need it.
        self.enforce_csrf(request)
        return super().authenticate(request)

def limit(request, scope, maximum=10, seconds=900):
    # Trusted proxy must strip/recreate X-Real-IP and keep Django private.
    address = request.META.get('REMOTE_ADDR', 'unknown')
    if trusted_ip := (proxy_address(request) if settings.TRUST_PROXY else None):
        address = trusted_ip
    key = hashlib.sha256(f'{scope}:{address}'.encode()).hexdigest()
    now = timezone.now()
    with transaction.atomic():
        RateWindow.objects.get_or_create(key=key, defaults={'started_at': now})
        window = RateWindow.objects.select_for_update().get(key=key)
        if now - window.started_at >= timedelta(seconds=seconds):
            window.started_at, window.count = now, 0
        if window.count >= maximum:
            raise Throttled(wait=max(1, seconds - int((now-window.started_at).total_seconds())))
        window.count += 1
        window.save()

def proxy_address(request):
    try:
        return str(ipaddress.ip_address(request.META.get('HTTP_X_REAL_IP', '')))
    except ValueError:
        return None
