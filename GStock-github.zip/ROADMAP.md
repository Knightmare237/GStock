# Feuille de route GStock

Mise à jour : 13 octobre 2026. Cases cochées uniquement pour les travaux réalisés ; preuves et limites dans docs/WEB-DELIVERY.md. L’audit initial reste dans docs/AUDIT.md.

## Phase 1 — Audit

- [x] Sources/configurations/dépendances inventoriées et lues ; état initial sauvegardé.
- [x] Absence initiale de backend, base, Git et tests documentée ; plan priorisé.
- [x] Corrections sûres du prototype et vérification de compilation/lint.

## Phase 2 — Stabilisation

- [x] Dépendances vérifiées, routes couvrant les modules, API centralisée et configuration.
- [x] Audits npm/Python exécutés ; alertes npm corrigées par versions compatibles.
- [ ] Git et CI initialisés et exécutés.

## Phase 3 — Interface

- [x] Site public, À propos, Fonctionnalités et FAQ complétés ; périmètre explicite.
- [x] Comptes/contact reliés à l’API ; validation, chargement, erreurs et confirmations.
- [x] UI française, logo SVG, focus, navigation mobile, mouvement réduit et skeletons liés aux requêtes.
- [x] 17 pages contrôlées à 320, 375, 430, 768, 1024 et 1440 px, sans débordement de document.
- [ ] Audit d’accessibilité complet et suite E2E automatisée.

## Phase 4 — Backend et comptes

- [x] Django/DRF, organisation, adhésions, rôles, modèle tenant, migrations et contraintes.
- [x] Sessions, CSRF public/privé, hash Django, expiration, limitation d’abus et désactivation.
- [x] Inscription, connexion, déconnexion, profil/email, changement/reset de mot de passe et invitations.
- [x] Tests d’isolation/permissions, comptes et CSRF.
- [x] PostgreSQL configurable ; SQLite explicitement limité au développement/tests.
- [ ] PostgreSQL opérationnel sur un environnement validé.
- [ ] SMTP officiel et livraison réelle des emails de contact/invitation/reset.

## Phase 5 — Modules métier

- [x] Produits : CRUD avec archivage, détails, SKU par organisation, pagination/filtres/tri, images privées.
- [x] Catégories, dépendances et archivage ; clients/fournisseurs.
- [x] Stock initial, mouvements signés, motifs/responsables, transactions et stock négatif refusé.
- [x] Ventes/achats multi-lignes, brouillons, validation/réception et annulation complète ; inverse traçable.
- [x] Tests de rollback, répétition d’action, images, exports et préservation d’une quantité récente lors d’une modification de métadonnées.
- [ ] Test de concurrence PostgreSQL exécuté (fourni, ignoré sous SQLite).

## Phase 6 — Tableau de bord

- [x] Indicateurs réels par organisation, périodes, graphiques, alertes et historique.
- [x] Valorisation aux prix d’achat actuels, classement des ventes et exports CSV/Excel.
- [x] États vides/erreurs et chargement réel ; démonstration fictive isolée.

## Phase 7 — Livraison

- [x] 34 tests backend et 6 tests frontend réussis ; 1 test PostgreSQL ignoré.
- [x] Build, lint, check Django, migrations sans dérive et intégrité des dépendances.
- [x] Scripts Windows, .env.example, API et guides PostgreSQL, HTTPS/déploiement et sauvegarde/restauration.
- [ ] Domaine/hébergement public configurés, reverse proxy HTTPS et service WSGI supervisé.
- [ ] Restauration PostgreSQL testée dans une base distincte.
- [ ] Revue finale de production sur l’environnement hébergé.

## Phase 8 — Évolutions

- [x] Principes desktop et licence annuelle documentés, sans développement prématuré.
- [ ] Évaluation Tauri après stabilité métier et validation du périmètre.
- [x] Import CSV/XLSX de nouveaux produits avec aperçu, validation complète, doublons refusés et stock initial tracé.
- [ ] Retours/réceptions partiels, PDF, FIFO, paiements/taxes et hors ligne selon besoins validés.

La version web est fonctionnelle localement. L’ouverture commerciale publique n’est pas déclarée achevée tant que les points de mise en service restent non vérifiés.
