# Journal technique

## 2026-10-13 — Sidebar et import de catalogue

- Scrollbar de navigation fine, transparente au repos, assortie au fond sombre au survol et au focus ; version tactile et Firefox prises en charge.
- Import CSV UTF-8 / Excel XLSX dans Produits, modèle CSV, aperçu, erreurs par ligne et confirmation explicite. Maximum 1 000 produits / 5 Mo, catégories existantes, doublons refusés, aucun remplacement.
- Nouvelle validation à la confirmation et création atomique ; stock initial enregistré comme mouvement, isolation par organisation et accès owner/manager.
- Vérification : suite backend 43 tests, 42 réussis et 1 test PostgreSQL ignoré ; lint et build web réussis. Parcours navigateur CSV analysé puis importé dans l’organisation de test, stock 3,5 et référence/code-barres conservés. Capture docs/import-produits-verification.png.

## 2026-10-13 — Identité visuelle, profil et animations

- Logo vectoriel GStock redessiné : monogramme G, cube de stock et flèche de progression, dégradé bleu avec accent turquoise ; partagé par favicon, site public et gestion.
- Profil déplacé de la sidebar à un menu de navbar : identité, rôle, organisation, paramètres et déconnexion ; fermeture extérieure/Escape et adaptation mobile.
- Couleur propre à chaque module, titres et tableaux teintés, boutons harmonisés, cartes statistiques à six accents.
- Transitions de navigation, apparition progressive des cartes, survol des boutons/cartes et animation des panneaux/modales ; préférence de mouvement réduit respectée.
- Profil fictif de la démonstration déplacé également dans son en-tête.
- Vérifications : lint sans avertissement, compilation réussie ; neuf thèmes contrôlés au navigateur ; menu de profil dans la navbar sans débordement à 320, 375, 430, 768, 1024 et 1440 px, fermeture par Échap vérifiée.
- Finition : logo complet avec nom exporté dans gstock-logo.svg, pages de comptes enrichies d’un panneau de présentation et de fonds colorés, notifications avec icônes et animation d’entrée, skeletons teintés avec balayage limité aux chargements réels.
- Contrôle complémentaire : SVG autonomes valides, 18 vérifications de largeur sur connexion/inscription/récupération sans débordement, accès aux paramètres et déconnexion vérifiés depuis le nouveau menu de profil.

## 2026-10-13 — Lanceur Windows et Firefox

- lanceur.cmd appelle scripts/launch-web.ps1 depuis le dossier du projet.
- Verification des prerequis, identification des serveurs existants, demarrage masque de Django/Vite et attente de disponibilite de l'API via le proxy frontend.
- Ouverture d'un nouvel onglet Firefox sur http://127.0.0.1:5175/ ; journaux propres a chaque lancement dans logs/.
- Aucun serveur existant n'est arrete, aucune donnee supprimee ; erreur explicite en cas de port occupe ou de lancement impossible.
- Tests : syntaxe PowerShell valide ; demarrage a froid via lanceur.cmd reussi pour Django et Vite ; interface HTTP 200 ; relancement sans navigateur reutilisant les deux serveurs ; Firefox lance.

## 2026-10-13 — Implémentation de la version web

- Backend Django 6.1.2/DRF 3.18.3 créé avec configuration par environnement, session/CSRF, organisations, rôles, comptes, mots de passe Django et limitation persistée.
- Modèles, première migration, contraintes de stock/prix/SKU, API v1, pagination, recherche et isolation serveur.
- Produits/catégories et partenaires connectés ; archivage et images privées réencodées.
- Stock initial et changements traçables ; ventes/achats en brouillon, validation/réception et annulation complète transactionnelles ; tests de rollback et répétition d’action.
- Verrouillage/relecture avant sauvegarde de métadonnées et images pour conserver les quantités concurrentes ; test PostgreSQL concurrent fourni, ignoré localement faute de serveur.
- Dashboard réel, périodes, alertes, activité en français, classement de ventes, CSV/Excel avec protection contre l’injection de formules.
- Espace React relié au serveur, routes protégées, gestion des sessions expirées, chargements réels, erreurs, états vides et confirmations.
- Accueil complété par FAQ, fonctionnalités/limites explicites, À propos et contact configurable. Logo SVG natif et police système sans requête Google Fonts.
- Pages chargées à la demande ; entrée JS réduite à 302,46 kB (gzip 99,11 kB), sans avertissement de bundle. Menu mobile : focus, Escape et fond inactif.
- Scripts PowerShell analysés : apostrophes typographiques corrigées dans les messages, syntaxe valide.
- Prettier ajouté en développement ; Axios relevé à 1.20.0 et source-map-js à 1.2.2 pour corriger les alertes npm. Autres dépendances frontend conservées.
- Installation/lancement Windows, dépendances Python verrouillées, configuration PostgreSQL optionnelle, exemple Nginx et guides complets ajoutés.
- Validation : 34 tests backend réussis, 1 test PostgreSQL ignoré ; 6 tests frontend réussis ; lint et build réussis ; migrations sans dérive ; audits npm/Python sans vulnérabilité connue signalée.
- Navigateur : inscription et organisation, produit avec stock initial, vente validée, dashboard cohérent ; 17 pages × six largeurs sans débordement de document.
- Limites : PostgreSQL, SMTP réel, HTTPS/publication et restauration non vérifiés ; pas de retours partiels, PDF, import, FIFO, taxes/paiements ou offline. Voir docs/WEB-DELIVERY.md.

## 2026-10-13 — Audit et premières corrections sûres

- État initial : frontend seul ; build réussi hors bac à sable, lint avec trois avertissements.
- Sauvegarde initiale ZIP avant modifications, intégrité contrôlée.
- Tableau existant conservé sous `/demo`, avertissement permanent sur les données fictives ; délai artificiel de 1,2 s supprimé.
- Huit routes de modules couvertes par un état d’indisponibilité ; `/dashboard/*` explicite l’absence d’espace privé ; page 404 ajoutée.
- Formulaires non connectés désactivés, soumission neutralisée ; aucune création de compte ni envoi de message.
- CTA convertis en liens, actions de démonstration désactivées ou dirigées vers un état explicite.
- Statistiques commerciales non étayées supprimées ; aperçu et modules étiquetés fictifs/prévus ; coordonnées non confirmées retirées.
- Trois imports inutilisés retirés ; menu public basculé à lg pour limiter le chevauchement à largeur intermédiaire.
- Libellés de menu, focus visible, mouvement réduit et métadonnées françaises ajoutés.
- Audit, inventaire, installation, roadmap et préparation desktop documentés.
- Dépendances et verrouillage inchangés ; aucune suppression de source utile, de base ou de migration.
- Vérifications : lint code 0 sans avertissement ; build code 0, 2 221 modules ; 14 dépendances directes cohérentes ; ZIP intègre, 37 entrées.
- Aucune suite de tests métier disponible ; navigateur, responsive, sécurité backend et audit du registre non exécutés.
