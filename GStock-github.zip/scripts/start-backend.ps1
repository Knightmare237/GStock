﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
if (-not (Test-Path -LiteralPath '.venv/Scripts/python.exe')) { throw "Exécutez scripts/setup.ps1 avant le lancement." }
if (-not (Test-Path -LiteralPath 'backend/.env')) { throw "Configuration backend/.env manquante." }
& ./.venv/Scripts/python.exe backend/manage.py check
if ($LASTEXITCODE -ne 0) { throw "La configuration Django contient une erreur." }
& ./.venv/Scripts/python.exe backend/manage.py runserver 127.0.0.1:8005
if ($LASTEXITCODE -ne 0) { throw "Le serveur ne démarre pas. Vérifiez le port 8005 et la base de données." }
