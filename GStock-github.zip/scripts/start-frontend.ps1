﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath (Join-Path $projectRoot 'frontend')
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "Node.js et npm sont requis." }
if (-not (Test-Path -LiteralPath 'node_modules')) { throw "Exécutez scripts/setup.ps1 avant le lancement." }
npm run dev
if ($LASTEXITCODE -ne 0) { throw "Le frontend ne démarre pas. Vérifiez le port 5175 et les erreurs affichées." }
