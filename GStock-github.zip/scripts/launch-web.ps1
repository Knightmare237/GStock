param([switch]$NoBrowser, [switch]$CheckOnly)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$webUrl = 'http://127.0.0.1:5175/'
$apiUrl = 'http://127.0.0.1:8005/api/v1/csrf/'
$pythonPath = Join-Path $projectRoot '.venv\Scripts\python.exe'
$managePath = Join-Path $projectRoot 'backend\manage.py'
$vitePath = Join-Path $projectRoot 'frontend\node_modules\vite\bin\vite.js'
$logDirectory = Join-Path $projectRoot 'logs'

function Test-Port([int]$Port) {
    $socket = New-Object System.Net.Sockets.TcpClient
    try {
        $pending = $socket.BeginConnect('127.0.0.1', $Port, $null, $null)
        if (-not $pending.AsyncWaitHandle.WaitOne(500)) { return $false }
        $socket.EndConnect($pending)
        return $true
    } catch { return $false }
    finally { $socket.Dispose() }
}

function Test-Api([string]$Url) {
    try {
        $response = Invoke-RestMethod -Uri $Url -TimeoutSec 2
        return ($response.csrfToken -is [string] -and $response.csrfToken.Length -gt 0 -and
                $null -ne $response.PSObject.Properties['contact_available'])
    } catch { return $false }
}

function Test-Frontend {
    try {
        $response = Invoke-WebRequest -Uri $webUrl -UseBasicParsing -TimeoutSec 2
        return ($response.StatusCode -eq 200 -and $response.Content -match '<title>GStock')
    } catch { return $false }
}

function Find-Firefox {
    $command = Get-Command firefox.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    $candidates = @(
        (Join-Path $env:ProgramFiles 'Mozilla Firefox\firefox.exe'),
        (Join-Path $env:LOCALAPPDATA 'Mozilla Firefox\firefox.exe')
    )
    if (${env:ProgramFiles(x86)}) {
        $candidates += Join-Path ${env:ProgramFiles(x86)} 'Mozilla Firefox\firefox.exe'
    }
    foreach ($registryKey in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe',
                               'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe')) {
        if (Test-Path -LiteralPath $registryKey) {
            $candidates += (Get-Item -LiteralPath $registryKey).GetValue('')
        }
    }
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate }
    }
    throw 'Firefox est introuvable. Installez Firefox ou ajoutez firefox.exe au PATH.'
}

function Start-Server([string]$Name, [string]$Executable, [string[]]$ServerArguments, [string]$Directory) {
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    $outputPath = Join-Path $logDirectory "$Name-$stamp.log"
    $errorPath = Join-Path $logDirectory "$Name-$stamp-error.log"
    $process = Start-Process -FilePath $Executable -ArgumentList $ServerArguments -WorkingDirectory $Directory `
        -WindowStyle Hidden -RedirectStandardOutput $outputPath -RedirectStandardError $errorPath -PassThru
    return [PSCustomObject]@{ Process = $process; Name = $Name; Output = $outputPath; Error = $errorPath }
}

try {
    if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Python du projet manque. Executez scripts\setup.ps1.' }
    if (-not (Test-Path -LiteralPath (Join-Path $projectRoot 'backend\.env'))) { throw 'backend\.env manque. Executez scripts\setup.ps1.' }
    if (-not (Test-Path -LiteralPath $vitePath)) { throw 'Dependances frontend manquantes. Executez scripts\setup.ps1.' }
    $nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
    if (-not $nodeCommand) { throw 'Node.js est introuvable. Installez Node.js et relancez ce fichier.' }
    $firefoxPath = if (-not $NoBrowser) { Find-Firefox } else { $null }
    $backendReady = Test-Api $apiUrl
    $frontendReady = Test-Frontend
    if ((Test-Port 8005) -and -not $backendReady) { throw 'Le port 8005 est occupe, mais ne repond pas comme le backend GStock. Aucun processus ne sera arrete.' }
    if ((Test-Port 5175) -and -not $frontendReady) { throw 'Le port 5175 est occupe, mais ne repond pas comme le frontend GStock. Aucun processus ne sera arrete.' }
    if ($CheckOnly) {
        Write-Host "Prerequis valides. Backend actif : $backendReady. Frontend actif : $frontendReady."
        if ($firefoxPath) { Write-Host "Firefox : $firefoxPath" }
        exit 0
    }
    $startedServers = @()
    if (-not $backendReady) {
        Write-Host 'Demarrage du backend GStock...'
        $startedServers += Start-Server 'backend' $pythonPath @('-u', ('"{0}"' -f $managePath), 'runserver', '127.0.0.1:8005', '--noreload') $projectRoot
    } else { Write-Host 'Backend GStock deja actif : reutilisation.' }
    if (-not $frontendReady) {
        Write-Host 'Demarrage du frontend GStock...'
        $startedServers += Start-Server 'frontend' $nodeCommand.Source @(('"{0}"' -f $vitePath)) (Join-Path $projectRoot 'frontend')
    } else { Write-Host 'Frontend GStock deja actif : reutilisation.' }
    $deadline = (Get-Date).AddSeconds(60)
    do {
        foreach ($server in $startedServers) {
            $server.Process.Refresh()
            if ($server.Process.HasExited) {
                if (Test-Path -LiteralPath $server.Error) { Get-Content -LiteralPath $server.Error -Tail 20 | Write-Host }
                throw "Le serveur $($server.Name) s'est arrete. Journaux : $($server.Output) et $($server.Error)"
            }
        }
        if ((Test-Api $apiUrl) -and (Test-Frontend) -and (Test-Api ($webUrl + 'api/v1/csrf/'))) { break }
        if ((Get-Date) -ge $deadline) { throw "GStock ne repond pas apres 60 secondes. Consultez les journaux dans $logDirectory." }
        Start-Sleep -Milliseconds 500
    } while ($true)
    Write-Host "GStock est accessible : $webUrl"
    foreach ($server in $startedServers) { Write-Host "$($server.Name) : PID $($server.Process.Id). Journaux : $($server.Output) et $($server.Error)" }
    if (-not $NoBrowser) {
        Start-Process -FilePath $firefoxPath -ArgumentList @('-new-tab', $webUrl)
    }
    exit 0
} catch {
    Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
