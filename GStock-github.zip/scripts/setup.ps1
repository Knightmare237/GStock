﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw "Python 3.12+ est requis." }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "Node.js et npm sont requis." }
if (-not (Test-Path -LiteralPath '.venv/Scripts/python.exe')) {
    python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Création du venv impossible." }
}
& ./.venv/Scripts/python.exe -m pip install -r backend/requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Installation des dépendances Python impossible." }
if (-not (Test-Path -LiteralPath 'backend/.env')) {
    & ./.venv/Scripts/python.exe -c "from pathlib import Path; import secrets; p=Path('backend/.env'); p.write_text(Path('backend/.env.example').read_text(encoding='utf-8').replace('DJANGO_SECRET_KEY=', 'DJANGO_SECRET_KEY='+secrets.token_urlsafe(64),1),encoding='utf-8')"
    if ($LASTEXITCODE -ne 0) { throw "Création de la configuration impossible." }
}
& ./.venv/Scripts/python.exe backend/manage.py migrate
if ($LASTEXITCODE -ne 0) { throw "Migration impossible. Consultez l’erreur ; aucune donnée ne sera supprimée automatiquement." }
& ./.venv/Scripts/python.exe backend/manage.py collectstatic --noinput
if ($LASTEXITCODE -ne 0) { throw "Collecte des fichiers statiques impossible." }
Set-Location -LiteralPath (Join-Path $projectRoot 'frontend')
npm ci
if ($LASTEXITCODE -ne 0) { throw "Installation du frontend impossible." }
Write-Host 'Installation terminée. Lancez scripts/start-backend.ps1 et scripts/start-frontend.ps1 dans deux terminaux.'
