# Frontend GStock

Consulter le [README du projet](../README.md) pour l’installation, les limites et la documentation.

Exécuter `npm run dev`, `npm run lint` et `npm run build` dans ce dossier.
