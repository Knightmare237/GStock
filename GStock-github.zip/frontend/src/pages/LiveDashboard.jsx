import { money, qty, date, activityLabel } from "../services/format";
import usePeriod from "../hooks/usePeriod";
import { Link } from "react-router-dom";
import {
  Package,
  Wallet,
  TriangleAlert,
  PackageX,
  ShoppingCart,
  Truck,
  Plus,
} from "lucide-react";
import useResource from "../hooks/useResource";
import { useAuth } from "../contexts/session";
import ResourceState from "../components/ResourceState";
import { PageHeading, Empty, Field, inputClass } from "../components/ui";

export function PeriodFilter({ period }) {
  return (
    <div className="flex flex-wrap gap-3">
      <Field label="Du">
        <input
          type="date"
          required
          className={inputClass}
          value={period.start}
          onChange={(e) => period.setStart(e.target.value)}
        />
      </Field>
      <Field label="Au">
        <input
          type="date"
          required
          className={inputClass}
          value={period.end}
          onChange={(e) => period.setEnd(e.target.value)}
        />
      </Field>
    </div>
  );
}
export default function LiveDashboard() {
  const { user } = useAuth();
  const period = usePeriod();
  const resource = useResource(
    `dashboard/?start=${period.start}&end=${period.end}`,
  );
  const data = resource.data,
    currency = user.organization.currency;
  const cards = data
    ? [
        ["Produits actifs", data.product_count, Package, "blue"],
        [
          "Valeur du stock",
          money(data.stock_value, currency),
          Wallet,
          "violet",
        ],
        ["Stocks faibles", data.low_stock_count, TriangleAlert, "amber"],
        ["Ruptures", data.out_of_stock_count, PackageX, "rose"],
        [
          "Ventes de la période",
          money(data.sales_total, currency),
          ShoppingCart,
          "emerald",
        ],
        [
          "Achats de la période",
          money(data.purchases_total, currency),
          Truck,
          "cyan",
        ],
      ]
    : [];
  const max = Math.max(1, ...(data?.series || []).map((s) => Number(s.total)));
  return (
    <>
      <PageHeading
        title="Vue d’ensemble"
        subtitle="Des indicateurs calculés à partir de votre organisation."
      >
        <PeriodFilter period={period} />
      </PageHeading>
      <ResourceState resource={resource}>
        {data && (
          <>
            <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-700 to-blue-500 p-6 text-white sm:p-8">
              <p className="text-sm text-blue-100">{user.organization.name}</p>
              <h2 className="mt-2 text-2xl font-bold">
                Votre activité, en un coup d’œil.
              </h2>
              <p className="mt-3 max-w-xl text-sm leading-6 text-blue-100">
                Suivez vos produits, anticipez les ruptures et retrouvez les
                dernières opérations. Valeur du stock calculée aux prix d’achat
                actuels.
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <Link
                  className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-blue-700"
                  to="/dashboard/products"
                >
                  <Plus size={16} />
                  Gérer les produits
                </Link>
                <Link
                  className="rounded-xl border border-white/40 px-4 py-2.5 text-sm"
                  to="/dashboard/stock"
                >
                  Consulter les mouvements
                </Link>
              </div>
            </section>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {cards.map(([label, value, Icon, color]) => (
                <article
                  key={label}
                  data-tone={color}
                  className="metric-card rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
                >
                  <div className="flex justify-between gap-3">
                    <p className="text-sm text-slate-500">{label}</p>
                    <span className="metric-icon rounded-xl p-2">
                      <Icon size={20} />
                    </span>
                  </div>
                  <p className="mt-3 break-words text-2xl font-bold">{value}</p>
                </article>
              ))}
            </div>
            <div className="grid gap-6 xl:grid-cols-3">
              <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 xl:col-span-2">
                <h2 className="font-bold">Évolution des ventes</h2>
                <p className="mt-1 text-xs text-slate-500">
                  Totaux quotidiens des ventes validées, hors documents annulés.
                </p>
                {data.series.length ? (
                  <>
                    <div
                      className="mt-6 flex h-52 items-end gap-2 overflow-x-auto"
                      role="img"
                      aria-label="Histogramme des ventes quotidiennes"
                    >
                      {data.series.map((s) => (
                        <div
                          key={s.day}
                          className="flex h-full min-w-8 max-w-14 flex-1 items-end"
                        >
                          <div
                            title={`${s.day} : ${money(s.total, currency)}`}
                            className="w-full rounded-t-lg bg-blue-500"
                            style={{
                              height: `${Math.max(2, (Number(s.total) / max) * 100)}%`,
                            }}
                          />
                        </div>
                      ))}
                    </div>
                    <details className="mt-5 text-sm">
                      <summary className="cursor-pointer text-blue-600">
                        Voir les valeurs du graphique
                      </summary>
                      <ul className="mt-3 space-y-1">
                        {data.series.map((s) => (
                          <li key={s.day}>
                            {s.day} : {money(s.total, currency)}
                          </li>
                        ))}
                      </ul>
                    </details>
                  </>
                ) : (
                  <Empty text="Aucune vente validée sur cette période." />
                )}
              </section>
              <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
                <div className="flex justify-between">
                  <h2 className="font-bold">Alertes de stock</h2>
                  <TriangleAlert size={20} className="text-orange-500" />
                </div>
                {data.alerts.length ? (
                  <div className="mt-5 space-y-3">
                    {data.alerts.map((p) => (
                      <Link
                        to="/dashboard/products"
                        key={p.id}
                        className="flex items-center justify-between gap-3 rounded-xl bg-orange-50 p-3 text-sm"
                      >
                        <span className="min-w-0 break-words font-medium">
                          {p.name}
                        </span>
                        <span className="shrink-0 font-semibold text-orange-800">
                          {qty(p.quantity)} {p.unit}
                        </span>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <Empty text="Aucun produit au seuil minimum." />
                )}
              </section>
            </div>
            <div className="grid gap-6 lg:grid-cols-2">
              <section className="rounded-2xl border border-slate-200 bg-white p-6">
                <div className="flex justify-between gap-3">
                  <h2 className="font-bold">Derniers mouvements</h2>
                  <Link className="text-sm text-blue-600" to="/dashboard/stock">
                    Voir tous
                  </Link>
                </div>
                {data.movements.length ? (
                  <div className="mt-5 divide-y divide-slate-100">
                    {data.movements.map((m) => (
                      <div
                        key={m.id}
                        className="flex flex-wrap justify-between gap-3 py-3"
                      >
                        <div>
                          <p className="text-sm font-medium">
                            {m.product_name}
                          </p>
                          <p className="text-xs text-slate-500">
                            {date(m.created_at)}
                          </p>
                        </div>
                        <p
                          className={`text-sm font-semibold ${Number(m.delta) > 0 ? "text-green-700" : "text-red-700"}`}
                        >
                          {Number(m.delta) > 0 ? "+" : ""}
                          {qty(m.delta)}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Empty text="Aucun mouvement sur cette période." />
                )}
              </section>
              <section className="rounded-2xl border border-slate-200 bg-white p-6">
                <h2 className="font-bold">Activité récente</h2>
                {data.activity.length ? (
                  <div className="mt-5 divide-y divide-slate-100">
                    {data.activity.map((a) => (
                      <div key={a.id} className="py-3">
                        <p className="text-sm font-medium">
                          {activityLabel(a.action)} · {a.user_name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {date(a.created_at)}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Empty text="Aucune activité enregistrée." />
                )}
              </section>
            </div>
          </>
        )}
      </ResourceState>
    </>
  );
}
