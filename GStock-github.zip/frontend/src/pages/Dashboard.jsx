import { Link } from "react-router-dom";
import {
  AlertTriangle,
  Boxes,
  Package,
  ShoppingCart,
  TrendingUp,
  Users,
} from "lucide-react";
import { motion } from "framer-motion";

import StatCard from "../components/StatCard";


function Dashboard() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >

      <p className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        Démonstration visuelle publique · Toutes les valeurs, produits et activités ci-dessous sont fictifs.
        Les actions métier ne sont pas disponibles et aucune donnée n’est enregistrée.
      </p>
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">
          Tableau de bord
        </h1>

        <p className="mt-1 text-sm text-slate-500">
          Suivez les performances de votre activité.
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">

        <StatCard
          title="Produits"
          value="245"
          variation="12.5%"
          icon={Package}
        />

        <StatCard
          title="Stock disponible"
          value="1 240"
          variation="8.2%"
          icon={Boxes}
        />

        <StatCard
          title="Ventes"
          value="2.4M FCFA"
          variation="20.4%"
          icon={ShoppingCart}
        />

        <StatCard
          title="Alertes stock"
          value="18"
          variation="5.1%"
          icon={AlertTriangle}
          positive={false}
        />

      </div>

      {/* Main analytics */}
      <div className="grid gap-6 xl:grid-cols-3">

        {/* Chart */}
        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm xl:col-span-2">

          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">

            <div>
              <h2 className="font-bold text-slate-900">
                Évolution des ventes
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Performance des 7 derniers jours
              </p>
            </div>

            <div className="flex items-center gap-2 text-sm font-semibold text-green-600">
              <TrendingUp size={16} />
              +20.4%
            </div>

          </div>

          <div className="mt-8 flex h-64 items-end gap-2 sm:gap-4">

            {[40, 55, 45, 70, 60, 85, 72, 95, 80, 100, 85, 90].map(
              (height, index) => (
                <motion.div
                  key={index}
                  initial={{ height: 0 }}
                  animate={{ height: `${height}%` }}
                  transition={{
                    duration: 0.7,
                    delay: index * 0.04,
                  }}
                  className="flex-1 rounded-t-lg bg-blue-500/90 transition hover:bg-blue-600"
                />
              )
            )}

          </div>

          <div className="mt-4 flex justify-between text-xs text-slate-400">
            <span>Lun</span>
            <span>Mar</span>
            <span>Mer</span>
            <span>Jeu</span>
            <span>Ven</span>
            <span>Sam</span>
            <span>Dim</span>
          </div>

        </div>

        {/* Stock faible */}
        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">

          <div className="flex items-center justify-between">

            <div>
              <h2 className="font-bold text-slate-900">
                Stock faible
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Produits à surveiller
              </p>
            </div>

            <AlertTriangle className="text-orange-500" size={21} />

          </div>

          <div className="mt-6 space-y-4">

            {[
              ["Ordinateur HP", "3 unités"],
              ["Clavier Logitech", "5 unités"],
              ["Souris Microsoft", "4 unités"],
              ["Écran Samsung", "2 unités"],
            ].map(([product, stock]) => (
              <div
                key={product}
                className="flex items-center justify-between rounded-xl bg-slate-50 p-3"
              >

                <div>
                  <p className="text-sm font-semibold text-slate-800">
                    {product}
                  </p>

                  <p className="mt-1 text-xs text-slate-500">
                    Stock restant
                  </p>
                </div>

                <span className="rounded-lg bg-orange-100 px-2.5 py-1 text-xs font-semibold text-orange-600">
                  {stock}
                </span>

              </div>
            ))}

          </div>

          <Link to="/demo/products" className="mt-6 block text-center w-full rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">
            Voir tous les produits
          </Link>

        </div>

      </div>

      {/* Bottom */}
      <div className="grid gap-6 lg:grid-cols-2">

        {/* Recent activities */}
        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">

          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-bold text-slate-900">
                Activité récente
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Dernières opérations
              </p>
            </div>

            <Link to="/demo/stock" className="text-sm font-semibold text-blue-600">
              Voir tout
            </Link>
          </div>

          <div className="mt-6 space-y-5">

            {[
              ["Vente", "Commande #GS-1042", "+125 000 FCFA"],
              ["Entrée", "Stock ordinateur HP", "+20 unités"],
              ["Vente", "Commande #GS-1041", "+85 000 FCFA"],
              ["Sortie", "Claviers Logitech", "-8 unités"],
            ].map(([type, name, value]) => (
              <div
                key={name}
                className="flex items-center gap-4"
              >

                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-50 text-blue-600">
                  {type === "Vente" ? (
                    <ShoppingCart size={17} />
                  ) : (
                    <Package size={17} />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-800">
                    {name}
                  </p>

                  <p className="text-xs text-slate-400">
                    {type}
                  </p>
                </div>

                <span className="text-sm font-semibold text-slate-700">
                  {value}
                </span>

              </div>
            ))}

          </div>

        </div>

        {/* Quick actions */}
        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">

          <h2 className="font-bold text-slate-900">
            Actions rapides
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Accédez rapidement aux fonctions principales.
          </p>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">

            {[
              ["Ajouter un produit", Package],
              ["Nouvelle vente", ShoppingCart],
              ["Entrée de stock", Boxes],
              ["Nouveau client", Users],
            ].map(([label, Icon]) => (
              <button
                disabled
                title="Action indisponible dans la démonstration"
                key={label}
                className="flex items-center gap-3 rounded-xl border border-slate-200 p-4 text-left transition hover:border-blue-200 hover:bg-blue-50"
              >

                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                  <Icon size={19} />
                </div>

                <span className="text-sm font-semibold text-slate-700">
                  {label}
                </span>

              </button>
            ))}

          </div>

        </div>

      </div>

    </motion.div>
  );
}

export default Dashboard;