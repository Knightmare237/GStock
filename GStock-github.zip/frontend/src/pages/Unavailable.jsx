import { Link } from "react-router-dom";

export default function Unavailable({ title = "Action hors démonstration" }) {
  return (
    <section className="mx-auto max-w-2xl px-6 py-16">
      <p className="text-sm font-semibold text-blue-600">
        GStock · Démonstration publique
      </p>
      <h1 className="mt-4 text-3xl font-bold">{title}</h1>
      <p className="mt-4 leading-7 text-slate-600">
        La démonstration publique présente uniquement des données fictives. Pour
        enregistrer vos produits et vos opérations, connectez-vous à votre
        espace de gestion.
      </p>
      <div className="mt-6 flex flex-wrap gap-4">
        <Link to="/" className="rounded-xl border border-slate-200 px-5 py-3">
          Accueil
        </Link>
        <Link
          to="/demo"
          className="rounded-xl bg-blue-600 px-5 py-3 text-white"
        >
          Voir la démonstration visuelle
        </Link>
        <Link
          to="/dashboard"
          className="rounded-xl border border-blue-200 px-5 py-3 text-blue-700"
        >
          Ouvrir mon espace
        </Link>
      </div>
    </section>
  );
}
