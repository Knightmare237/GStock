import { money, qty } from "../services/format";
import { useState } from "react";
import { useAuth } from "../contexts/session";
import useResource from "../hooks/useResource";
import { download, errorMessage } from "../services/api";
import {
  PageHeading,
  ErrorNotice,
  Empty,
  Table,
  Cell,
  buttonClass,
  secondaryClass,
} from "../components/ui";
import ResourceState from "../components/ResourceState";
import { PeriodFilter } from "./LiveDashboard";
import usePeriod from "../hooks/usePeriod";
export default function Reports() {
  const { user } = useAuth(),
    period = usePeriod();
  const resource = useResource(
    `dashboard/?start=${period.start}&end=${period.end}`,
  );
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function exportFile(kind, format) {
    setBusy(true);
    setError("");
    try {
      await download(kind, format, period.start, period.end);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  if (!["owner", "manager", "accountant"].includes(user.role))
    return (
      <Empty text="Votre rôle ne permet pas les exports et rapports financiers." />
    );
  return (
    <>
      <PageHeading
        title="Rapports et exports"
        subtitle="Valorisation aux prix d’achat actuels ; ventes et achats validés hors annulations."
      >
        <PeriodFilter period={period} />
      </PageHeading>
      <ErrorNotice message={error} />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ["products", "Catalogue"],
          ["movements", "Mouvements"],
          ["sale", "Ventes"],
          ["purchase", "Achats"],
        ].map(([kind, label]) => (
          <section
            key={kind}
            className="rounded-2xl border border-slate-200 bg-white p-5"
          >
            <h2 className="font-bold">{label}</h2>
            <p className="my-3 text-xs text-slate-500">
              {kind === "products"
                ? "Tous les produits, actifs et archivés."
                : "Documents ou mouvements sur la période sélectionnée."}
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                className={buttonClass}
                disabled={busy}
                onClick={() => exportFile(kind, "csv")}
              >
                CSV
              </button>
              <button
                className={secondaryClass}
                disabled={busy}
                onClick={() => exportFile(kind, "xlsx")}
              >
                Excel
              </button>
            </div>
          </section>
        ))}
      </div>
      <ResourceState resource={resource}>
        {resource.data && (
          <>
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                ["Stock actuel", resource.data.stock_value],
                ["Ventes", resource.data.sales_total],
                ["Achats", resource.data.purchases_total],
              ].map(([label, value]) => (
                <section key={label} className="rounded-2xl bg-white p-6">
                  <p className="text-sm text-slate-500">{label}</p>
                  <p className="mt-3 text-xl font-bold">
                    {money(value, user.organization.currency)}
                  </p>
                </section>
              ))}
            </div>
            <h2 className="font-bold">Produits les plus vendus</h2>
            {resource.data.top_products.length ? (
              <Table headers={["Produit", "Quantité vendue", "Montant brut"]}>
                {resource.data.top_products.map((p) => (
                  <tr key={p.product_id}>
                    <Cell>{p.product__name}</Cell>
                    <Cell>{qty(p.quantity)}</Cell>
                    <Cell>{money(p.revenue, user.organization.currency)}</Cell>
                  </tr>
                ))}
              </Table>
            ) : (
              <Empty text="Aucune vente validée pour établir ce classement." />
            )}
          </>
        )}
      </ResourceState>
      <p className="text-sm text-slate-500">
        Le PDF et l’analyse de faible rotation ne sont pas disponibles dans
        cette version. Les exports de documents incluent leurs statuts ; filtrez
        les annulations pour vos analyses externes.
      </p>
    </>
  );
}
