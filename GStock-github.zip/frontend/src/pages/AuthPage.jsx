import { useState } from "react";
import { Package, ArrowLeftRight, ShieldCheck } from "lucide-react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../contexts/session";
import { api, bootstrap, errorMessage } from "../services/api";
import {
  Field,
  inputClass,
  buttonClass,
  ErrorNotice,
  SuccessNotice,
} from "../components/ui";

export default function AuthPage({ mode }) {
  const { authenticate } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const params = useParams();
  const [values, setValues] = useState({
    email: "",
    password: "",
    confirmation: "",
    name: "",
    organization: "",
  });
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState("");
  const titles = {
    login: "Bienvenue sur GStock",
    register: "Créez votre espace",
    forgot: "Mot de passe oublié",
    reset: "Nouveau mot de passe",
  };
  function field(key, label, type = "text", autoComplete) {
    return (
      <Field label={label}>
        <input
          name={key}
          aria-label={label}
          className={inputClass}
          type={type}
          required
          value={values[key]}
          onChange={(e) => setValues({ ...values, [key]: e.target.value })}
          minLength={type === "password" && mode !== "login" ? 10 : undefined}
          maxLength={
            key === "organization" ? 120 : type === "password" ? 128 : 150
          }
          autoComplete={autoComplete}
        />
      </Field>
    );
  }
  async function submit(e) {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (
      ["register", "reset"].includes(mode) &&
      values.password !== values.confirmation
    ) {
      setError("Les mots de passe ne correspondent pas.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "login" || mode === "register") {
        await authenticate(mode, values);
        const destination = location.state?.from;
        navigate(
          destination?.startsWith("/dashboard") ? destination : "/dashboard",
          { replace: true },
        );
      } else {
        await bootstrap();
        const { data } = await api.post(
          mode === "forgot" ? "auth/forgot-password/" : "auth/reset-password/",
          { ...values, ...params },
        );
        setSuccess(data.detail);
        setValues({ ...values, password: "", confirmation: "" });
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="auth-shell flex min-h-screen items-center justify-center gap-16 px-4 py-10 lg:px-10">
      <section className="auth-intro hidden max-w-md lg:block">
        <img
          src="/gstock-logo.svg"
          alt="GStock, gestion de stock"
          className="mb-12 w-72"
        />
        <p className="mb-5 text-xs font-bold uppercase tracking-[.2em] text-blue-600">
          Votre espace de gestion
        </p>
        <h2 className="text-4xl font-bold leading-tight text-slate-900">
          Moins de dispersion.
          <br />
          <span className="text-blue-600">Plus de visibilité.</span>
        </h2>
        <p className="mt-5 text-base leading-8 text-slate-600">
          Retrouvez votre catalogue, vos mouvements et vos opérations dans un
          espace pensé pour votre équipe.
        </p>
        <div className="mt-8 space-y-4">
          {[
            [
              Package,
              "Un catalogue centralisé",
              "Produits, catégories, prix et seuils.",
            ],
            [
              ArrowLeftRight,
              "Des opérations traçables",
              "Entrées, sorties, achats et ventes.",
            ],
            [
              ShieldCheck,
              "Des responsabilités claires",
              "Une organisation et des rôles adaptés.",
            ],
          ].map(([Icon, title, description]) => (
            <div key={title} className="flex items-center gap-4">
              <span className="rounded-2xl border border-white bg-white/70 p-3 text-blue-600 shadow-sm">
                <Icon size={22} />
              </span>
              <div>
                <p className="text-sm font-semibold text-slate-800">{title}</p>
                <p className="mt-1 text-xs text-slate-500">{description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
      <div className="auth-card w-full max-w-md rounded-3xl border border-blue-100 bg-white p-6 sm:p-9">
        <Link to="/" className="mb-8 flex items-center gap-3 text-xl font-bold">
          <img src="/gstock.svg" alt="" className="h-11 w-11" />
          GStock
        </Link>
        <h1 className="text-2xl font-bold">{titles[mode]}</h1>
        <p className="mt-3 text-sm leading-6 text-slate-500">
          {mode === "register"
            ? "Une organisation indépendante pour vos produits et vos opérations."
            : "Gérez votre activité dans un espace centralisé."}
        </p>
        <form onSubmit={submit} className="mt-7 space-y-5">
          <ErrorNotice message={error} />
          <SuccessNotice message={success} />
          {mode === "register" && (
            <>
              {field("name", "Nom complet", "text", "name")}
              {field(
                "organization",
                "Nom de votre entreprise",
                "text",
                "organization",
              )}
            </>
          )}
          {mode !== "reset" &&
            field("email", "Adresse email", "email", "email")}
          {mode !== "forgot" &&
            field(
              "password",
              "Mot de passe",
              "password",
              mode === "login" ? "current-password" : "new-password",
            )}
          {["register", "reset"].includes(mode) &&
            field(
              "confirmation",
              "Confirmer le mot de passe",
              "password",
              "new-password",
            )}
          <button disabled={busy} className={`${buttonClass} w-full`}>
            {busy
              ? "Traitement…"
              : {
                  login: "Se connecter",
                  register: "Créer mon espace",
                  forgot: "Recevoir un lien",
                  reset: "Enregistrer le mot de passe",
                }[mode]}
          </button>
        </form>
        <div className="mt-6 flex flex-wrap justify-between gap-3 text-sm text-blue-600">
          <Link to={mode === "login" ? "/register" : "/login"}>
            {mode === "login" ? "Créer un compte" : "Se connecter"}
          </Link>
          {mode === "login" && (
            <Link to="/forgot-password">Mot de passe oublié ?</Link>
          )}
        </div>
      </div>
    </main>
  );
}
