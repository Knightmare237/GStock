import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <section className="mx-auto max-w-2xl px-6 py-16">
      <p className="font-semibold text-blue-600">Erreur 404</p>
      <h1 className="mt-3 text-3xl font-bold">Page introuvable</h1>
      <p className="mt-4 text-slate-600">Cette adresse ne correspond à aucune page GStock.</p>
      <Link to="/" className="mt-6 inline-block rounded-xl bg-blue-600 px-5 py-3 text-white">Retour à l’accueil</Link>
    </section>
  );
}
