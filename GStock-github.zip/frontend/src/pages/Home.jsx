import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BarChart3,
  Boxes,
  CheckCircle2,
  Package,
  ShieldCheck,
  ShoppingCart,
  TrendingUp,
  Users,
} from "lucide-react";

import AnimatedSection from "../components/AnimatedSection";

const MotionLink = motion.create(Link);

function Home() {
  const features = [
    {
      icon: Package,
      title: "Gestion des produits",
      description:
        "Centralisez vos produits, catégories, prix et informations importantes.",
    },
    {
      icon: Boxes,
      title: "Suivi du stock",
      description:
        "Suivez les entrées, sorties et niveaux de stock en temps réel.",
    },
    {
      icon: ShoppingCart,
      title: "Ventes & achats",
      description:
        "Gérez vos transactions et automatisez la mise à jour de vos stocks.",
    },
    {
      icon: BarChart3,
      title: "Analyses",
      description:
        "Visualisez vos performances grâce à des statistiques claires.",
    },
    {
      icon: Users,
      title: "Utilisateurs",
      description:
        "Attribuez différents rôles et contrôlez les accès à la plateforme.",
    },
    {
      icon: ShieldCheck,
      title: "Sécurité",
      description:
        "Protégez vos données grâce à une authentification sécurisée.",
    },
  ];

  const steps = [
    {
      number: "01",
      title: "Créez votre espace",
      description:
        "Inscrivez votre entreprise et configurez votre espace GStock.",
    },
    {
      number: "02",
      title: "Ajoutez vos produits",
      description: "Créez vos produits et définissez vos niveaux de stock.",
    },
    {
      number: "03",
      title: "Gérez votre activité",
      description:
        "Suivez les mouvements, ventes, achats et performances depuis votre dashboard.",
    },
  ];

  return (
    <div className="overflow-hidden bg-white">
      {/* HERO */}
      <section className="relative px-6 py-20 sm:py-28 lg:py-32">
        <div className="absolute left-0 top-0 -z-10 h-96 w-96 rounded-full bg-blue-100/50 blur-3xl" />

        <div className="absolute right-0 top-20 -z-10 h-96 w-96 rounded-full bg-green-100/40 blur-3xl" />

        <div className="mx-auto grid max-w-7xl items-center gap-16 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-600">
              <span className="h-2 w-2 rounded-full bg-blue-600" />
              Gestion de stock intelligente
            </div>

            <h1 className="mt-6 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl xl:text-7xl">
              Votre stock.
              <span className="block text-blue-600">Votre contrôle.</span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-8 text-slate-600 sm:text-lg">
              GStock centralise vos produits, vos stocks, vos ventes, vos achats
              et vos statistiques dans une seule plateforme simple et intuitive.
            </p>

            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <MotionLink
                to="/register"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="group inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-3.5 font-semibold text-white shadow-xl shadow-blue-600/20 transition hover:bg-blue-700"
              >
                Créer mon espace
                <ArrowRight
                  size={18}
                  className="transition-transform group-hover:translate-x-1"
                />
              </MotionLink>

              <MotionLink
                to="/features"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="rounded-xl border border-slate-200 px-6 py-3.5 font-semibold text-slate-700 transition hover:bg-slate-50"
              >
                Découvrir les fonctionnalités
              </MotionLink>
            </div>

            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-slate-500">
              <span className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-green-500" />
                Simple à utiliser
              </span>

              <span className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-green-500" />
                Responsive
              </span>

              <span className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-green-500" />
                Accès par organisation
              </span>
            </div>
          </motion.div>

          {/* Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              duration: 0.8,
              delay: 0.2,
            }}
          >
            <div className="relative">
              <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-r from-blue-500/20 to-green-400/20 blur-2xl" />

              <div className="relative rounded-[2rem] bg-slate-950 p-3 shadow-2xl sm:p-5">
                <div className="rounded-2xl bg-slate-50 p-5 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-slate-500">
                        Aperçu fictif · Démonstration
                      </p>

                      <h2 className="mt-1 text-lg font-bold text-slate-900">
                        Tableau de bord
                      </h2>
                    </div>

                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 font-semibold text-blue-600">
                      M
                    </div>
                  </div>

                  <div className="mt-6 grid grid-cols-2 gap-3">
                    {[
                      ["Produits", "245", "+12%"],
                      ["Stock total", "1 240", "+8%"],
                      ["Stock faible", "18", "-5%"],
                      ["Ventes", "2.4M", "+20%"],
                    ].map(([label, value, variation]) => (
                      <div
                        key={label}
                        className="rounded-2xl bg-white p-4 shadow-sm"
                      >
                        <p className="text-xs text-slate-500">{label}</p>

                        <p className="mt-2 text-xl font-bold text-slate-900 sm:text-2xl">
                          {value}
                        </p>

                        <p
                          className={`mt-1 text-xs font-medium ${
                            variation.startsWith("-")
                              ? "text-red-500"
                              : "text-green-500"
                          }`}
                        >
                          {variation}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 rounded-2xl bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold text-slate-900">
                        Activité du stock
                      </p>

                      <TrendingUp size={17} className="text-blue-600" />
                    </div>

                    <div className="mt-6 flex h-32 items-end gap-2">
                      {[35, 55, 42, 70, 52, 85, 65, 90, 72].map(
                        (height, index) => (
                          <motion.div
                            key={index}
                            initial={{ height: 0 }}
                            animate={{ height: `${height}%` }}
                            transition={{
                              duration: 0.8,
                              delay: 0.5 + index * 0.05,
                            }}
                            className="flex-1 rounded-t-md bg-blue-500"
                          />
                        ),
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* STATS */}
      <AnimatedSection>
        <section className="border-y border-slate-100 bg-slate-50 px-6 py-10">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 md:grid-cols-4">
            {[
              ["Produits", "Catalogue et catégories"],
              ["Stock", "Historique traçable"],
              ["Ventes", "Validation et annulation"],
              ["Rapports", "Exports CSV et Excel"],
            ].map(([value, label]) => (
              <div key={label} className="text-center">
                <p className="text-3xl font-bold text-slate-900">{value}</p>

                <p className="mt-1 text-sm text-slate-500">{label}</p>
              </div>
            ))}
          </div>
        </section>
      </AnimatedSection>

      {/* FEATURES */}
      <section className="px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <AnimatedSection>
            <div className="mx-auto max-w-2xl text-center">
              <span className="text-sm font-semibold text-blue-600">
                FONCTIONNALITÉS
              </span>

              <h2 className="mt-3 text-3xl font-bold text-slate-900 sm:text-4xl">
                Les outils pour piloter votre activité
              </h2>

              <p className="mt-4 leading-7 text-slate-600">
                Des fonctionnalités pour centraliser et piloter votre activité.
              </p>
            </div>
          </AnimatedSection>

          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => {
              const Icon = feature.icon;

              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.5,
                    delay: index * 0.08,
                  }}
                  whileHover={{ y: -6 }}
                  className="group rounded-2xl border border-slate-100 bg-white p-7 shadow-sm transition-shadow hover:shadow-xl hover:shadow-slate-200/50"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600 transition group-hover:bg-blue-600 group-hover:text-white">
                    <Icon size={22} />
                  </div>

                  <h3 className="mt-6 text-lg font-bold text-slate-900">
                    {feature.title}
                  </h3>

                  <p className="mt-3 leading-7 text-slate-600">
                    {feature.description}
                  </p>

                  <Link
                    to="/features"
                    className="mt-5 flex items-center gap-2 text-sm font-semibold text-blue-600"
                  >
                    Module disponible
                    <ArrowRight size={16} />
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-slate-950 px-6 py-24 text-white">
        <div className="mx-auto max-w-7xl">
          <AnimatedSection>
            <div className="max-w-2xl">
              <span className="text-sm font-semibold text-blue-400">
                COMMENT ÇA MARCHE ?
              </span>

              <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
                Une gestion simple en quelques étapes
              </h2>
            </div>
          </AnimatedSection>

          <div className="mt-14 grid gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.1,
                }}
                className="relative rounded-2xl border border-slate-800 bg-slate-900 p-7"
              >
                <span className="text-4xl font-bold text-blue-500">
                  {step.number}
                </span>

                <h3 className="mt-6 text-xl font-bold">{step.title}</h3>

                <p className="mt-3 leading-7 text-slate-400">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-16">
        <h2 className="text-3xl font-bold">Questions fréquentes</h2>
        <div className="mt-8 space-y-4">
          {[
            [
              "Les chiffres de l’aperçu sont-ils réels ?",
              "L’aperçu public est une illustration fictive. Dans votre espace connecté, les indicateurs sont calculés à partir des produits et opérations de votre organisation.",
            ],
            [
              "Quand une vente modifie-t-elle le stock ?",
              "Lors de sa validation. Un brouillon ne réserve pas de quantité. Le serveur vérifie la disponibilité ; une vente insuffisamment approvisionnée est refusée.",
            ],
            [
              "Puis-je annuler une opération ?",
              "Une vente ou un achat validé peut être annulé intégralement avec un mouvement inverse. Une annulation qui rendrait le stock négatif est refusée. Les retours partiels ne sont pas disponibles.",
            ],
            [
              "Puis-je travailler sans connexion ?",
              "La version web nécessite une connexion au serveur. La version desktop et sa politique hors ligne sont des évolutions futures.",
            ],
          ].map(([question, answer]) => (
            <details
              key={question}
              className="rounded-xl border border-slate-200 p-5"
            >
              <summary className="cursor-pointer font-semibold">
                {question}
              </summary>
              <p className="mt-3 text-sm leading-7 text-slate-600">{answer}</p>
            </details>
          ))}
        </div>
      </section>

      {/* CTA */}
      <AnimatedSection>
        <section className="px-6 py-24">
          <div className="mx-auto max-w-5xl overflow-hidden rounded-3xl bg-blue-600 px-6 py-14 text-center text-white shadow-2xl shadow-blue-600/20 sm:px-12">
            <h2 className="text-3xl font-bold sm:text-4xl">
              Prêt à reprendre le contrôle de votre stock ?
            </h2>

            <p className="mx-auto mt-4 max-w-2xl text-blue-100">
              Centralisez votre activité et prenez de meilleures décisions grâce
              à GStock.
            </p>

            <MotionLink
              to="/demo"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 font-semibold text-blue-600 shadow-lg"
            >
              Explorer la démonstration
              <ArrowRight size={18} />
            </MotionLink>
          </div>
        </section>
      </AnimatedSection>
    </div>
  );
}

export default Home;
