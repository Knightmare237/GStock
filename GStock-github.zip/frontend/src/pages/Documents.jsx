import { money, qty, date } from "../services/format";
import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { useAuth } from "../contexts/session";
import useResource from "../hooks/useResource";
import useOptions from "../hooks/useOptions";
import { api, errorMessage } from "../services/api";
import ResourceState, { Pagination } from "../components/ResourceState";
import {
  PageHeading,
  Table,
  Cell,
  Modal,
  Confirm,
  Field,
  ErrorNotice,
  SuccessNotice,
  inputClass,
  buttonClass,
  secondaryClass,
} from "../components/ui";

export default function Documents({ kind }) {
  const { user } = useAuth();
  const sale = kind === "sale",
    currency = user.organization.currency;
  const writable =
    ["owner", "manager"].includes(user.role) ||
    (user.role === "seller" && sale);
  const [page, setPage] = useState(1),
    [search, setSearch] = useState(""),
    [status, setStatus] = useState(""),
    [editing, setEditing] = useState(null),
    [detail, setDetail] = useState(null),
    [confirm, setConfirm] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState("");
  const resource = useResource(
    `documents/?${new URLSearchParams({ kind, page, search, status })}`,
  );
  const products = useOptions("products/?active=true&ordering=name");
  const partners = useOptions(
    `partners/?active=true&kind=${sale ? "customer" : "supplier"}&ordering=name`,
  );
  function open(doc) {
    setError("");
    setEditing(
      doc
        ? {
            ...doc,
            lines: doc.lines.map((l) => ({ ...l, product: String(l.product) })),
          }
        : {
            kind,
            partner: "",
            notes: "",
            lines: [{ product: "", quantity: "1", unit_price: "0" }],
          },
    );
  }
  function line(index, key, value) {
    setEditing({
      ...editing,
      lines: editing.lines.map((l, i) => {
        if (i !== index) return l;
        const next = { ...l, [key]: value };
        if (key === "product") {
          const p = products.rows.find((p) => String(p.id) === value);
          next.unit_price = p ? (sale ? p.sale_price : p.purchase_price) : "0";
        }
        return next;
      }),
    });
  }
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const values = {
        kind,
        partner: editing.partner ? Number(editing.partner) : null,
        notes: editing.notes,
        lines: editing.lines.map((l) => ({
          product: Number(l.product),
          quantity: l.quantity,
          unit_price: l.unit_price,
        })),
      };
      await api[editing.id ? "patch" : "post"](
        editing.id ? `documents/${editing.id}/` : "documents/",
        values,
      );
      setEditing(null);
      setSuccess(
        "Brouillon enregistré. Validez-le pour appliquer le mouvement de stock.",
      );
      resource.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  async function transition() {
    setBusy(true);
    setError("");
    try {
      await api.post(`documents/${confirm.doc.id}/${confirm.action}/`);
      setConfirm(null);
      setSuccess(
        "Document mis à jour ; le stock et l’historique ont été actualisés.",
      );
      resource.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        title={sale ? "Ventes" : "Achats"}
        subtitle={
          sale
            ? "Enregistrez une vente, puis validez la sortie de stock."
            : "Préparez un achat, puis validez sa réception pour entrer le stock."
        }
      >
        {writable && (
          <button className={buttonClass} onClick={() => open(null)}>
            <Plus size={17} />
            Nouveau brouillon
          </button>
        )}
      </PageHeading>
      <SuccessNotice message={success} />
      <ErrorNotice message={products.error || partners.error} />
      {!editing && !confirm && <ErrorNotice message={error} />}
      <div className="grid gap-3 sm:grid-cols-2">
        <input
          aria-label="Rechercher un document"
          className={inputClass}
          placeholder="Référence ou partenaire…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
        />
        <select
          aria-label="Statut des documents"
          className={inputClass}
          value={status}
          onChange={(e) => {
            setStatus(e.target.value);
            setPage(1);
          }}
        >
          <option value="">Tous les statuts</option>
          <option value="draft">Brouillons</option>
          <option value="completed">Validés</option>
          <option value="cancelled">Annulés</option>
        </select>
      </div>
      <ResourceState resource={resource}>
        <Table
          headers={[
            "Référence",
            "Partenaire",
            "Date",
            "Total",
            "Statut",
            "Actions",
          ]}
        >
          {resource.data?.results.map((d) => (
            <tr key={d.id}>
              <Cell>
                <span className="font-mono text-xs">
                  {d.reference.slice(0, 8).toUpperCase()}
                </span>
              </Cell>
              <Cell>{d.partner_name || "Sans partenaire"}</Cell>
              <Cell>{date(d.created_at)}</Cell>
              <Cell>{money(d.total, currency)}</Cell>
              <Cell>
                <span
                  className={`rounded-full px-2 py-1 text-xs ${d.status === "completed" ? "bg-green-50 text-green-800" : d.status === "cancelled" ? "bg-red-50 text-red-800" : "bg-amber-50 text-amber-800"}`}
                >
                  {
                    {
                      draft: "Brouillon",
                      completed: "Validé",
                      cancelled: "Annulé",
                    }[d.status]
                  }
                </span>
              </Cell>
              <Cell>
                <div className="flex flex-wrap gap-2">
                  <button
                    className={secondaryClass}
                    onClick={() => setDetail(d)}
                  >
                    Détails
                  </button>
                  {writable && d.status === "draft" && (
                    <>
                      <button
                        className={secondaryClass}
                        onClick={() => open(d)}
                      >
                        Modifier
                      </button>
                      <button
                        className={buttonClass}
                        onClick={() => {
                          setError("");
                          setConfirm({ doc: d, action: "complete" });
                        }}
                      >
                        {sale ? "Valider" : "Réceptionner"}
                      </button>
                    </>
                  )}
                  {writable && d.status !== "cancelled" && (
                    <button
                      className={secondaryClass}
                      onClick={() => {
                        setError("");
                        setConfirm({ doc: d, action: "cancel" });
                      }}
                    >
                      Annuler
                    </button>
                  )}
                </div>
              </Cell>
            </tr>
          ))}
        </Table>
      </ResourceState>
      <Pagination resource={resource} page={page} setPage={setPage} />
      {editing && (
        <Modal
          title={
            editing.id
              ? "Modifier le brouillon"
              : sale
                ? "Nouvelle vente"
                : "Nouvel achat"
          }
          onClose={busy ? () => {} : () => setEditing(null)}
        >
          <form onSubmit={save} className="space-y-5">
            <ErrorNotice message={error} />
            <Field label={sale ? "Client" : "Fournisseur"}>
              <select
                className={inputClass}
                value={editing.partner || ""}
                onChange={(e) =>
                  setEditing({ ...editing, partner: e.target.value })
                }
              >
                <option value="">Sans partenaire</option>
                {partners.rows.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </Field>
            <div className="space-y-3">
              {editing.lines.map((l, i) => (
                <div
                  key={i}
                  className="grid gap-3 rounded-xl border border-slate-200 p-3 sm:grid-cols-[2fr_1fr_1fr_auto]"
                >
                  <Field label="Produit">
                    <select
                      required
                      className={inputClass}
                      value={l.product}
                      onChange={(e) => line(i, "product", e.target.value)}
                    >
                      <option value="">Sélectionner…</option>
                      {products.rows.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({qty(p.quantity)} {p.unit})
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Quantité">
                    <input
                      required
                      type="number"
                      min=".001"
                      step=".001"
                      className={inputClass}
                      value={l.quantity}
                      onChange={(e) => line(i, "quantity", e.target.value)}
                    />
                  </Field>
                  <Field label={`Prix (${currency})`}>
                    <input
                      required
                      type="number"
                      min="0"
                      step=".01"
                      className={inputClass}
                      value={l.unit_price}
                      onChange={(e) => line(i, "unit_price", e.target.value)}
                    />
                  </Field>
                  <button
                    type="button"
                    aria-label="Retirer la ligne"
                    disabled={editing.lines.length === 1}
                    onClick={() =>
                      setEditing({
                        ...editing,
                        lines: editing.lines.filter((_, j) => i !== j),
                      })
                    }
                    className={`${secondaryClass} self-end`}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              disabled={editing.lines.length >= 100}
              className={secondaryClass}
              onClick={() =>
                setEditing({
                  ...editing,
                  lines: [
                    ...editing.lines,
                    { product: "", quantity: "1", unit_price: "0" },
                  ],
                })
              }
            >
              <Plus size={16} />
              Ajouter une ligne
            </button>
            <Field label="Notes">
              <textarea
                className={inputClass}
                rows={2}
                value={editing.notes}
                onChange={(e) =>
                  setEditing({ ...editing, notes: e.target.value })
                }
              />
            </Field>
            <p className="text-sm text-slate-500">
              Le stock est vérifié et modifié au moment de la validation. Un
              brouillon ne réserve pas de stock. Le total définitif est calculé
              par le serveur.
            </p>
            <button disabled={busy} className={buttonClass}>
              {busy ? "Enregistrement…" : "Enregistrer le brouillon"}
            </button>
          </form>
        </Modal>
      )}
      {detail && (
        <Modal
          title={`Document ${detail.reference.slice(0, 8).toUpperCase()}`}
          onClose={() => setDetail(null)}
        >
          <div className="space-y-4">
            <p>
              {detail.partner_name || "Sans partenaire"} ·{" "}
              {date(detail.created_at)}
            </p>
            <div className="divide-y divide-slate-100">
              {detail.lines.map((l) => (
                <div
                  key={l.id}
                  className="flex flex-wrap justify-between gap-3 py-3"
                >
                  <span>
                    {l.product_name} × {qty(l.quantity)}
                  </span>
                  <span>{money(l.unit_price, currency)} / unité</span>
                </div>
              ))}
            </div>
            <p className="text-lg font-bold">
              Total : {money(detail.total, currency)}
            </p>
            <p className="text-slate-500">{detail.notes || "Aucune note."}</p>
            <p className="text-xs text-slate-500">
              Validé : {date(detail.completed_at)} · Annulé :{" "}
              {date(detail.cancelled_at)}
            </p>
          </div>
        </Modal>
      )}
      {confirm && (
        <Confirm
          title={
            confirm.action === "cancel"
              ? "Annuler ce document ?"
              : sale
                ? "Valider la vente ?"
                : "Réceptionner cet achat ?"
          }
          text={
            confirm.action === "cancel"
              ? "Un document validé entraîne un mouvement inverse complet. Une réception déjà consommée ne peut pas être annulée si elle rend le stock négatif. Les retours partiels ne sont pas disponibles."
              : sale
                ? "Cette action sortira les quantités du stock. Elle sera refusée si le stock est insuffisant."
                : "Cette action entrera toutes les quantités en stock."
          }
          onClose={() => setConfirm(null)}
          onConfirm={transition}
          busy={busy}
          error={error}
        />
      )}
    </>
  );
}
