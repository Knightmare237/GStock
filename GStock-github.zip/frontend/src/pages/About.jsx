import AnimatedSection from "../components/AnimatedSection";
export default function About() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <p className="text-sm font-semibold text-blue-600">À PROPOS DE GSTOCK</p>
      <h1 className="mt-3 max-w-3xl text-3xl font-bold sm:text-4xl">
        Rendre le stock plus clair, les opérations plus fiables.
      </h1>
      <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-600">
        GStock accompagne les entreprises, commerces et équipes qui souhaitent
        retrouver leurs produits, suivre les quantités et comprendre leurs
        opérations dans un même espace.
      </p>
      <div className="mt-12 grid gap-6 md:grid-cols-2">
        {[
          [
            "Notre mission",
            "Réduire la dispersion des informations et donner aux équipes une base commune pour le catalogue, les mouvements, les achats et les ventes.",
          ],
          [
            "Notre vision",
            "Une solution web simple à maintenir et à faire évoluer, avec une interface réutilisable pour une future application Windows.",
          ],
          [
            "La traçabilité avant tout",
            "Une quantité ne change pas sans un mouvement associé. Les validations et annulations conservent le contexte de l’opération plutôt que d’effacer l’historique.",
          ],
          [
            "Des accès adaptés",
            "Chaque organisation conserve son espace de données. Les permissions sont contrôlées par le serveur pour encadrer les responsabilités de chaque utilisateur.",
          ],
        ].map(([title, text]) => (
          <AnimatedSection
            key={title}
            className="rounded-2xl border border-slate-200 p-6"
          >
            <h2 className="text-lg font-bold">{title}</h2>
            <p className="mt-3 leading-7 text-slate-600">{text}</p>
          </AnimatedSection>
        ))}
      </div>
    </section>
  );
}
