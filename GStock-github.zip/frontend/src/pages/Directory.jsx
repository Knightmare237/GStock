import { useState } from "react";
import { Plus, Pencil, Archive } from "lucide-react";
import { useAuth } from "../contexts/session";
import useResource from "../hooks/useResource";
import { api, errorMessage } from "../services/api";
import ResourceState, { Pagination } from "../components/ResourceState";
import {
  PageHeading,
  Table,
  Cell,
  Modal,
  Confirm,
  Field,
  ErrorNotice,
  SuccessNotice,
  inputClass,
  buttonClass,
  secondaryClass,
} from "../components/ui";

export default function Directory({ kind }) {
  const { user } = useAuth();
  const category = kind === "category";
  const url = category ? "categories/" : "partners/";
  const title = category
    ? "Catégories"
    : kind === "customer"
      ? "Clients"
      : "Fournisseurs";
  const writable =
    ["owner", "manager"].includes(user.role) ||
    (user.role === "seller" && kind === "customer");
  const [page, setPage] = useState(1),
    [search, setSearch] = useState(""),
    [active, setActive] = useState("true");
  const resource = useResource(
    `${url}?${new URLSearchParams({ page, search, active, kind: category ? "" : kind, ordering: "name" })}`,
  );
  const [editing, setEditing] = useState(null),
    [archive, setArchive] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState("");
  function open(item) {
    setError("");
    setEditing(
      item || {
        name: "",
        email: "",
        phone: "",
        address: "",
        kind,
        active: true,
      },
    );
  }
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const values = category
        ? { name: editing.name, active: editing.active }
        : editing;
      await api[editing.id ? "patch" : "post"](
        editing.id ? `${url}${editing.id}/` : url,
        values,
      );
      setEditing(null);
      setSuccess("Informations enregistrées.");
      resource.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  async function changeStatus() {
    setBusy(true);
    setError("");
    try {
      await api.patch(`${url}${archive.id}/`, { active: !archive.active });
      setArchive(null);
      setSuccess("Statut mis à jour.");
      resource.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        title={title}
        subtitle="Organisez vos données et conservez leur historique."
      >
        {writable && (
          <button className={buttonClass} onClick={() => open(null)}>
            <Plus size={17} />
            Ajouter
          </button>
        )}
      </PageHeading>
      <SuccessNotice message={success} />
      {!editing && !archive && <ErrorNotice message={error} />}
      <div className="flex flex-col gap-3 sm:flex-row">
        <input
          aria-label={`Rechercher dans ${title}`}
          className={inputClass}
          placeholder="Rechercher…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
        />
        <select
          aria-label="Statut"
          className={inputClass}
          value={active}
          onChange={(e) => {
            setActive(e.target.value);
            setPage(1);
          }}
        >
          <option value="true">Actifs</option>
          <option value="false">Archivés</option>
          <option value="">Tous</option>
        </select>
      </div>
      <ResourceState resource={resource}>
        <Table
          headers={
            category
              ? ["Nom", "Statut", "Actions"]
              : ["Nom", "Email", "Téléphone", "Statut", "Actions"]
          }
        >
          {resource.data?.results.map((item) => (
            <tr key={item.id}>
              <Cell>
                <p className="font-semibold">{item.name}</p>
                {!category && (
                  <p className="text-xs text-slate-500">{item.address}</p>
                )}
              </Cell>
              {!category && (
                <>
                  <Cell>{item.email || "—"}</Cell>
                  <Cell>{item.phone || "—"}</Cell>
                </>
              )}
              <Cell>{item.active ? "Actif" : "Archivé"}</Cell>
              <Cell>
                {writable && (
                  <div className="flex gap-2">
                    <button
                      aria-label={`Modifier ${item.name}`}
                      className={secondaryClass}
                      onClick={() => open(item)}
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      aria-label={`Changer le statut de ${item.name}`}
                      className={secondaryClass}
                      onClick={() => {
                        setError("");
                        setArchive(item);
                      }}
                    >
                      <Archive size={16} />
                    </button>
                  </div>
                )}
              </Cell>
            </tr>
          ))}
        </Table>
      </ResourceState>
      <Pagination resource={resource} page={page} setPage={setPage} />
      {editing && (
        <Modal
          title={editing.id ? "Modifier" : "Ajouter"}
          onClose={busy ? () => {} : () => setEditing(null)}
        >
          <form onSubmit={save} className="space-y-5">
            <ErrorNotice message={error} />
            {(category ? ["name"] : ["name", "email", "phone", "address"]).map(
              (key) => (
                <Field
                  key={key}
                  label={
                    {
                      name: "Nom",
                      email: "Email",
                      phone: "Téléphone",
                      address: "Adresse",
                    }[key]
                  }
                >
                  <input
                    required={key === "name"}
                    maxLength={
                      key === "name"
                        ? category
                          ? 120
                          : 160
                        : key === "phone"
                          ? 40
                          : undefined
                    }
                    className={inputClass}
                    type={key === "email" ? "email" : "text"}
                    value={editing[key]}
                    onChange={(e) =>
                      setEditing({ ...editing, [key]: e.target.value })
                    }
                  />
                </Field>
              ),
            )}
            <button className={buttonClass} disabled={busy}>
              {busy ? "Enregistrement…" : "Enregistrer"}
            </button>
          </form>
        </Modal>
      )}
      {archive && (
        <Confirm
          title="Changer le statut ?"
          text={
            category
              ? "Une catégorie utilisée par des produits actifs ne peut pas être archivée. Reclassifiez ces produits si nécessaire."
              : "L’historique sera conservé. Un partenaire archivé ne pourra plus être sélectionné pour un nouveau document."
          }
          onClose={() => setArchive(null)}
          onConfirm={changeStatus}
          busy={busy}
          error={error}
        />
      )}
    </>
  );
}
