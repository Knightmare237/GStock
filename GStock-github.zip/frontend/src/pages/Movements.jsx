import { date, qty } from "../services/format";
import { useState } from "react";
import useResource from "../hooks/useResource";
import useOptions from "../hooks/useOptions";
import { useAuth } from "../contexts/session";
import { api, errorMessage } from "../services/api";
import ResourceState, { Pagination } from "../components/ResourceState";
import {
  PageHeading,
  Table,
  Cell,
  Modal,
  Field,
  ErrorNotice,
  SuccessNotice,
  inputClass,
  buttonClass,
} from "../components/ui";
export default function Movements() {
  const { user } = useAuth();
  const [page, setPage] = useState(1),
    [search, setSearch] = useState(""),
    [open, setOpen] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState(""),
    [revision, setRevision] = useState(0);
  const resource = useResource(
    `movements/?${new URLSearchParams({ page, search })}`,
  );
  const products = useOptions("products/?active=true&ordering=name", revision);
  const [form, setForm] = useState({
    product: "",
    type: "entry",
    quantity: "",
    reason: "",
  });
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const delta = Number(form.quantity) * (form.type === "exit" ? -1 : 1);
      await api.post("movements/adjust/", {
        product: Number(form.product),
        delta,
        reason: `${form.type === "adjust" ? "Ajustement" : form.type === "entry" ? "Entrée" : "Sortie"} : ${form.reason}`,
      });
      setOpen(false);
      setForm({ product: "", type: "entry", quantity: "", reason: "" });
      setSuccess("Mouvement enregistré.");
      resource.reload();
      setRevision((v) => v + 1);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        title="Mouvements de stock"
        subtitle="Chaque variation est enregistrée avec son motif et son responsable."
      >
        {["owner", "manager"].includes(user.role) && (
          <button
            className={buttonClass}
            onClick={() => {
              setError("");
              setOpen(true);
            }}
          >
            Nouveau mouvement
          </button>
        )}
      </PageHeading>
      <SuccessNotice message={success} />
      <ErrorNotice message={products.error} />
      {!open && <ErrorNotice message={error} />}
      <input
        aria-label="Rechercher un mouvement"
        className={inputClass}
        value={search}
        placeholder="Produit, référence ou motif…"
        onChange={(e) => {
          setSearch(e.target.value);
          setPage(1);
        }}
      />
      <ResourceState resource={resource}>
        <Table
          headers={[
            "Date",
            "Produit",
            "Variation",
            "Stock après",
            "Motif",
            "Responsable",
          ]}
        >
          {resource.data?.results.map((m) => (
            <tr key={m.id}>
              <Cell>{date(m.created_at)}</Cell>
              <Cell>{m.product_name}</Cell>
              <Cell>
                <span
                  className={
                    Number(m.delta) > 0
                      ? "font-semibold text-green-700"
                      : "font-semibold text-red-700"
                  }
                >
                  {Number(m.delta) > 0 ? "+" : ""}
                  {qty(m.delta)}
                </span>
              </Cell>
              <Cell>{qty(m.balance)}</Cell>
              <Cell>{m.reason}</Cell>
              <Cell>{m.user_name}</Cell>
            </tr>
          ))}
        </Table>
      </ResourceState>
      <Pagination resource={resource} page={page} setPage={setPage} />
      {open && (
        <Modal
          title="Nouveau mouvement"
          onClose={busy ? () => {} : () => setOpen(false)}
        >
          <form onSubmit={submit} className="space-y-5">
            <ErrorNotice message={error} />
            <Field label="Produit">
              <select
                required
                className={inputClass}
                value={form.product}
                onChange={(e) => setForm({ ...form, product: e.target.value })}
              >
                <option value="">Sélectionner…</option>
                {products.rows.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} · {qty(p.quantity)} {p.unit}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Type">
              <select
                className={inputClass}
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value })}
              >
                <option value="entry">Entrée</option>
                <option value="exit">Sortie</option>
                <option value="adjust">Correction par variation signée</option>
              </select>
            </Field>
            <Field
              label={
                form.type === "adjust"
                  ? "Variation (+ ou −), pas le stock final"
                  : "Quantité"
              }
            >
              <input
                required
                className={inputClass}
                type="number"
                step=".001"
                min={form.type === "adjust" ? undefined : ".001"}
                value={form.quantity}
                onChange={(e) => setForm({ ...form, quantity: e.target.value })}
              />
            </Field>
            <Field label="Motif">
              <input
                required
                minLength={3}
                maxLength={220}
                className={inputClass}
                value={form.reason}
                onChange={(e) => setForm({ ...form, reason: e.target.value })}
              />
            </Field>
            <p className="text-sm text-slate-500">
              Un mouvement ne peut pas être supprimé. Une erreur se corrige par
              un nouveau mouvement explicite ; le stock négatif est refusé.
            </p>
            <button disabled={busy} className={buttonClass}>
              {busy ? "Enregistrement…" : "Enregistrer le mouvement"}
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}
