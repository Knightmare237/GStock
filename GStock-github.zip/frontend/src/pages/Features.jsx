import { Link } from "react-router-dom";
import {
  Package,
  ArrowLeftRight,
  ShoppingCart,
  Users,
  ShieldCheck,
  BarChart3,
} from "lucide-react";

const modules = [
  [
    Package,
    "Produits et catégories",
    "Créez, recherchez et archivez vos produits. Gérez références, prix, unités, seuils et images. La quantité initiale est enregistrée dans l’historique.",
  ],
  [
    ArrowLeftRight,
    "Mouvements de stock",
    "Consultez chaque entrée, sortie et correction avec son motif, son responsable et le stock résultant. Les stocks négatifs sont refusés.",
  ],
  [
    ShoppingCart,
    "Ventes et achats",
    "Préparez des documents à plusieurs lignes. La validation applique le mouvement de stock ; une annulation complète conserve la trace inverse.",
  ],
  [
    Users,
    "Clients et fournisseurs",
    "Centralisez noms, emails, téléphones et adresses. Archivez les partenaires tout en conservant les opérations passées.",
  ],
  [
    ShieldCheck,
    "Comptes et accès",
    "Chaque compte appartient à une organisation. Les rôles administrateur, gestionnaire, vendeur, comptable et lecteur encadrent les opérations autorisées.",
  ],
  [
    BarChart3,
    "Tableau de bord et rapports",
    "Consultez stock, alertes, achats et ventes réels. Filtrez les périodes et exportez le catalogue, les mouvements et les documents en CSV ou Excel.",
  ],
];
export default function Features() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <p className="text-sm font-semibold text-blue-600">LES MODULES GSTOCK</p>
      <h1 className="mt-3 text-3xl font-bold sm:text-4xl">
        Une gestion structurée, de votre catalogue à vos ventes.
      </h1>
      <p className="mt-5 max-w-3xl leading-7 text-slate-600">
        Les modules ci-dessous sont connectés à l’API. Leur disponibilité dépend
        de votre rôle et de la configuration du serveur.
      </p>
      <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {modules.map(([Icon, title, text]) => (
          <article
            key={title}
            className="rounded-2xl border border-slate-200 bg-white p-6"
          >
            <Icon className="text-blue-600" size={26} />
            <h2 className="mt-5 text-lg font-bold">{title}</h2>
            <p className="mt-3 text-sm leading-7 text-slate-600">{text}</p>
          </article>
        ))}
      </div>
      <div className="mt-10 rounded-2xl bg-slate-50 p-6">
        <h2 className="font-bold">Périmètre de cette version</h2>
        <p className="mt-3 text-sm leading-7 text-slate-600">
          Une organisation par compte, une devise par organisation et des
          réceptions complètes. La valorisation utilise les prix d’achat actuels
          ; elle ne constitue pas une comptabilité FIFO. Les retours partiels,
          taxes, règlements, exports PDF et travail hors ligne ne sont pas
          disponibles. Les emails nécessitent un service SMTP configuré. La
          version desktop et les licences restent sur la feuille de route. Le
          catalogue accepte l’import CSV et Excel XLSX de nouveaux produits,
          avec aperçu et validation avant confirmation (1 000 lignes, 5 Mo
          maximum).
        </p>
      </div>
      <Link
        to="/register"
        className="mt-8 inline-block rounded-xl bg-blue-600 px-6 py-3 font-semibold text-white"
      >
        Créer votre espace
      </Link>
    </section>
  );
}
