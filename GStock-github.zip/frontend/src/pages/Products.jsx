import { money, qty } from "../services/format";
import { useState } from "react";
import { Plus, Pencil, Archive, Eye, Package, Upload } from "lucide-react";
import ProductImport from "../components/ProductImport";
import useResource from "../hooks/useResource";
import useOptions from "../hooks/useOptions";
import { api, errorMessage, download } from "../services/api";
import { useAuth } from "../contexts/session";
import ResourceState, { Pagination } from "../components/ResourceState";
import {
  PageHeading,
  Table,
  Cell,
  Field,
  Modal,
  Confirm,
  ErrorNotice,
  SuccessNotice,
  inputClass,
  buttonClass,
  secondaryClass,
} from "../components/ui";

const blank = {
  sku: "",
  name: "",
  description: "",
  category: "",
  barcode: "",
  purchase_price: "0",
  sale_price: "0",
  initial_quantity: "0",
  minimum_stock: "0",
  unit: "unité",
  active: true,
};
export default function Products() {
  const [importing, setImporting] = useState(false);
  const { user } = useAuth();
  const writable = ["owner", "manager"].includes(user.role);
  const [search, setSearch] = useState(""),
    [category, setCategory] = useState(""),
    [active, setActive] = useState("true"),
    [ordering, setOrdering] = useState("name"),
    [page, setPage] = useState(1);
  const resource = useResource(
    `products/?${new URLSearchParams({ search, category, active, ordering, page })}`,
  );
  const categories = useOptions("categories/?active=true&ordering=name");
  const [editing, setEditing] = useState(null),
    [detail, setDetail] = useState(null),
    [archive, setArchive] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState(""),
    [file, setFile] = useState(null);
  function open(product) {
    setEditing(product ? { ...product } : { ...blank });
    setFile(null);
    setError("");
  }
  function filter(fn, value) {
    fn(value);
    setPage(1);
  }
  function field(key, label, type = "text") {
    return (
      <Field label={label}>
        <input
          required={!["barcode", "description"].includes(key)}
          className={inputClass}
          type={type}
          min={type === "number" ? 0 : undefined}
          step={
            ["initial_quantity", "minimum_stock"].includes(key) ? ".001" : ".01"
          }
          maxLength={
            key === "name"
              ? 160
              : key === "unit"
                ? 30
                : key === "sku" || key === "barcode"
                  ? 80
                  : undefined
          }
          value={editing[key] ?? ""}
          onChange={(e) => setEditing({ ...editing, [key]: e.target.value })}
        />
      </Field>
    );
  }
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const values = {
        ...editing,
        category: editing.category ? Number(editing.category) : null,
      };
      if (editing.id) delete values.initial_quantity;
      const { data } = await api[editing.id ? "patch" : "post"](
        editing.id ? `products/${editing.id}/` : "products/",
        values,
      );
      setEditing(data);
      if (file) {
        const form = new FormData();
        form.append("image", file);
        await api.post(`products/${data.id}/image/`, form);
      }
      setEditing(null);
      setSuccess("Produit enregistré.");
      resource.reload();
    } catch (err) {
      setError(errorMessage(err));
      resource.reload();
    } finally {
      setBusy(false);
    }
  }
  async function archiveProduct() {
    setBusy(true);
    setError("");
    try {
      await api.patch(`products/${archive.id}/`, { active: !archive.active });
      setArchive(null);
      setSuccess("Statut du produit mis à jour.");
      resource.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  async function exportProducts() {
    setError("");
    try {
      await download("products", "csv");
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  return (
    <>
      {importing && (
        <ProductImport
          onClose={() => setImporting(false)}
          onImported={(count) => {
            setImporting(false);
            setSuccess(`${count} produit(s) importé(s).`);
            resource.reload();
          }}
        />
      )}
      <PageHeading
        title="Produits"
        subtitle="Votre catalogue, vos prix et vos niveaux de stock."
      >
        <div className="flex flex-wrap gap-2">
          {writable && (
            <button
              className={secondaryClass}
              onClick={() => setImporting(true)}
            >
              <Upload size={17} />
              Importer des produits
            </button>
          )}
          {["owner", "manager", "accountant"].includes(user.role) && (
            <button className={secondaryClass} onClick={exportProducts}>
              Exporter CSV
            </button>
          )}
          {writable && (
            <button className={buttonClass} onClick={() => open(null)}>
              <Plus size={17} />
              Ajouter un produit
            </button>
          )}
        </div>
      </PageHeading>
      <SuccessNotice message={success} />
      {!editing && !archive && <ErrorNotice message={error} />}
      <ErrorNotice message={categories.error} />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <input
          aria-label="Rechercher un produit"
          className={inputClass}
          placeholder="Nom, référence ou code-barres…"
          value={search}
          onChange={(e) => filter(setSearch, e.target.value)}
        />
        <select
          aria-label="Filtrer par catégorie"
          className={inputClass}
          value={category}
          onChange={(e) => filter(setCategory, e.target.value)}
        >
          <option value="">Toutes les catégories</option>
          {categories.rows.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          aria-label="Filtrer par statut"
          className={inputClass}
          value={active}
          onChange={(e) => filter(setActive, e.target.value)}
        >
          <option value="true">Actifs</option>
          <option value="false">Archivés</option>
          <option value="">Tous les statuts</option>
        </select>
        <select
          aria-label="Trier les produits"
          className={inputClass}
          value={ordering}
          onChange={(e) => filter(setOrdering, e.target.value)}
        >
          <option value="name">Nom A–Z</option>
          <option value="-created_at">Plus récents</option>
          <option value="quantity">Stock croissant</option>
          <option value="-quantity">Stock décroissant</option>
          <option value="sku">Référence</option>
        </select>
      </div>
      <ResourceState
        resource={resource}
        empty="Aucun produit trouvé. Ajoutez un produit ou modifiez les filtres."
      >
        <Table
          headers={[
            "Produit",
            "Catégorie",
            "Stock",
            "Prix vente",
            "Statut",
            "Actions",
          ]}
        >
          {resource.data?.results.map((p) => (
            <tr key={p.id}>
              <Cell>
                <div className="flex items-center gap-3">
                  {p.image_url ? (
                    <img
                      src={p.image_url}
                      alt=""
                      className="h-10 w-10 rounded-lg object-cover"
                    />
                  ) : (
                    <Package size={20} className="text-blue-500" />
                  )}
                  <div>
                    <p className="font-semibold">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.sku}</p>
                  </div>
                </div>
              </Cell>
              <Cell>{p.category_name || "—"}</Cell>
              <Cell>
                <span
                  className={
                    Number(p.quantity) <= Number(p.minimum_stock)
                      ? "font-semibold text-orange-700"
                      : ""
                  }
                >
                  {qty(p.quantity)} {p.unit}
                </span>
              </Cell>
              <Cell>{money(p.sale_price, user.organization.currency)}</Cell>
              <Cell>{p.active ? "Actif" : "Archivé"}</Cell>
              <Cell>
                <div className="flex gap-2">
                  <button
                    className={secondaryClass}
                    aria-label={`Détails de ${p.name}`}
                    onClick={() => setDetail(p)}
                  >
                    <Eye size={16} />
                  </button>
                  {writable && (
                    <>
                      <button
                        className={secondaryClass}
                        aria-label={`Modifier ${p.name}`}
                        onClick={() => open(p)}
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        className={secondaryClass}
                        aria-label={`${p.active ? "Archiver" : "Réactiver"} ${p.name}`}
                        onClick={() => {
                          setError("");
                          setArchive(p);
                        }}
                      >
                        <Archive size={16} />
                      </button>
                    </>
                  )}
                </div>
              </Cell>
            </tr>
          ))}
        </Table>
      </ResourceState>
      <Pagination resource={resource} page={page} setPage={setPage} />
      {editing && (
        <Modal
          title={editing.id ? "Modifier le produit" : "Ajouter un produit"}
          onClose={busy ? () => {} : () => setEditing(null)}
        >
          <form className="space-y-5" onSubmit={save}>
            <ErrorNotice message={error} />
            <div className="grid gap-4 sm:grid-cols-2">
              {field("name", "Nom")}
              {field("sku", "Référence / SKU")}
              <Field label="Catégorie">
                <select
                  className={inputClass}
                  value={editing.category || ""}
                  onChange={(e) =>
                    setEditing({ ...editing, category: e.target.value })
                  }
                >
                  <option value="">Sans catégorie</option>
                  {categories.rows.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </Field>
              {field("barcode", "Code-barres")}
              {field("purchase_price", "Prix d’achat", "number")}
              {field("sale_price", "Prix de vente", "number")}
              {!editing.id &&
                field("initial_quantity", "Quantité initiale", "number")}
              {field("minimum_stock", "Seuil minimum", "number")}
              {field("unit", "Unité")}
            </div>
            <Field label="Description">
              <textarea
                className={inputClass}
                rows={3}
                value={editing.description}
                onChange={(e) =>
                  setEditing({ ...editing, description: e.target.value })
                }
              />
            </Field>
            <Field label="Image (JPEG, PNG, WebP ; 5 Mo maximum)">
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className={inputClass}
                onChange={(e) => setFile(e.target.files[0] || null)}
              />
            </Field>
            <p className="text-xs text-slate-500">
              Les changements de quantité après création passent par un
              mouvement de stock.
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                disabled={busy}
                onClick={() => setEditing(null)}
                className={secondaryClass}
              >
                Annuler
              </button>
              <button disabled={busy} className={buttonClass}>
                {busy ? "Enregistrement…" : "Enregistrer"}
              </button>
            </div>
          </form>
        </Modal>
      )}
      {detail && (
        <Modal title={detail.name} onClose={() => setDetail(null)}>
          <div className="space-y-4">
            {detail.image_url && (
              <img
                src={detail.image_url}
                alt={detail.name}
                className="max-h-56 rounded-xl object-contain"
              />
            )}
            <p className="text-sm text-slate-500">
              Référence : {detail.sku} · Code-barres : {detail.barcode || "—"}
            </p>
            <p>{detail.description || "Aucune description."}</p>
            <p>
              Stock : {qty(detail.quantity)} {detail.unit} · Seuil :{" "}
              {qty(detail.minimum_stock)}
            </p>
            <p>
              Achat : {money(detail.purchase_price, user.organization.currency)}{" "}
              · Vente : {money(detail.sale_price, user.organization.currency)}
            </p>
          </div>
        </Modal>
      )}
      {archive && (
        <Confirm
          title={
            archive.active ? "Archiver ce produit ?" : "Réactiver ce produit ?"
          }
          text="L’historique et les mouvements seront conservés."
          onClose={() => setArchive(null)}
          onConfirm={archiveProduct}
          busy={busy}
          error={error}
        />
      )}
    </>
  );
}
