import { useState } from "react";
import { useAuth } from "../contexts/session";
import useResource from "../hooks/useResource";
import { api, errorMessage } from "../services/api";
import {
  PageHeading,
  Field,
  Table,
  Cell,
  ErrorNotice,
  SuccessNotice,
  inputClass,
  buttonClass,
  secondaryClass,
} from "../components/ui";
import ResourceState from "../components/ResourceState";
const roles = {
  manager: "Gestionnaire",
  seller: "Vendeur",
  accountant: "Comptable",
  reader: "Lecteur",
};
export default function Settings() {
  const { user, refresh } = useAuth();
  const [name, setName] = useState(user.name),
    [email, setEmail] = useState(user.email),
    [profilePassword, setProfilePassword] = useState(""),
    [orgName, setOrgName] = useState(user.organization.name),
    [currency, setCurrency] = useState(user.organization.currency),
    [password, setPassword] = useState({
      current_password: "",
      password: "",
      confirmation: "",
    }),
    [invite, setInvite] = useState({ name: "", email: "", role: "reader" }),
    [error, setError] = useState(""),
    [success, setSuccess] = useState(""),
    [busy, setBusy] = useState(false);
  const members = useResource(
    user.role === "owner" ? "members/" : "organization/",
  );
  async function run(task, message) {
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      await task();
      setSuccess(message);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  async function profile(e) {
    e.preventDefault();
    await run(async () => {
      await api.patch("auth/me/", {
        name,
        email,
        current_password: profilePassword,
      });
      setProfilePassword("");
      await refresh();
    }, "Profil enregistré.");
  }
  async function organization(e) {
    e.preventDefault();
    await run(async () => {
      await api.patch("organization/", { name: orgName, currency });
      await refresh();
    }, "Organisation mise à jour.");
  }
  async function changePassword(e) {
    e.preventDefault();
    if (password.password !== password.confirmation) {
      setError("Les mots de passe ne correspondent pas.");
      return;
    }
    await run(async () => {
      await api.post("auth/password/", password);
      setPassword({ current_password: "", password: "", confirmation: "" });
    }, "Mot de passe modifié.");
  }
  async function addMember(e) {
    e.preventDefault();
    await run(async () => {
      await api.post("members/", invite);
      setInvite({ name: "", email: "", role: "reader" });
      members.reload();
    }, "Accès créé et lien de choix du mot de passe envoyé. En mode email console, consulter le terminal backend.");
  }
  async function member(m, changes) {
    if (!window.confirm("Confirmer la modification de cet accès utilisateur ?"))
      return;
    await run(async () => {
      await api.patch(`members/${m.id}/`, {
        role: m.role,
        active: m.active,
        ...changes,
      });
      members.reload();
    }, "Accès mis à jour.");
  }
  return (
    <>
      <PageHeading
        title="Paramètres"
        subtitle="Votre profil, votre sécurité et votre organisation."
      />
      <ErrorNotice message={error} />
      <SuccessNotice message={success} />
      <div className="grid items-start gap-6 xl:grid-cols-2">
        <form
          onSubmit={profile}
          className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6"
        >
          <h2 className="font-bold">Profil</h2>
          <Field label="Nom complet">
            <input
              required
              maxLength={150}
              className={inputClass}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </Field>
          <Field label="Email de connexion">
            <input
              required
              type="email"
              maxLength={150}
              className={inputClass}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          {email !== user.email && (
            <Field label="Mot de passe actuel pour confirmer le changement d’email">
              <input
                required
                type="password"
                autoComplete="current-password"
                className={inputClass}
                value={profilePassword}
                onChange={(e) => setProfilePassword(e.target.value)}
              />
            </Field>
          )}
          <button disabled={busy} className={buttonClass}>
            Enregistrer
          </button>
        </form>
        <form
          onSubmit={changePassword}
          className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6"
        >
          <h2 className="font-bold">Changer le mot de passe</h2>
          {["current_password", "password", "confirmation"].map((key) => (
            <Field
              key={key}
              label={
                {
                  current_password: "Mot de passe actuel",
                  password: "Nouveau mot de passe",
                  confirmation: "Confirmer le nouveau mot de passe",
                }[key]
              }
            >
              <input
                required
                type="password"
                maxLength={128}
                minLength={key === "current_password" ? undefined : 10}
                autoComplete={
                  key === "current_password"
                    ? "current-password"
                    : "new-password"
                }
                className={inputClass}
                value={password[key]}
                onChange={(e) =>
                  setPassword({ ...password, [key]: e.target.value })
                }
              />
            </Field>
          ))}
          <button disabled={busy} className={buttonClass}>
            Changer le mot de passe
          </button>
        </form>
      </div>
      {user.role === "owner" && (
        <>
          <form
            onSubmit={organization}
            className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6"
          >
            <h2 className="font-bold">Organisation</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Nom de l’entreprise">
                <input
                  required
                  maxLength={120}
                  className={inputClass}
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                />
              </Field>
              <Field label="Devise">
                <select
                  className={inputClass}
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                >
                  {["XAF", "XOF", "EUR", "USD", "GBP"].map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </Field>
            </div>
            <p className="text-xs text-slate-500">
              La devise ne peut plus changer après création d’un document.
              Changer la devise ne convertit pas les prix existants.
            </p>
            <button disabled={busy} className={buttonClass}>
              Enregistrer l’organisation
            </button>
          </form>
          <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="font-bold">Accès des utilisateurs</h2>
            <ResourceState resource={members}>
              <Table headers={["Nom", "Email", "Rôle", "Accès"]}>
                {Array.isArray(members.data) &&
                  members.data.map((m) => (
                    <tr key={m.id}>
                      <Cell>{m.name}</Cell>
                      <Cell>{m.email}</Cell>
                      <Cell>
                        {m.id === user.id ? (
                          "Administrateur"
                        ) : (
                          <select
                            disabled={busy}
                            aria-label={`Rôle de ${m.name}`}
                            className={inputClass}
                            value={m.role}
                            onChange={(e) =>
                              member(m, { role: e.target.value })
                            }
                          >
                            {Object.entries(roles).map(([k, v]) => (
                              <option key={k} value={k}>
                                {v}
                              </option>
                            ))}
                          </select>
                        )}
                      </Cell>
                      <Cell>
                        {m.id === user.id ? (
                          "Actif"
                        ) : (
                          <button
                            disabled={busy}
                            className={secondaryClass}
                            onClick={() => member(m, { active: !m.active })}
                          >
                            {m.active ? "Désactiver" : "Réactiver"}
                          </button>
                        )}
                      </Cell>
                    </tr>
                  ))}
              </Table>
            </ResourceState>
            <form onSubmit={addMember} className="grid gap-4 sm:grid-cols-2">
              <Field label="Nom du nouvel utilisateur">
                <input
                  required
                  maxLength={150}
                  className={inputClass}
                  value={invite.name}
                  onChange={(e) =>
                    setInvite({ ...invite, name: e.target.value })
                  }
                />
              </Field>
              <Field label="Email">
                <input
                  required
                  type="email"
                  maxLength={150}
                  className={inputClass}
                  value={invite.email}
                  onChange={(e) =>
                    setInvite({ ...invite, email: e.target.value })
                  }
                />
              </Field>
              <Field label="Rôle">
                <select
                  className={inputClass}
                  value={invite.role}
                  onChange={(e) =>
                    setInvite({ ...invite, role: e.target.value })
                  }
                >
                  {Object.entries(roles).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </Field>
              <button disabled={busy} className={`${buttonClass} self-end`}>
                Créer l’accès et envoyer le lien
              </button>
            </form>
          </section>
        </>
      )}
    </>
  );
}
