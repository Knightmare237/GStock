import { useEffect, useState } from "react";
import { api, bootstrap, errorMessage } from "../services/api";
import {
  Field,
  inputClass,
  buttonClass,
  ErrorNotice,
  SuccessNotice,
} from "../components/ui";

function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
    website: "",
  });
  const [available, setAvailable] = useState(null),
    [error, setError] = useState(""),
    [success, setSuccess] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    bootstrap()
      .then((d) => setAvailable(d.contact_available))
      .catch((e) => setError(errorMessage(e)));
  }, []);
  async function submit(event) {
    event.preventDefault();
    setError("");
    setSuccess("");
    setBusy(true);
    try {
      await bootstrap();
      const { data } = await api.post("contact/", form);
      setSuccess(data.detail);
      setForm({ name: "", email: "", subject: "", message: "", website: "" });
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="mx-auto min-h-[70vh] max-w-3xl px-4 py-16 sm:px-6">
      <h1 className="text-3xl font-bold">Contactez GStock</h1>
      <p className="mt-4 leading-7 text-slate-500">
        Une question sur votre gestion de stock ou sur la configuration de la
        solution ? Décrivez votre besoin.
      </p>
      {available === false && (
        <p className="mt-6 rounded-xl bg-amber-50 p-4 text-sm text-amber-900">
          Le service de contact doit être configuré par l’administrateur avant
          de pouvoir envoyer un message.
        </p>
      )}
      <form onSubmit={submit} className="mt-8 space-y-5">
        <ErrorNotice message={error} />
        <SuccessNotice message={success} />
        {["name", "email", "subject"].map((key) => (
          <Field
            key={key}
            label={
              { name: "Votre nom", email: "Adresse email", subject: "Sujet" }[
                key
              ]
            }
          >
            <input
              required
              disabled={!available || busy}
              className={inputClass}
              type={key === "email" ? "email" : "text"}
              maxLength={key === "name" ? 120 : key === "subject" ? 160 : 254}
              value={form[key]}
              onChange={(e) => setForm({ ...form, [key]: e.target.value })}
            />
          </Field>
        ))}
        <Field label="Message">
          <textarea
            required
            disabled={!available || busy}
            className={inputClass}
            minLength={10}
            maxLength={5000}
            rows={6}
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
          />
        </Field>
        <div hidden>
          <label>
            Site web
            <input
              tabIndex={-1}
              autoComplete="off"
              value={form.website}
              onChange={(e) => setForm({ ...form, website: e.target.value })}
            />
          </label>
        </div>
        <button disabled={!available || busy} className={buttonClass}>
          {busy ? "Envoi…" : "Envoyer le message"}
        </button>
      </form>
    </section>
  );
}

export default Contact;
