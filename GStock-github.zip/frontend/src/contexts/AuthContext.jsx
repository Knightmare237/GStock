import { useCallback, useEffect, useState } from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { api, bootstrap, errorMessage } from "../services/api";

import { AuthContext, useAuth } from "./session";
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    setError("");
    try {
      await bootstrap();
      const response = await api.get("auth/me/");
      setUser(response.data);
    } catch (e) {
      setUser(null);
      if (![401, 403].includes(e.response?.status)) setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    refresh();
  }, [refresh]);
  useEffect(() => {
    const expired = () => setUser(null);
    window.addEventListener("gstock:session-expired", expired);
    return () => window.removeEventListener("gstock:session-expired", expired);
  }, []);
  async function authenticate(action, values) {
    await bootstrap();
    const { data } = await api.post(`auth/${action}/`, values);
    setUser(data);
    await bootstrap();
    return data;
  }
  async function signOut() {
    await api.post("auth/logout/");
    setUser(null);
    await bootstrap();
  }
  return (
    <AuthContext.Provider
      value={{ user, loading, error, refresh, authenticate, signOut }}
    >
      {children}
    </AuthContext.Provider>
  );
}
export function RequireAuth() {
  const { user, loading, error, refresh } = useAuth();
  const location = useLocation();
  if (loading)
    return (
      <div role="status" className="p-10 text-center">
        VÃ©rification de votre sessionâ€¦
      </div>
    );
  if (error)
    return (
      <div role="alert" className="p-10 text-center">
        {error}
        <button className="ml-4 text-blue-600" onClick={refresh}>
          RÃ©essayer
        </button>
      </div>
    );
  return user ? (
    <Outlet />
  ) : (
    <Navigate to="/login" state={{ from: location.pathname }} replace />
  );
}
