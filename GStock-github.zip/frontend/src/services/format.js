export function money(value, currency) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: currency || "XAF",
  }).format(Number(value || 0));
}
export function qty(value) {
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 3 }).format(
    Number(value || 0),
  );
}
export function date(value) {
  return value
    ? new Intl.DateTimeFormat("fr-FR", {
        dateStyle: "short",
        timeStyle: "short",
      }).format(new Date(value))
    : "—";
}

export function activityLabel(action) {
  return (
    {
      "account.register": "Espace créé",
      "account.login": "Connexion",
      "account.logout": "Déconnexion",
      "account.profile": "Profil modifié",
      "account.password": "Mot de passe modifié",
      "account.reset": "Mot de passe réinitialisé",
      "product.create": "Produit ajouté",
      "product.update": "Produit modifié",
      "product.image": "Image du produit modifiée",
      "product.image.delete": "Image retirée",
      "category.create": "Catégorie ajoutée",
      "category.update": "Catégorie modifiée",
      "partner.create": "Partenaire ajouté",
      "partner.update": "Partenaire modifié",
      "stock.movement": "Mouvement de stock",
      "document.create": "Brouillon créé",
      "document.update": "Brouillon modifié",
      "document.complete": "Document validé",
      "document.cancel": "Document annulé",
      "organization.update": "Organisation modifiée",
      "member.invite": "Accès utilisateur créé",
      "member.update": "Accès utilisateur modifié",
      "report.export": "Rapport exporté",
    }[action] || "Opération enregistrée"
  );
}
