import { test } from "node:test";
import assert from "node:assert/strict";
import { api, allPages, errorMessage, download } from "./api.js";

test("network errors are explicit", () => {
  assert.match(errorMessage(new Error("offline")), /serveur est inaccessible/);
});
test("server field validation and permission errors are displayed", () => {
  assert.equal(
    errorMessage({ response: { data: { sku: ["Déjà utilisée."] } } }),
    "sku : Déjà utilisée.",
  );
  assert.equal(
    errorMessage({ response: { data: { detail: "Accès refusé." } } }),
    "Accès refusé.",
  );
});
test("HTML failures do not expose an internal traceback", () => {
  assert.equal(
    errorMessage({ response: { data: "<html>Traceback SECRET</html>" } }),
    "Une erreur est survenue. Réessayez.",
  );
});
test("options follow every API page through the same-origin proxy", async () => {
  const original = api.get;
  const calls = [];
  api.get = async (url) => {
    calls.push(url);
    return {
      data: url.includes("page=2")
        ? { results: [{ id: 2 }], next: null }
        : {
            results: [{ id: 1 }],
            next: "http://127.0.0.1:8005/api/v1/products/?page=2",
          },
    };
  };
  try {
    assert.deepEqual(await allPages("products/"), [{ id: 1 }, { id: 2 }]);
    assert.deepEqual(calls, ["products/", "products/?page=2"]);
  } finally {
    api.get = original;
  }
});
test("a failed options page rejects rather than reporting an empty catalog", async () => {
  const original = api.get;
  api.get = async () => {
    throw new Error("offline");
  };
  try {
    await assert.rejects(allPages("categories/"), /offline/);
  } finally {
    api.get = original;
  }
});

test("a failed export retains the JSON validation message from a blob response", async () => {
  const original = api.get;
  api.get = async () => {
    throw {
      response: {
        data: new Blob([JSON.stringify({ detail: "Période invalide." })]),
      },
    };
  };
  try {
    await assert.rejects(
      download("sale", "xlsx"),
      (e) => errorMessage(e) === "Période invalide.",
    );
  } finally {
    api.get = original;
  }
});
