import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import PublicLayout from "./layouts/PublicLayout";
import DashboardLayout from "./layouts/DashboardLayout";

const Home = lazy(() => import("./pages/Home"));
const About = lazy(() => import("./pages/About"));
const Features = lazy(() => import("./pages/Features"));
const Contact = lazy(() => import("./pages/Contact"));
const AuthPage = lazy(() => import("./pages/AuthPage"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Unavailable = lazy(() => import("./pages/Unavailable"));
const NotFound = lazy(() => import("./pages/NotFound"));
import { MotionConfig } from "framer-motion";
import { AuthProvider, RequireAuth } from "./contexts/AuthContext";
import WorkspaceLayout from "./components/WorkspaceLayout";
const Products = lazy(() => import("./pages/Products"));
const Directory = lazy(() => import("./pages/Directory"));
const Movements = lazy(() => import("./pages/Movements"));
const Documents = lazy(() => import("./pages/Documents"));
const LiveDashboard = lazy(() => import("./pages/LiveDashboard"));
const Reports = lazy(() => import("./pages/Reports"));
const Settings = lazy(() => import("./pages/Settings"));

function App() {
  return (
    <MotionConfig reducedMotion="user">
      <BrowserRouter>
        <AuthProvider>
          <Suspense
            fallback={
              <div role="status" className="p-10 text-center text-slate-500">
                Chargement de la page…
              </div>
            }
          >
            <Routes>
              {/* SITE PUBLIC */}
              <Route element={<PublicLayout />}>
                <Route path="/" element={<Home />} />

                <Route path="/about" element={<About />} />

                <Route path="/features" element={<Features />} />

                <Route path="/contact" element={<Contact />} />
                <Route path="*" element={<NotFound />} />
              </Route>

              {/* COMPTES ET RÉCUPÉRATION D’ACCÈS */}
              <Route path="/login" element={<AuthPage mode="login" />} />

              <Route path="/register" element={<AuthPage mode="register" />} />
              <Route
                path="/forgot-password"
                element={<AuthPage mode="forgot" />}
              />
              <Route
                path="/reset-password/:uid/:token"
                element={<AuthPage mode="reset" />}
              />
              <Route element={<RequireAuth />}>
                <Route path="/dashboard" element={<WorkspaceLayout />}>
                  <Route index element={<LiveDashboard />} />
                  <Route path="products" element={<Products />} />
                  <Route
                    path="categories"
                    element={<Directory key="category" kind="category" />}
                  />
                  <Route path="stock" element={<Movements />} />
                  <Route
                    path="sales"
                    element={<Documents key="sale" kind="sale" />}
                  />
                  <Route
                    path="purchases"
                    element={<Documents key="purchase" kind="purchase" />}
                  />
                  <Route
                    path="suppliers"
                    element={<Directory key="supplier" kind="supplier" />}
                  />
                  <Route
                    path="customers"
                    element={<Directory key="customer" kind="customer" />}
                  />
                  <Route path="reports" element={<Reports />} />
                  <Route path="settings" element={<Settings />} />
                  <Route path="*" element={<NotFound />} />
                </Route>
              </Route>

              {/* DÉMONSTRATION PUBLIQUE, DONNÉES FICTIVES */}
              <Route element={<DashboardLayout />}>
                <Route path="/demo" element={<Dashboard />} />
                <Route path="/demo/:module" element={<Unavailable />} />
              </Route>
            </Routes>
          </Suspense>
        </AuthProvider>
      </BrowserRouter>
    </MotionConfig>
  );
}

export default App;
