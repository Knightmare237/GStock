import { useEffect, useState } from "react";
import { allPages, errorMessage } from "../services/api";
export default function useOptions(url, revision = 0) {
  const [rows, setRows] = useState([]),
    [error, setError] = useState("");
  useEffect(() => {
    let alive = true;
    setError("");
    allPages(url)
      .then((data) => {
        if (alive) setRows(data);
      })
      .catch((e) => {
        if (alive) setError(errorMessage(e));
      });
    return () => {
      alive = false;
    };
  }, [url, revision]);
  return { rows, error };
}
