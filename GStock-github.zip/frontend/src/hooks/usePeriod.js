import { useState } from "react";
export default function usePeriod() {
  const today = new Date().toISOString().slice(0, 10);
  const past = new Date();
  past.setDate(past.getDate() - 29);
  const [start, setStart] = useState(past.toISOString().slice(0, 10));
  const [end, setEnd] = useState(today);
  return { start, end, setStart, setEnd };
}
