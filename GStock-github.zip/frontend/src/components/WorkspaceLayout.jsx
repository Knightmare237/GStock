import { useEffect, useRef, useState } from "react";
import {
  Link,
  NavLink,
  Outlet,
  useNavigate,
  useLocation,
} from "react-router-dom";
import {
  LayoutDashboard,
  Package,
  Tags,
  ArrowLeftRight,
  ShoppingCart,
  Truck,
  Users,
  BarChart3,
  Settings,
  Menu,
  X,
  Sparkles,
} from "lucide-react";
import { useAuth } from "../contexts/session";
import { errorMessage } from "../services/api";
import { ErrorNotice } from "./ui";
import ProfileMenu from "./ProfileMenu";

export default function WorkspaceLayout() {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const space = location.pathname.split("/")[2] || "overview";
  const drawer = useRef(null);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const nodes = () =>
      Array.from(
        drawer.current.querySelectorAll("a, button:not(:disabled)"),
      ).filter((el) => el.getClientRects().length);
    nodes()[0]?.focus();
    function keyboard(event) {
      if (event.key === "Escape") {
        setOpen(false);
        return;
      }
      if (event.key !== "Tab") return;
      const items = nodes(),
        first = items[0],
        last = items.at(-1);
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    }
    function resize() {
      if (window.innerWidth >= 1024) setOpen(false);
    }
    document.addEventListener("keydown", keyboard);
    window.addEventListener("resize", resize);
    return () => {
      document.removeEventListener("keydown", keyboard);
      window.removeEventListener("resize", resize);
      document.body.style.overflow = previousOverflow;
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);
  const links = [
    ["", "Vue d’ensemble", LayoutDashboard],
    ["products", "Produits", Package],
    ["categories", "Catégories", Tags],
    ["stock", "Mouvements", ArrowLeftRight],
    ["sales", "Ventes", ShoppingCart],
    ["purchases", "Achats", Truck],
    ["suppliers", "Fournisseurs", Truck],
    ["customers", "Clients", Users],
    ["reports", "Rapports", BarChart3],
    ["settings", "Paramètres", Settings],
  ];
  async function exit() {
    setBusy(true);
    setError("");
    try {
      await signOut();
      navigate("/login");
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="workspace min-h-screen" data-space={space}>
      {open && (
        <button
          aria-label="Fermer le menu"
          className="fixed inset-0 z-40 bg-slate-950/40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}
      <aside
        ref={drawer}
        className={`workspace-sidebar fixed inset-y-0 left-0 z-50 flex w-64 flex-col text-white transition-transform lg:visible lg:translate-x-0 ${open ? "visible translate-x-0" : "invisible -translate-x-full"}`}
        aria-label="Navigation de gestion"
      >
        <div className="flex h-20 items-center justify-between border-b border-white/10 px-5">
          <Link
            to="/dashboard"
            className="brand-link flex items-center gap-3 text-xl font-bold"
          >
            <img src="/gstock.svg" alt="" className="h-10 w-10" />
            GStock
          </Link>
          <button
            aria-label="Fermer le menu"
            onClick={() => setOpen(false)}
            className="p-2 lg:hidden"
          >
            <X size={20} />
          </button>
        </div>
        <div className="px-5 pt-6">
          <p className="truncate text-sm font-semibold">
            {user.organization.name}
          </p>
          <p className="mt-1 text-xs text-blue-200">Votre espace de gestion</p>
        </div>
        <nav className="sidebar-scroll flex-1 space-y-1 overflow-y-auto px-3 py-6">
          {links
            .filter(
              ([path]) =>
                !(user.role === "seller" && path === "purchases") &&
                !(
                  ["seller", "reader"].includes(user.role) && path === "reports"
                ),
            )
            .map(([path, label, Icon]) => (
              <NavLink
                key={path}
                to={`/dashboard${path ? "/" + path : ""}`}
                end={!path}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `workspace-nav-link flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition ${isActive ? "is-active text-white" : "text-blue-100 hover:bg-white/10"}`
                }
              >
                <Icon size={18} />
                {label}
              </NavLink>
            ))}
        </nav>
        <div className="border-t border-white/10 p-4">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <Sparkles size={18} className="mb-2 text-cyan-300" />
            <p className="text-sm font-semibold">Votre activité, organisée.</p>
            <p className="mt-2 text-xs leading-5 text-blue-200">
              Tous vos outils dans un seul espace.
            </p>
          </div>
        </div>
      </aside>
      <div className="lg:pl-64" inert={open ? true : undefined}>
        <header className="workspace-header sticky top-0 z-30 flex h-20 items-center justify-between gap-3 px-4 backdrop-blur sm:px-7">
          <button
            aria-label="Ouvrir le menu"
            aria-expanded={open}
            onClick={() => setOpen(true)}
            className="rounded-xl p-2 lg:hidden"
          >
            <Menu />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-slate-800">
              {user.organization.name}
            </p>
            <p className="hidden text-xs text-slate-500 sm:block">
              {links.find(
                ([path]) => path === (space === "overview" ? "" : space),
              )?.[1] || "Votre espace"}
            </p>
          </div>
          <ProfileMenu user={user} busy={busy} onSignOut={exit} />
        </header>
        <main className="mx-auto max-w-[1600px] space-y-6 p-4 sm:p-7 lg:p-8">
          <ErrorNotice message={error} />
          <div key={location.pathname} className="space-page space-y-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
