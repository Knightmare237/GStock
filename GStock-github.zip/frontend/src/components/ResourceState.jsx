import { Empty, ErrorNotice, secondaryClass } from "./ui";
import Skeleton from "./Skeleton";
export default function ResourceState({ resource, children, empty }) {
  if (resource.loading)
    return (
      <div role="status" aria-label="Chargement" className="space-y-3">
        <Skeleton className="h-12 w-full" />
        {Array.from({ length: 4 }, (_, i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  if (resource.error)
    return (
      <div className="space-y-3">
        <ErrorNotice message={resource.error} />
        <button className={secondaryClass} onClick={resource.reload}>
          Réessayer
        </button>
      </div>
    );
  if (resource.data?.results?.length === 0) return <Empty text={empty} />;
  return children;
}
export function Pagination({ resource, page, setPage }) {
  const count = resource.data?.count || 0;
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-slate-500">
      <span>
        {count} résultat(s) · Page {page}
      </span>
      <div className="flex gap-2">
        <button
          className={secondaryClass}
          disabled={resource.loading || page <= 1}
          onClick={() => setPage(page - 1)}
        >
          Précédent
        </button>
        <button
          className={secondaryClass}
          disabled={resource.loading || !resource.data?.next}
          onClick={() => setPage(page + 1)}
        >
          Suivant
        </button>
      </div>
    </div>
  );
}
