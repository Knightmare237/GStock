import { useState } from "react";
import { Upload, Download } from "lucide-react";
import { api, errorMessage } from "../services/api";
import {
  Modal,
  Field,
  ErrorNotice,
  Table,
  Cell,
  inputClass,
  buttonClass,
  secondaryClass,
} from "./ui";

export default function ProductImport({ onClose, onImported }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(mode) {
    setBusy(true);
    setError("");
    const form = new FormData();
    form.append("file", file);
    form.append("mode", mode);
    try {
      const { data } = await api.post("products/import/", form, {
        timeout: 120000,
      });
      if (mode === "commit") onImported(data.created);
      else setPreview(data);
    } catch (err) {
      if (err.response?.data?.errors) setPreview(err.response.data);
      else {
        setPreview(null);
        setError(errorMessage(err));
      }
    } finally {
      setBusy(false);
    }
  }
  async function template() {
    setError("");
    try {
      const { data } = await api.get("products/import-template/", {
        responseType: "blob",
      });
      const url = URL.createObjectURL(data);
      const link = document.createElement("a");
      link.href = url;
      link.download = "gstock-modele-produits.csv";
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  return (
    <Modal title="Importer des produits" onClose={busy ? () => {} : onClose}>
      <div className="space-y-5" aria-busy={busy}>
        <p className="text-sm leading-6 text-slate-600">
          Ajoutez jusqu’à 1 000 produits depuis un CSV UTF-8 ou un fichier Excel
          XLSX (5 Mo maximum, première feuille). L’import crée de nouveaux
          produits. Les références existantes ne sont jamais remplacées.
        </p>
        <button className={secondaryClass} disabled={busy} onClick={template}>
          <Download size={17} />
          Télécharger le modèle CSV
        </button>
        <p className="text-xs leading-6 text-slate-500">
          Remplacez la ligne d’exemple du modèle. Les colonnes sku (référence)
          et name (nom) sont obligatoires. Les catégories doivent déjà exister ;
          laissez la cellule vide sinon. Quantités et prix positifs ou nuls,
          décimales avec point ou virgule. Sans formules ; codes-barres au
          format texte pour conserver les zéros.
        </p>
        <Field label="Liste de produits">
          <input
            className={inputClass}
            type="file"
            accept=".csv,.xlsx"
            disabled={busy}
            onChange={(event) => {
              setPreview(null);
              setError("");
              const selected = event.target.files?.[0];
              if (selected?.size > 5 * 1024 * 1024) {
                setFile(null);
                setError("Le fichier dépasse 5 Mo.");
              } else setFile(selected || null);
            }}
          />
        </Field>
        <ErrorNotice message={error} />
        {preview && (
          <div className="space-y-4">
            <p role="status" className="text-sm font-semibold">
              {preview.count} produit(s) analysé(s) —{" "}
              {preview.valid
                ? "prêts à importer"
                : `${preview.error_count} erreur(s) à corriger`}
            </p>
            {preview.errors.length > 0 && (
              <div
                role="alert"
                className="max-h-48 overflow-y-auto rounded-xl bg-red-50 p-4 text-sm text-red-800"
              >
                <p className="mb-2 font-semibold">
                  Aucun produit ajouté. Corrigez le fichier puis analysez-le à
                  nouveau.
                </p>
                <ul className="space-y-1">
                  {preview.errors.map((item, index) => (
                    <li key={index}>
                      Ligne {item.line} · {item.field} : {item.message}
                    </li>
                  ))}
                </ul>
                {preview.error_count > preview.errors.length && (
                  <p className="mt-2">
                    Seules les 100 premières erreurs sont affichées.
                  </p>
                )}
              </div>
            )}
            {preview.preview.length > 0 && (
              <>
                <p className="text-xs text-slate-500">
                  Aperçu des 20 premiers produits valides. Toutes les lignes
                  sont vérifiées.
                </p>
                <Table
                  headers={[
                    "Ligne",
                    "Référence",
                    "Produit",
                    "Catégorie",
                    "Stock initial",
                  ]}
                >
                  {preview.preview.map((item) => (
                    <tr key={item.line}>
                      <Cell>{item.line}</Cell>
                      <Cell>{item.sku}</Cell>
                      <Cell>{item.name}</Cell>
                      <Cell>{item.category || "—"}</Cell>
                      <Cell>{item.initial_quantity}</Cell>
                    </tr>
                  ))}
                </Table>
              </>
            )}
          </div>
        )}
        <div className="flex flex-wrap justify-end gap-3">
          <button className={secondaryClass} disabled={busy} onClick={onClose}>
            Annuler
          </button>
          <button
            className={preview?.valid ? secondaryClass : buttonClass}
            disabled={busy || !file}
            onClick={() => submit("preview")}
          >
            {busy ? "Traitement…" : "Analyser le fichier"}
          </button>
          {preview?.valid && (
            <button
              className={buttonClass}
              disabled={busy}
              onClick={() => submit("commit")}
            >
              <Upload size={17} />
              Confirmer l’import de {preview.count} produit(s)
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}
