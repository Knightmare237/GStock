import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer className="bg-slate-950 text-white">
      <div className="mx-auto max-w-7xl px-6 py-14">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2">
              <img src="/gstock.svg" alt="" className="h-10 w-10 rounded-xl" />

              <span className="text-xl font-bold">
                G<span className="text-blue-400">Stock</span>
              </span>
            </Link>

            <p className="mt-5 max-w-xs text-sm leading-6 text-slate-400">
              Une solution moderne et intuitive pour gérer, suivre et optimiser
              votre stock.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="font-semibold">Navigation</h3>

            <div className="mt-5 flex flex-col gap-3 text-sm text-slate-400">
              <Link to="/" className="hover:text-white">
                Accueil
              </Link>

              <Link to="/features" className="hover:text-white">
                Fonctionnalités
              </Link>

              <Link to="/about" className="hover:text-white">
                À propos
              </Link>

              <Link to="/contact" className="hover:text-white">
                Contact
              </Link>
            </div>
          </div>

          {/* Plateforme */}
          <div>
            <h3 className="font-semibold">Plateforme</h3>

            <div className="mt-5 flex flex-col gap-3 text-sm text-slate-400">
              <Link to="/login" className="hover:text-white">
                Connexion
              </Link>

              <Link to="/register" className="hover:text-white">
                Créer un compte
              </Link>

              <span>Catalogue de produits</span>
              <span>Mouvements de stock</span>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold">Contact</h3>

            <div className="mt-5 space-y-3 text-sm text-slate-400">
              <Link to="/contact" className="hover:text-white">
                Informations de contact
              </Link>
              <p>Coordonnées officielles à configurer.</p>
              <p>GStock — Gestion intelligente</p>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-slate-800 pt-6 text-center text-sm text-slate-500">
          © {new Date().getFullYear()} GStock. Tous droits réservés.
        </div>
      </div>
    </footer>
  );
}

export default Footer;
