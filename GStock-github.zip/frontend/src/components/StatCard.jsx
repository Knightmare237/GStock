import { ArrowDown, ArrowUp } from "lucide-react";

function StatCard({
  title,
  value,
  variation,
  icon: Icon,
  positive = true,
}) {
  return (
    <div className="group rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg">

      <div className="flex items-start justify-between">

        <div>
          <p className="text-sm text-slate-500">
            {title}
          </p>

          <p className="mt-2 text-2xl font-bold text-slate-900">
            {value}
          </p>
        </div>

        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600 transition group-hover:bg-blue-600 group-hover:text-white">
          <Icon size={21} />
        </div>

      </div>

      <div className="mt-4 flex items-center gap-2">

        <span
          className={`flex items-center gap-1 text-xs font-semibold ${
            positive ? "text-green-600" : "text-red-500"
          }`}
        >
          {positive ? (
            <ArrowUp size={13} />
          ) : (
            <ArrowDown size={13} />
          )}

          {variation}
        </span>

        <span className="text-xs text-slate-400">
          vs mois dernier
        </span>

      </div>

    </div>
  );
}

export default StatCard;