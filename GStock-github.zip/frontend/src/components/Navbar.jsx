import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Link, NavLink } from "react-router-dom";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinkClass = ({ isActive }) =>
    `text-sm font-medium transition ${
      isActive ? "text-blue-600" : "text-slate-600 hover:text-blue-600"
    }`;

  return (
    <header className="sticky top-0 z-50 border-b border-slate-100 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-6">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <img src="/gstock.svg" alt="" className="h-10 w-10 rounded-xl" />

          <span className="text-xl font-bold text-slate-900">
            G<span className="text-blue-600">Stock</span>
          </span>
        </Link>

        {/* Desktop navigation */}
        <nav className="hidden items-center gap-8 lg:flex">
          <NavLink to="/" className={navLinkClass}>
            Accueil
          </NavLink>

          <NavLink to="/features" className={navLinkClass}>
            Fonctionnalités
          </NavLink>

          <NavLink to="/about" className={navLinkClass}>
            À propos
          </NavLink>

          <NavLink to="/contact" className={navLinkClass}>
            Contact
          </NavLink>
        </nav>

        {/* Desktop buttons */}
        <div className="hidden items-center gap-3 lg:flex">
          <Link
            to="/login"
            className="rounded-xl px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
          >
            Connexion
          </Link>

          <Link
            to="/register"
            className="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700"
          >
            S'inscrire
          </Link>
        </div>

        {/* Mobile button */}
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="rounded-xl p-2 text-slate-700 hover:bg-slate-100 lg:hidden"
          aria-label={isOpen ? "Fermer le menu" : "Ouvrir le menu"}
          aria-expanded={isOpen}
          aria-controls="public-mobile-menu"
        >
          {isOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div
          id="public-mobile-menu"
          className="border-t border-slate-100 bg-white px-6 py-5 lg:hidden"
        >
          <nav className="flex flex-col gap-4">
            <NavLink
              to="/"
              onClick={() => setIsOpen(false)}
              className={navLinkClass}
            >
              Accueil
            </NavLink>

            <NavLink
              to="/features"
              onClick={() => setIsOpen(false)}
              className={navLinkClass}
            >
              Fonctionnalités
            </NavLink>

            <NavLink
              to="/about"
              onClick={() => setIsOpen(false)}
              className={navLinkClass}
            >
              À propos
            </NavLink>

            <NavLink
              to="/contact"
              onClick={() => setIsOpen(false)}
              className={navLinkClass}
            >
              Contact
            </NavLink>

            <div className="mt-2 flex flex-col gap-3 border-t border-slate-100 pt-4">
              <Link
                to="/login"
                onClick={() => setIsOpen(false)}
                className="rounded-xl px-4 py-3 text-center text-sm font-semibold text-slate-700 hover:bg-slate-100"
              >
                Connexion
              </Link>

              <Link
                to="/register"
                onClick={() => setIsOpen(false)}
                className="rounded-xl bg-blue-600 px-4 py-3 text-center text-sm font-semibold text-white"
              >
                S'inscrire
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

export default Navbar;
