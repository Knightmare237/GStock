import { useEffect, useRef } from "react";
import { X, Inbox, CircleAlert, CircleCheck } from "lucide-react";

export const inputClass =
  "w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm focus:border-blue-600";
export const buttonClass =
  "primary-button inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50";
export const secondaryClass =
  "secondary-button inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium hover:bg-slate-50";
export function Field({ label, children }) {
  return (
    <label className="block space-y-2 text-sm font-medium text-slate-700">
      <span>{label}</span>
      {children}
    </label>
  );
}
export function ErrorNotice({ message }) {
  return message ? (
    <p
      role="alert"
      className="notice-enter flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
    >
      <CircleAlert size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
      <span>{message}</span>
    </p>
  ) : null;
}
export function SuccessNotice({ message }) {
  return message ? (
    <p
      role="status"
      className="notice-enter flex items-start gap-2 rounded-xl border border-green-200 bg-green-50 p-3 text-sm text-green-800"
    >
      <CircleCheck size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
      <span>{message}</span>
    </p>
  ) : null;
}
export function Empty({ text = "Aucune donnée pour le moment." }) {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-12 text-center text-slate-500">
      <span className="empty-icon">
        <Inbox size={28} aria-hidden="true" />
      </span>
      <p>{text}</p>
    </div>
  );
}
export function PageHeading({ title, subtitle, children }) {
  return (
    <div className="space-heading flex flex-wrap items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">
          {title}
        </h1>
        <p className="mt-2 text-sm text-slate-500">{subtitle}</p>
      </div>
      {children}
    </div>
  );
}
export function Modal({ title, onClose, children }) {
  const ref = useRef(null);
  useEffect(() => {
    const dialog = ref.current;
    dialog.showModal();
    return () => dialog.close();
  }, []);
  return (
    <dialog
      ref={ref}
      onCancel={onClose}
      aria-label={title}
      className="space-modal m-auto max-h-[90dvh] w-[calc(100%-2rem)] max-w-2xl overflow-y-auto rounded-2xl border-0 bg-white p-5 shadow-2xl backdrop:bg-slate-950/50 sm:p-7"
    >
      <div className="mb-6 flex items-center justify-between gap-3">
        <h2 className="text-xl font-bold">{title}</h2>
        <button
          onClick={onClose}
          aria-label="Fermer"
          className={secondaryClass}
        >
          <X size={18} />
        </button>
      </div>
      {children}
    </dialog>
  );
}
export function Confirm({ title, text, onConfirm, onClose, busy, error }) {
  return (
    <Modal title={title} onClose={busy ? () => {} : onClose}>
      <div className="space-y-5">
        <p>{text}</p>
        <ErrorNotice message={error} />
        <div className="flex flex-wrap justify-end gap-3">
          <button disabled={busy} onClick={onClose} className={secondaryClass}>
            Annuler
          </button>
          <button disabled={busy} onClick={onConfirm} className={buttonClass}>
            {busy ? "Traitement…" : "Confirmer"}
          </button>
        </div>
      </div>
    </Modal>
  );
}
export function Table({ headers, children }) {
  return (
    <div className="space-table overflow-x-auto rounded-2xl border border-slate-200 bg-white">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
          <tr>
            {headers.map((h) => (
              <th key={h} scope="col" className="px-4 py-4">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">{children}</tbody>
      </table>
    </div>
  );
}
export function Cell({ children }) {
  return <td className="px-4 py-4">{children}</td>;
}
