import { NavLink } from "react-router-dom";
import {
  BarChart3,
  Boxes,
  ClipboardList,
  LayoutDashboard,
  Package,
  Settings,
  ShoppingCart,
  Truck,
  Users,
  X,
} from "lucide-react";

function DashboardSidebar({ open, onClose }) {
  const links = [
    {
      label: "Tableau de bord",
      icon: LayoutDashboard,
      to: "/demo",
    },
    {
      label: "Produits",
      icon: Package,
      to: "/demo/products",
    },
    {
      label: "Stock",
      icon: Boxes,
      to: "/demo/stock",
    },
    {
      label: "Ventes",
      icon: ShoppingCart,
      to: "/demo/sales",
    },
    {
      label: "Achats",
      icon: ClipboardList,
      to: "/demo/purchases",
    },
    {
      label: "Fournisseurs",
      icon: Truck,
      to: "/demo/suppliers",
    },
    {
      label: "Clients",
      icon: Users,
      to: "/demo/customers",
    },
    {
      label: "Rapports",
      icon: BarChart3,
      to: "/demo/reports",
    },
  ];

  return (
    <>
      {open && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/50 lg:hidden"
        />
      )}

      <aside
        className={`fixed left-0 top-0 z-50 flex h-screen w-72 flex-col bg-slate-950 text-white transition-transform duration-300 lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Logo */}
        <div className="flex h-20 items-center justify-between border-b border-slate-800 px-6">
          <div className="flex items-center gap-3">
            <img src="/gstock.svg" alt="" className="h-10 w-10 rounded-xl" />

            <div>
              <p className="font-bold">
                G<span className="text-blue-400">Stock</span>
              </p>

              <p className="text-xs text-slate-500">Gestion de stock</p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Fermer le menu"
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 lg:hidden"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="sidebar-scroll flex-1 overflow-y-auto px-4 py-6">
          <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
            Principal
          </p>

          <div className="space-y-1">
            {links.map((link) => {
              const Icon = link.icon;

              return (
                <NavLink
                  key={link.label}
                  to={link.to}
                  end={link.to === "/demo"}
                  onClick={onClose}
                  className={({ isActive }) =>
                    `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition ${
                      isActive
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20"
                        : "text-slate-400 hover:bg-slate-800 hover:text-white"
                    }`
                  }
                >
                  <Icon size={19} />
                  {link.label}
                </NavLink>
              );
            })}
          </div>

          <p className="mb-3 mt-8 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
            Configuration
          </p>

          <NavLink
            to="/demo/settings"
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition ${
                isActive
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`
            }
          >
            <Settings size={19} />
            Paramètres
          </NavLink>
        </nav>

        <p className="border-t border-slate-800 p-5 text-xs text-slate-400">
          Démonstration publique · Données fictives
        </p>
      </aside>
    </>
  );
}

export default DashboardSidebar;
