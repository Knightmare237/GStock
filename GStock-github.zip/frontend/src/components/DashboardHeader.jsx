import { Bell, Menu, Search } from "lucide-react";

function DashboardHeader({ onMenuClick }) {
  return (
    <header className="sticky top-0 z-30 flex h-20 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur sm:px-6">
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          aria-label="Ouvrir le menu de démonstration"
          className="rounded-xl p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
        >
          <Menu size={22} />
        </button>

        <div className="hidden md:block">
          <h1 className="text-lg font-bold text-slate-900">Aperçu GStock</h1>

          <p className="text-sm text-slate-500">
            Démonstration publique, données fictives.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative hidden lg:block">
          <Search
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />

          <input
            type="search"
            disabled
            aria-label="Recherche indisponible dans la démonstration"
            placeholder="Rechercher..."
            className="w-64 rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-10 pr-4 text-sm outline-none transition focus:border-blue-500 focus:bg-white"
          />
        </div>

        <button
          disabled
          aria-label="Notifications indisponibles dans la démonstration"
          className="relative rounded-xl p-2.5 text-slate-600 hover:bg-slate-100"
        >
          <Bell size={20} />
        </button>

        <div className="flex items-center gap-2 rounded-xl border border-blue-100 bg-blue-50 p-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 font-semibold text-white">
            D
          </span>
          <div className="hidden sm:block">
            <p className="text-xs font-semibold text-slate-800">
              Compte de démonstration
            </p>
            <p className="text-xs text-slate-500">Données fictives</p>
          </div>
        </div>
      </div>
    </header>
  );
}

export default DashboardHeader;
