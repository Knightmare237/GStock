import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ChevronDown,
  LogOut,
  Settings,
  UserRound,
  Building2,
} from "lucide-react";

const roles = {
  owner: "Administrateur",
  manager: "Gestionnaire",
  seller: "Vendeur",
  accountant: "Comptable",
  reader: "Lecteur",
};

export default function ProfileMenu({ user, busy, onSignOut }) {
  const [open, setOpen] = useState(false);
  const root = useRef(null),
    trigger = useRef(null);
  const initials =
    user.name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toUpperCase() || "G";
  useEffect(() => {
    if (!open) return;
    function outside(event) {
      if (!root.current.contains(event.target)) setOpen(false);
    }
    function keyboard(event) {
      if (event.key === "Escape") {
        setOpen(false);
        trigger.current.focus();
      }
    }
    document.addEventListener("pointerdown", outside);
    document.addEventListener("keydown", keyboard);
    return () => {
      document.removeEventListener("pointerdown", outside);
      document.removeEventListener("keydown", keyboard);
    };
  }, [open]);
  return (
    <div ref={root} className="profile-menu">
      <button
        ref={trigger}
        className="profile-trigger"
        aria-label="Mon compte"
        aria-expanded={open}
        aria-controls="account-panel"
        onClick={() => setOpen((value) => !value)}
      >
        <span className="profile-avatar">
          {initials}
          <span className="profile-status" />
        </span>
        <span className="hidden min-w-0 text-left sm:block">
          <span className="block max-w-44 truncate text-sm font-semibold text-slate-900">
            {user.name}
          </span>
          <span className="block text-xs text-slate-500">
            {roles[user.role]}
          </span>
        </span>
        <ChevronDown
          size={16}
          className={`profile-chevron ${open ? "is-open" : ""}`}
        />
      </button>
      {open && (
        <div
          id="account-panel"
          className="profile-panel"
          onBlur={(event) => {
            if (!root.current.contains(event.relatedTarget)) setOpen(false);
          }}
        >
          <div className="border-b border-slate-100 px-4 py-4">
            <p className="font-semibold text-slate-900">{user.name}</p>
            <p className="mt-1 break-all text-xs text-slate-500">
              {user.email}
            </p>
            <span className="profile-role">{roles[user.role]}</span>
          </div>
          <p className="flex items-center gap-2 px-4 py-3 text-xs text-slate-500">
            <Building2 size={14} className="shrink-0" />
            <span className="truncate">{user.organization.name}</span>
          </p>
          <div className="space-y-1 px-2 pb-2">
            <Link
              to="/dashboard/settings"
              className="profile-action"
              onClick={() => setOpen(false)}
            >
              <UserRound size={17} />
              Mon profil
            </Link>
            <Link
              to="/dashboard/settings"
              className="profile-action"
              onClick={() => setOpen(false)}
            >
              <Settings size={17} />
              Paramètres du compte
            </Link>
            <button
              disabled={busy}
              className="profile-action profile-logout"
              onClick={onSignOut}
            >
              <LogOut size={17} />
              {busy ? "Déconnexion…" : "Se déconnecter"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
